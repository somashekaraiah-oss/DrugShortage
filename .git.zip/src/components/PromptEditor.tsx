import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/hooks/use-toast";
import { 
  Edit3, 
  Save, 
  Plus, 
  Trash2, 
  Eye, 
  EyeOff, 
  CheckCircle, 
  AlertCircle,
  Copy,
  RefreshCw
} from "lucide-react";
import { 
  promptManager, 
  PromptTemplate, 
  PromptContext,
  getTemplateForIntent,
  buildPromptContext
} from "@/services/promptManager";

interface PromptEditorProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PromptEditor = ({ isOpen, onClose }: PromptEditorProps) => {
  const [templates, setTemplates] = useState<PromptTemplate[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<PromptTemplate | null>(null);
  const [editingTemplate, setEditingTemplate] = useState<Partial<PromptTemplate> | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [validationResult, setValidationResult] = useState<{ valid: boolean; errors: string[] } | null>(null);
  const [testContext, setTestContext] = useState<PromptContext>({});
  const [previewOutput, setPreviewOutput] = useState<string>("");
  const { toast } = useToast();

  useEffect(() => {
    loadTemplates();
  }, []);

  const loadTemplates = () => {
    const allTemplates = promptManager.getAllTemplates();
    setTemplates(allTemplates);
    if (!selectedTemplate && allTemplates.length > 0) {
      setSelectedTemplate(allTemplates[0]);
    }
  };

  const handleCreateNew = () => {
    const newTemplate: Partial<PromptTemplate> = {
      id: `custom_${Date.now()}`,
      name: "New Template",
      category: "analysis",
      template: "Enter your prompt template here using {{variableName}} syntax...",
      variables: [],
      description: "Custom prompt template",
      isActive: true
    };
    setEditingTemplate(newTemplate);
    setIsEditing(true);
  };

  const handleEdit = (template: PromptTemplate) => {
    setEditingTemplate({ ...template });
    setIsEditing(true);
    validateTemplate(template.template);
  };

  const handleSave = () => {
    if (!editingTemplate || !editingTemplate.template) return;

    const validation = promptManager.validateTemplate(editingTemplate.template);
    if (!validation.valid) {
      toast({
        title: "Validation Error",
        description: validation.errors.join(", "),
        variant: "destructive"
      });
      return;
    }

    const variables = promptManager.extractVariables(editingTemplate.template);
    const templateToSave = {
      ...editingTemplate,
      variables,
      lastModified: new Date()
    } as PromptTemplate;

    promptManager.saveTemplate(templateToSave);
    loadTemplates();
    setSelectedTemplate(templateToSave);
    setIsEditing(false);
    setEditingTemplate(null);

    toast({
      title: "Template Saved",
      description: `Template "${templateToSave.name}" has been saved successfully.`
    });
  };

  const handleDelete = (templateId: string) => {
    if (promptManager.deleteTemplate(templateId)) {
      loadTemplates();
      if (selectedTemplate?.id === templateId) {
        setSelectedTemplate(templates[0] || null);
      }
      toast({
        title: "Template Deleted",
        description: "Template has been removed successfully."
      });
    }
  };

  const handleToggle = (templateId: string) => {
    if (promptManager.toggleTemplate(templateId)) {
      loadTemplates();
      toast({
        title: "Template Updated",
        description: "Template status has been changed."
      });
    }
  };

  const validateTemplate = (template: string) => {
    const result = promptManager.validateTemplate(template);
    setValidationResult(result);
    return result;
  };

  const handleTestPrompt = () => {
    if (!selectedTemplate) return;

    try {
      const output = promptManager.injectContext(selectedTemplate.id, testContext);
      setPreviewOutput(output);
    } catch (error) {
      toast({
        title: "Test Error",
        description: error instanceof Error ? error.message : "Failed to generate preview",
        variant: "destructive"
      });
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied",
      description: "Content copied to clipboard"
    });
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-7xl h-[90vh] flex flex-col">
        <CardHeader className="flex-shrink-0 border-b">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Edit3 className="h-5 w-5" />
                Prompt Template Editor
              </CardTitle>
              <p className="text-sm text-muted-foreground">
                Create and manage AI prompt templates with dynamic variable injection
              </p>
            </div>
            <Button variant="outline" onClick={onClose}>
              Close
            </Button>
          </div>
        </CardHeader>

        <CardContent className="flex-1 p-0 overflow-hidden">
          <div className="grid grid-cols-12 h-full">
            {/* Template List Sidebar */}
            <div className="col-span-3 border-r">
              <div className="p-4 border-b">
                <Button 
                  onClick={handleCreateNew}
                  className="w-full"
                  size="sm"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  New Template
                </Button>
              </div>
              
              <ScrollArea className="h-[calc(100%-80px)]">
                <div className="p-4 space-y-2">
                  {templates.map((template) => (
                    <Card 
                      key={template.id}
                      className={`cursor-pointer transition-all hover:bg-accent/50 ${
                        selectedTemplate?.id === template.id ? 'ring-2 ring-primary' : ''
                      }`}
                      onClick={() => setSelectedTemplate(template)}
                    >
                      <CardContent className="p-3">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="text-sm font-medium truncate">{template.name}</h4>
                          <div className="flex items-center gap-1">
                            {template.isActive ? (
                              <Eye className="h-3 w-3 text-green-500" />
                            ) : (
                              <EyeOff className="h-3 w-3 text-gray-400" />
                            )}
                          </div>
                        </div>
                        <Badge variant="outline" className="text-xs">
                          {template.category}
                        </Badge>
                        <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
                          {template.description}
                        </p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </ScrollArea>
            </div>

            {/* Main Editor Area */}
            <div className="col-span-9">
              <Tabs defaultValue="edit" className="h-full">
                <div className="border-b px-4 py-2">
                  <TabsList>
                    <TabsTrigger value="edit">Edit Template</TabsTrigger>
                    <TabsTrigger value="test">Test & Preview</TabsTrigger>
                    <TabsTrigger value="variables">Variables</TabsTrigger>
                  </TabsList>
                </div>

                <TabsContent value="edit" className="h-[calc(100%-60px)] p-4">
                  {isEditing && editingTemplate ? (
                    <div className="space-y-4 h-full">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="name">Template Name</Label>
                          <Input
                            id="name"
                            value={editingTemplate.name || ""}
                            onChange={(e) => setEditingTemplate({
                              ...editingTemplate,
                              name: e.target.value
                            })}
                          />
                        </div>
                        <div>
                          <Label htmlFor="category">Category</Label>
                          <Select
                            value={editingTemplate.category}
                            onValueChange={(value) => setEditingTemplate({
                              ...editingTemplate,
                              category: value as any
                            })}
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="analysis">Analysis</SelectItem>
                              <SelectItem value="forecast">Forecast</SelectItem>
                              <SelectItem value="risk">Risk Assessment</SelectItem>
                              <SelectItem value="comparison">Comparison</SelectItem>
                              <SelectItem value="summary">Summary</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      <div>
                        <Label htmlFor="description">Description</Label>
                        <Input
                          id="description"
                          value={editingTemplate.description || ""}
                          onChange={(e) => setEditingTemplate({
                            ...editingTemplate,
                            description: e.target.value
                          })}
                        />
                      </div>

                      <div className="flex-1 flex flex-col">
                        <div className="flex items-center justify-between mb-2">
                          <Label htmlFor="template">Template Content</Label>
                          <div className="flex items-center gap-2">
                            {validationResult && (
                              <div className="flex items-center gap-1">
                                {validationResult.valid ? (
                                  <CheckCircle className="h-4 w-4 text-green-500" />
                                ) : (
                                  <AlertCircle className="h-4 w-4 text-red-500" />
                                )}
                                <span className="text-xs">
                                  {validationResult.valid ? 'Valid' : 'Errors'}
                                </span>
                              </div>
                            )}
                          </div>
                        </div>
                        <Textarea
                          id="template"
                          value={editingTemplate.template || ""}
                          onChange={(e) => {
                            setEditingTemplate({
                              ...editingTemplate,
                              template: e.target.value
                            });
                            validateTemplate(e.target.value);
                          }}
                          className="flex-1 font-mono text-sm"
                          placeholder="Enter your prompt template using {{variableName}} syntax..."
                        />
                        {validationResult && !validationResult.valid && (
                          <div className="mt-2 p-2 bg-red-50 border border-red-200 rounded">
                            <p className="text-sm text-red-700">
                              Validation Errors:
                            </p>
                            <ul className="text-xs text-red-600 mt-1">
                              {validationResult.errors.map((error, i) => (
                                <li key={i}>• {error}</li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>

                      <div className="flex items-center justify-between pt-4">
                        <div className="flex items-center gap-2">
                          <Switch
                            checked={editingTemplate.isActive}
                            onCheckedChange={(checked) => setEditingTemplate({
                              ...editingTemplate,
                              isActive: checked
                            })}
                          />
                          <Label>Active</Label>
                        </div>
                        <div className="flex gap-2">
                          <Button
                            variant="outline"
                            onClick={() => {
                              setIsEditing(false);
                              setEditingTemplate(null);
                            }}
                          >
                            Cancel
                          </Button>
                          <Button onClick={handleSave}>
                            <Save className="h-4 w-4 mr-2" />
                            Save Template
                          </Button>
                        </div>
                      </div>
                    </div>
                  ) : selectedTemplate ? (
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="text-lg font-semibold">{selectedTemplate.name}</h3>
                          <p className="text-sm text-muted-foreground">{selectedTemplate.description}</p>
                        </div>
                        <div className="flex gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleToggle(selectedTemplate.id)}
                          >
                            {selectedTemplate.isActive ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => copyToClipboard(selectedTemplate.template)}
                          >
                            <Copy className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleEdit(selectedTemplate)}
                          >
                            <Edit3 className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => handleDelete(selectedTemplate.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>

                      <Separator />

                      <div>
                        <Label>Template Content</Label>
                        <Textarea
                          value={selectedTemplate.template}
                          readOnly
                          className="mt-2 font-mono text-sm min-h-[400px]"
                        />
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center justify-center h-full">
                      <p className="text-muted-foreground">Select a template to view or edit</p>
                    </div>
                  )}
                </TabsContent>

                <TabsContent value="test" className="h-[calc(100%-60px)] p-4">
                  {selectedTemplate && (
                    <div className="grid grid-cols-2 gap-4 h-full">
                      <div className="space-y-4">
                        <div>
                          <Label>Test Context Variables</Label>
                          <div className="mt-2 space-y-2">
                            <Input
                              placeholder="Drug Name"
                              value={testContext.drugName || ""}
                              onChange={(e) => setTestContext({
                                ...testContext,
                                drugName: e.target.value
                              })}
                            />
                            <Input
                              placeholder="Time Range (days)"
                              type="number"
                              value={testContext.timeRange || ""}
                              onChange={(e) => setTestContext({
                                ...testContext,
                                timeRange: parseInt(e.target.value) || undefined
                              })}
                            />
                            <Input
                              placeholder="Manufacturer"
                              value={testContext.manufacturer || ""}
                              onChange={(e) => setTestContext({
                                ...testContext,
                                manufacturer: e.target.value
                              })}
                            />
                            <Input
                              placeholder="Therapy Area"
                              value={testContext.therapyArea || ""}
                              onChange={(e) => setTestContext({
                                ...testContext,
                                therapyArea: e.target.value
                              })}
                            />
                          </div>
                          <Button 
                            onClick={handleTestPrompt}
                            className="w-full mt-4"
                          >
                            <RefreshCw className="h-4 w-4 mr-2" />
                            Generate Preview
                          </Button>
                        </div>
                      </div>

                      <div>
                        <Label>Preview Output</Label>
                        <Textarea
                          value={previewOutput}
                          readOnly
                          className="mt-2 font-mono text-sm h-[400px]"
                          placeholder="Click 'Generate Preview' to see the processed template"
                        />
                      </div>
                    </div>
                  )}
                </TabsContent>

                <TabsContent value="variables" className="h-[calc(100%-60px)] p-4">
                  {selectedTemplate && (
                    <div className="space-y-4">
                      <div>
                        <Label>Available Variables</Label>
                        <div className="mt-2 flex flex-wrap gap-2">
                          {selectedTemplate.variables.map((variable) => (
                            <Badge key={variable} variant="outline">
                              {`{{${variable}}}`}
                            </Badge>
                          ))}
                        </div>
                      </div>

                      <Separator />

                      <div>
                        <Label>Variable Documentation</Label>
                        <div className="mt-2 space-y-2 text-sm">
                          <p><code>{"{{drugName}}"}</code> - Name of the pharmaceutical product</p>
                          <p><code>{"{{timeRange}}"}</code> - Forecast time period in days</p>
                          <p><code>{"{{manufacturer}}"}</code> - Drug manufacturer name</p>
                          <p><code>{"{{therapyArea}}"}</code> - Therapeutic area or drug category</p>
                          <p><code>{"{{riskLevel}}"}</code> - Current risk level (high/medium/low)</p>
                          <p><code>{"{{complianceScore}}"}</code> - Manufacturing compliance percentage</p>
                          <p><code>{"{{comparisonTargets}}"}</code> - List of drugs for comparison</p>
                          <p><code>{"{{userQuery}}"}</code> - Original user query text</p>
                        </div>
                      </div>
                    </div>
                  )}
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};