import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { NDCData } from "./SyntheticDataGenerator";
import { Pill, AlertTriangle, CheckCircle, Clock } from "lucide-react";

interface DrugSelectorProps {
  data: NDCData[];
  selectedNDC?: string;
  onSelectionChange: (ndcId: string) => void;
}

export const DrugSelector = ({ data, selectedNDC, onSelectionChange }: DrugSelectorProps) => {
  const getRiskIcon = (risk: string) => {
    switch (risk) {
      case 'high': return <AlertTriangle className="h-3 w-3" />;
      case 'medium': return <Clock className="h-3 w-3" />;
      default: return <CheckCircle className="h-3 w-3" />;
    }
  };

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'high': return 'text-destructive';
      case 'medium': return 'text-warning';
      default: return 'text-success';
    }
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2">
        <Pill className="h-4 w-4 text-primary" />
        <h3 className="text-sm font-medium">Select Drug for Analysis</h3>
      </div>
      
      <Select value={selectedNDC} onValueChange={onSelectionChange}>
        <SelectTrigger className="w-full">
          <SelectValue placeholder="Choose an NDC to analyze..." />
        </SelectTrigger>
        <SelectContent className="max-h-60">
          {data.map((ndc) => (
            <SelectItem key={ndc.id} value={ndc.id} className="py-3">
              <div className="flex items-center justify-between w-full">
                <div className="flex-1 min-w-0">
                  <div className="font-medium text-sm truncate">{ndc.name}</div>
                  <div className="text-xs text-muted-foreground">{ndc.id}</div>
                </div>
                <div className="flex items-center gap-2 ml-2">
                  <Badge variant="outline" className={`text-xs ${getRiskColor(ndc.riskLevel)}`}>
                    {getRiskIcon(ndc.riskLevel)}
                    {ndc.riskLevel}
                  </Badge>
                </div>
              </div>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
      
      {selectedNDC && (
        <div className="text-xs text-muted-foreground">
          💡 Try asking: "Forecast {data.find(d => d.id === selectedNDC)?.name.split(' ')[0].toLowerCase()} for 45 days"
        </div>
      )}
    </div>
  );
};