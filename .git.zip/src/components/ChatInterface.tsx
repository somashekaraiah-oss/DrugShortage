import { useState, useRef, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { MessageSquare, Send, Bot, User, Zap, TrendingUp, AlertTriangle, RefreshCw } from "lucide-react";
import { NDCData } from "./SyntheticDataGenerator";
import { analyzeQuery, QueryIntent } from "@/utils/semanticMatching";
import { generateContextualResponse, DataInsight } from "@/utils/aiResponseGenerator";
import { promptManager, getTemplateForIntent, buildPromptContext } from "@/services/promptManager";
import { apiClient } from "@/services/apiClient";
import aiAssistantRobot from "../assets/ai-assistant-robot.png";

export interface ChatMessage {
  id: string;
  type: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  insights?: DataInsight[];
  promptTemplate?: string;
  processingTime?: number;
  apiSource?: 'local' | 'fastapi';
}

interface ChatInterfaceProps {
  data: NDCData[];
  onQuerySubmit: (query: string, intent?: QueryIntent) => void;
  messages: ChatMessage[];
  enableAdvancedMode?: boolean;
  onPromptEdit?: () => void;
}

export const ChatInterface = ({ 
  data, 
  onQuerySubmit, 
  messages, 
  enableAdvancedMode = false,
  onPromptEdit 
}: ChatInterfaceProps) => {
  const [input, setInput] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const scrollAreaRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Auto-scroll to bottom when new messages arrive
    if (scrollAreaRef.current) {
      scrollAreaRef.current.scrollTop = scrollAreaRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (input.trim() && !isProcessing) {
      setIsProcessing(true);
      const startTime = Date.now();
      
      try {
        const intent = analyzeQuery(input.trim(), data);
        
        // Enhanced processing with prompt templates and API integration
        if (enableAdvancedMode && apiClient) {
          const templateId = getTemplateForIntent(intent);
          if (templateId) {
            const context = buildPromptContext(intent, data);
            const enhancedPrompt = promptManager.injectContext(templateId, context);
            
            // Try FastAPI first, fallback to local processing
            try {
              const apiResponse = await apiClient.processNaturalLanguageQuery(enhancedPrompt, {
                intent,
                data: data.slice(0, 10), // Limit data for API call
                timestamp: new Date().toISOString()
              });
              
              if (apiResponse.success) {
                // Handle API response with enhanced insights
                const processingTime = Date.now() - startTime;
                onQuerySubmit(input.trim(), intent);
              } else {
                throw new Error('API processing failed');
              }
            } catch (apiError) {
              console.warn('FastAPI processing failed, using local:', apiError);
              onQuerySubmit(input.trim(), intent);
            }
          } else {
            onQuerySubmit(input.trim(), intent);
          }
        } else {
          onQuerySubmit(input.trim(), intent);
        }
        
        setInput("");
      } finally {
        setIsProcessing(false);
      }
    }
  };

  const sampleQueries = [
    "Anything I should be worried about?",
    "What's new in the forecast?",
    "Is this bad?",
    "Should we be concerned about injectables?",
    "What's the story behind this spike?",
    "Show 45-day forecast for NDC_042",
    "Forecast methotrexate for 60 days", 
    "Analyze shortage risk for insulin"
  ];

  return (
    <div className="h-full flex flex-col">
      {/* Messages Area */}
      <ScrollArea className="flex-1 p-6" ref={scrollAreaRef}>
        <div className="space-y-6">
          {messages.length === 0 && (
            <div className="text-center py-12">
              <div className="w-24 h-24 mx-auto mb-6 rounded-full overflow-hidden bg-gradient-to-br from-blue-500 to-cyan-400 p-1">
                <img 
                  src={aiAssistantRobot} 
                  alt="ShortageIQ Assistant" 
                  className="w-full h-full object-cover rounded-full"
                />
              </div>
              <h3 className="text-xl font-semibold mb-3">Welcome to ShortageIQ</h3>
              <p className="text-muted-foreground mb-6 max-w-md mx-auto">
                Your intelligent pharmaceutical shortage forecasting assistant. Ask naturally - I understand conversational queries and provide contextual insights!
              </p>
              <div className="space-y-3">
                <p className="text-sm font-medium text-muted-foreground">Try asking naturally:</p>
                <div className="grid gap-2 max-w-lg mx-auto">
                  {sampleQueries.slice(0, 5).map((query, index) => {
                    const previewIntent = analyzeQuery(query, data);
                    return (
                      <button
                        key={index}
                        onClick={() => {
                          const intent = analyzeQuery(query, data);
                          onQuerySubmit(query, intent);
                        }}
                        disabled={isProcessing}
                        className="text-left p-3 rounded-lg border border-border hover:bg-accent/50 hover:border-primary/30 transition-all duration-200 group disabled:opacity-50"
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-primary group-hover:text-primary-glow font-medium">"{query}"</span>
                          <div className="flex items-center gap-2">
                            <Badge variant="outline" className="text-xs">
                              {previewIntent.type.replace('_', ' ')}
                            </Badge>
                            {previewIntent.confidence > 0.8 && (
                              <Zap className="h-3 w-3 text-yellow-500" />
                            )}
                          </div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          )}
          
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex gap-4 ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {message.type === 'assistant' && (
                <div className="flex-shrink-0 w-12 h-12 bg-gradient-to-br from-blue-500 to-cyan-400 rounded-full flex items-center justify-center overflow-hidden p-1">
                  <img 
                    src={aiAssistantRobot} 
                    alt="ShortageIQ Assistant" 
                    className="w-full h-full object-cover rounded-full"
                  />
                </div>
              )}
              
              <div
                className={`max-w-[85%] p-4 rounded-xl ${
                  message.type === 'user'
                    ? 'bg-primary text-primary-foreground ml-auto rounded-br-sm'
                    : 'bg-muted/50 border rounded-bl-sm'
                }`}
              >
                <div className="prose prose-sm max-w-none">
                  <p className="text-sm whitespace-pre-wrap leading-relaxed m-0">{message.content}</p>
                  
                  {/* Enhanced message metadata */}
                  {enableAdvancedMode && message.type === 'assistant' && (
                    <div className="mt-2 flex items-center gap-2 text-xs text-muted-foreground">
                      {message.promptTemplate && (
                        <Badge variant="outline" className="text-xs">
                          Template: {message.promptTemplate}
                        </Badge>
                      )}
                      {message.processingTime && (
                        <span>{message.processingTime}ms</span>
                      )}
                      {message.apiSource && (
                        <Badge variant={message.apiSource === 'fastapi' ? 'default' : 'secondary'} className="text-xs">
                          {message.apiSource}
                        </Badge>
                      )}
                    </div>
                  )}
                </div>
                
                {/* Render insights for assistant messages */}
                {message.type === 'assistant' && message.insights && (
                  <div className="mt-4 space-y-3">
                    {message.insights.map((insight, idx) => (
                      <div key={idx} className="border border-border/50 rounded-lg overflow-hidden">
                        <div className={`px-3 py-2 text-xs font-medium flex items-center gap-2 ${
                          insight.type === 'alert' ? 'bg-destructive/10 text-destructive' :
                          insight.type === 'metric' ? 'bg-primary/10 text-primary' :
                          'bg-muted/30'
                        }`}>
                          {insight.type === 'alert' && <AlertTriangle className="h-3 w-3" />}
                          {insight.type === 'metric' && <TrendingUp className="h-3 w-3" />}
                          {insight.title}
                        </div>
                        
                        {insight.type === 'table' && Array.isArray(insight.content) && (
                          <div className="max-h-48 overflow-auto">
                            <Table>
                              <TableHeader>
                                <TableRow>
                                  {Object.keys(insight.content[0] || {}).map((header) => (
                                    <TableHead key={header} className="text-xs font-medium py-2">
                                      {header}
                                    </TableHead>
                                  ))}
                                </TableRow>
                              </TableHeader>
                              <TableBody>
                                {insight.content.map((row, rowIdx) => (
                                  <TableRow key={rowIdx}>
                                    {Object.values(row).map((cell, cellIdx) => (
                                      <TableCell key={cellIdx} className="text-xs py-2">
                                        {String(cell)}
                                      </TableCell>
                                    ))}
                                  </TableRow>
                                ))}
                              </TableBody>
                            </Table>
                          </div>
                        )}
                        
                        {insight.type !== 'table' && (
                          <div className="p-3 text-xs">
                            {String(insight.content)}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
                
                <p className="text-xs opacity-60 mt-2 text-right">
                  {message.timestamp.toLocaleTimeString()}
                </p>
              </div>
              
              {message.type === 'user' && (
                <div className="flex-shrink-0 w-10 h-10 bg-secondary/80 rounded-full flex items-center justify-center">
                  <User className="h-5 w-5 text-secondary-foreground" />
                </div>
              )}
            </div>
          ))}
        </div>
      </ScrollArea>
      
      {/* Enhanced Input Area */}
      <div className="border-t bg-background/95 backdrop-blur-sm p-4">
        {enableAdvancedMode && (
          <div className="flex items-center justify-between mb-3 text-xs text-muted-foreground">
            <div className="flex items-center gap-2">
              <span>Advanced Mode</span>
              <Badge variant="outline" className="text-xs">Templates Active</Badge>
              {apiClient && <Badge variant="outline" className="text-xs">FastAPI Ready</Badge>}
            </div>
            {onPromptEdit && (
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={onPromptEdit}
                className="text-xs h-6"
              >
                Edit Prompts
              </Button>
            )}
          </div>
        )}
        
        <form onSubmit={handleSubmit} className="flex gap-3">
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={enableAdvancedMode 
              ? "Ask naturally: 'Anything I should worry about?' or 'What's new?'" 
              : "Ask naturally: 'Should we be concerned?' or 'What's going on?'"
            }
            className="flex-1 h-12"
            disabled={isProcessing}
          />
          <Button 
            type="submit" 
            disabled={!input.trim() || isProcessing} 
            className="bg-gradient-primary h-12 px-6"
          >
            {isProcessing ? (
              <RefreshCw className="h-4 w-4 animate-spin" />
            ) : (
              <Send className="h-4 w-4" />
            )}
          </Button>
        </form>
      </div>
    </div>
  );
};