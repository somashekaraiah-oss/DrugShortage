import React, { useState, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Upload, Download, RefreshCw, Database, FileJson, FileSpreadsheet } from "lucide-react";
import { NDCData, generateSyntheticData } from './SyntheticDataGenerator';
import { useToast } from "@/hooks/use-toast";

interface DataLoaderProps {
  data: NDCData[];
  onDataUpdate: (newData: NDCData[]) => void;
}

// Pre-defined datasets for different scenarios
const DATASET_SCENARIOS = {
  'critical_shortage': 'Critical Shortage Scenario (High-risk drugs)',
  'seasonal_flu': 'Seasonal Flu Outbreak (Respiratory focus)',
  'supply_chain_crisis': 'Supply Chain Crisis (Manufacturing delays)',
  'regulatory_changes': 'New Regulatory Environment (Compliance focus)',
  'oncology_shortage': 'Oncology Drug Shortage (Cancer care crisis)',
  'controlled_substances': 'Controlled Substance Monitoring (DEA focus)',
  'pediatric_emergency': 'Pediatric Emergency (Children\'s hospital)',
  'cardiac_surgery': 'Cardiac Surgery Focus (Cardiovascular drugs)'
};

export const DataLoader: React.FC<DataLoaderProps> = ({ data, onDataUpdate }) => {
  const [selectedScenario, setSelectedScenario] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);
  const [uploadedFileName, setUploadedFileName] = useState<string>('');
  const { toast } = useToast();

  const generateScenarioData = useCallback((scenario: string): NDCData[] => {
    const baseData = generateSyntheticData();
    
    switch (scenario) {
      case 'critical_shortage':
        return baseData.map(item => ({
          ...item,
          shortageFlag: Math.random() < 0.4, // 40% shortage rate
          riskLevel: Math.random() < 0.5 ? 'high' : 'medium' as 'high' | 'medium',
          historicalShortageCount: Math.floor(Math.random() * 8) + 2,
          supplyChainComplexity: Math.floor(Math.random() * 3) + 3 // Higher complexity
        }));
        
      case 'oncology_shortage':
        return baseData.filter(item => item.category === 'oncology' || item.therapeuticArea === 'oncology')
          .map(item => ({
            ...item,
            shortageFlag: Math.random() < 0.6, // 60% shortage for oncology
            riskLevel: 'high' as const,
            criticalityScore: Math.floor(Math.random() * 20) + 80,
            alternativeProducts: Math.floor(Math.random() * 2) // Limited alternatives
          }));
          
      case 'controlled_substances':
        return baseData.filter(item => item.substanceType === 'controlled')
          .map(item => ({
            ...item,
            fdaInspectionScore: Math.floor(Math.random() * 15) + 85, // High inspection scores
            regulatoryChanges: Math.floor(Math.random() * 5) + 3, // Many regulatory changes
            complianceScore: Math.max(0.9, item.complianceScore), // High compliance required
            geopoliticalRisk: Math.floor(Math.random() * 3) + 3 // Higher geopolitical risk
          }));
          
      case 'supply_chain_crisis':
        return baseData.map(item => ({
          ...item,
          leadTime: item.leadTime + Math.floor(Math.random() * 60) + 30, // Extended lead times
          rawMaterialRisk: Math.floor(Math.random() * 2) + 4, // High raw material risk
          geopoliticalRisk: Math.floor(Math.random() * 2) + 4, // High geopolitical risk
          supplyChainComplexity: Math.floor(Math.random() * 2) + 4 // High complexity
        }));
        
      case 'seasonal_flu':
        return baseData.filter(item => 
          item.category === 'respiratory' || 
          item.category === 'antibiotic' || 
          item.category === 'antiviral'
        ).map(item => ({
          ...item,
          customerDemandVolatility: Math.min(1, item.customerDemandVolatility + 0.3), // High demand volatility
          inventoryTurnover: Math.max(5, item.inventoryTurnover - 10), // Faster turnover
          criticalityScore: Math.floor(Math.random() * 30) + 70
        }));
        
      default:
        return baseData;
    }
  }, []);

  const loadScenario = useCallback((scenario: string) => {
    setIsLoading(true);
    setTimeout(() => {
      const scenarioData = generateScenarioData(scenario);
      onDataUpdate(scenarioData);
      setIsLoading(false);
      toast({
        title: "Scenario Loaded",
        description: `Loaded ${DATASET_SCENARIOS[scenario as keyof typeof DATASET_SCENARIOS]} with ${scenarioData.length} drugs`,
      });
    }, 1000); // Simulate loading time
  }, [generateScenarioData, onDataUpdate, toast]);

  const exportData = useCallback((format: 'json' | 'csv') => {
    let content: string;
    let filename: string;
    let mimeType: string;

    if (format === 'json') {
      content = JSON.stringify(data, null, 2);
      filename = `drug_data_${new Date().toISOString().split('T')[0]}.json`;
      mimeType = 'application/json';
    } else {
      // CSV format
      const headers = Object.keys(data[0]).join(',');
      const rows = data.map(item => 
        Object.values(item).map(value => 
          typeof value === 'string' ? `"${value}"` : value
        ).join(',')
      );
      content = [headers, ...rows].join('\n');
      filename = `drug_data_${new Date().toISOString().split('T')[0]}.csv`;
      mimeType = 'text/csv';
    }

    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    toast({
      title: "Data Exported",
      description: `Successfully exported ${data.length} records as ${format.toUpperCase()}`,
    });
  }, [data, toast]);

  const handleFileUpload = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setUploadedFileName(file.name);
    const reader = new FileReader();
    
    reader.onload = (e) => {
      try {
        const content = e.target?.result as string;
        let parsedData: NDCData[];

        if (file.name.endsWith('.json')) {
          parsedData = JSON.parse(content);
        } else if (file.name.endsWith('.csv')) {
          const lines = content.split('\n');
          const headers = lines[0].split(',').map(h => h.trim().replace(/"/g, ''));
          parsedData = lines.slice(1).filter(line => line.trim()).map(line => {
            const values = line.split(',').map(v => v.trim().replace(/"/g, ''));
            const obj: any = {};
            headers.forEach((header, index) => {
              const value = values[index];
              // Try to parse numbers and booleans
              if (!isNaN(Number(value))) {
                obj[header] = Number(value);
              } else if (value === 'true' || value === 'false') {
                obj[header] = value === 'true';
              } else {
                obj[header] = value;
              }
            });
            return obj;
          });
        } else {
          throw new Error('Unsupported file format');
        }

        onDataUpdate(parsedData);
        toast({
          title: "Data Imported",
          description: `Successfully imported ${parsedData.length} records from ${file.name}`,
        });
      } catch (error) {
        toast({
          title: "Import Error",
          description: "Failed to parse the uploaded file. Please check the format.",
          variant: "destructive",
        });
      }
    };

    reader.readAsText(file);
  }, [onDataUpdate, toast]);

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Database className="h-5 w-5" />
          Data Management & Scenarios
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="scenarios" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="scenarios">Scenarios</TabsTrigger>
            <TabsTrigger value="import">Import</TabsTrigger>
            <TabsTrigger value="export">Export</TabsTrigger>
          </TabsList>
          
          <TabsContent value="scenarios" className="space-y-4">
            <div className="space-y-4">
              <div>
                <Label htmlFor="scenario-select">Select Data Scenario</Label>
                <Select value={selectedScenario} onValueChange={setSelectedScenario}>
                  <SelectTrigger>
                    <SelectValue placeholder="Choose a data scenario..." />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.entries(DATASET_SCENARIOS).map(([key, label]) => (
                      <SelectItem key={key} value={key}>
                        {label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <Button 
                onClick={() => selectedScenario && loadScenario(selectedScenario)}
                disabled={!selectedScenario || isLoading}
                className="w-full"
              >
                {isLoading ? (
                  <>
                    <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                    Loading Scenario...
                  </>
                ) : (
                  <>
                    <Database className="mr-2 h-4 w-4" />
                    Load Scenario
                  </>
                )}
              </Button>
              
              <div className="grid grid-cols-2 gap-4 pt-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary">{data.length}</div>
                  <div className="text-sm text-muted-foreground">Total Drugs</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-destructive">
                    {data.filter(d => d.riskLevel === 'high').length}
                  </div>
                  <div className="text-sm text-muted-foreground">High Risk</div>
                </div>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="import" className="space-y-4">
            <div className="space-y-4">
              <div>
                <Label htmlFor="file-upload">Import Data File</Label>
                <div className="mt-2">
                  <Input
                    id="file-upload"
                    type="file"
                    accept=".json,.csv"
                    onChange={handleFileUpload}
                    className="cursor-pointer"
                  />
                  <p className="text-sm text-muted-foreground mt-1">
                    Supports JSON and CSV files with NDC data structure
                  </p>
                </div>
              </div>
              
              {uploadedFileName && (
                <div className="flex items-center gap-2">
                  <Badge variant="secondary">
                    <Upload className="w-3 h-3 mr-1" />
                    {uploadedFileName}
                  </Badge>
                </div>
              )}
            </div>
          </TabsContent>
          
          <TabsContent value="export" className="space-y-4">
            <div className="space-y-4">
              <div className="text-sm text-muted-foreground">
                Export current dataset ({data.length} records) in your preferred format
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <Button 
                  variant="outline" 
                  onClick={() => exportData('json')}
                  className="flex items-center gap-2"
                >
                  <FileJson className="h-4 w-4" />
                  Export JSON
                </Button>
                
                <Button 
                  variant="outline" 
                  onClick={() => exportData('csv')}
                  className="flex items-center gap-2"
                >
                  <FileSpreadsheet className="h-4 w-4" />
                  Export CSV
                </Button>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};