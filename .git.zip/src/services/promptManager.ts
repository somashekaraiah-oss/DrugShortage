// Prompt Management System for ShortageIQ
// Allows dynamic prompt customization and injection

export interface PromptTemplate {
  id: string;
  name: string;
  category: 'analysis' | 'forecast' | 'risk' | 'comparison' | 'summary';
  template: string;
  variables: string[];
  description: string;
  isActive: boolean;
  lastModified: Date;
}

export interface PromptContext {
  drugName?: string;
  timeRange?: number;
  riskLevel?: string;
  manufacturer?: string;
  therapyArea?: string;
  forecastType?: string;
  comparisonTarget?: string[];
  userQuery?: string;
}

class PromptManager {
  private templates: Map<string, PromptTemplate> = new Map();

  constructor() {
    this.initializeDefaultTemplates();
  }

  private initializeDefaultTemplates() {
    const defaultTemplates: PromptTemplate[] = [
      {
        id: 'forecast-analysis',
        name: 'Drug Shortage Forecast',
        category: 'forecast',
        template: `Analyze the shortage risk for {{drugName}} over the next {{timeRange}} days. Consider:
- Current compliance score and manufacturing status
- Historical shortage patterns
- Regulatory factors and inspection history
- Supply chain vulnerabilities
- Market demand fluctuations

Provide a detailed {{timeRange}}-day forecast with confidence intervals and key risk factors.`,
        variables: ['drugName', 'timeRange'],
        description: 'Generates pharmaceutical shortage forecasts using TFT model',
        isActive: true,
        lastModified: new Date()
      },
      {
        id: 'risk-assessment',
        name: 'Risk Level Analysis',
        category: 'risk',
        template: `Evaluate the current risk level for {{drugName}} manufactured by {{manufacturer}}:
- Manufacturing compliance ({{complianceScore}}%)
- Inspection gaps and regulatory status
- Critical therapy area impact: {{therapyArea}}
- Alternative suppliers availability
- Demand elasticity factors

Classify as HIGH/MEDIUM/LOW risk with supporting evidence.`,
        variables: ['drugName', 'manufacturer', 'complianceScore', 'therapyArea'],
        description: 'Comprehensive risk assessment for pharmaceutical products',
        isActive: true,
        lastModified: new Date()
      },
      {
        id: 'comparative-analysis',
        name: 'Drug Comparison',
        category: 'comparison',
        template: `Compare shortage risks between {{comparisonTargets}}:
- Relative risk profiles and shortage history
- Manufacturing diversity and facility status
- Regulatory compliance differences
- Market substitutability and demand
- Supply chain resilience metrics

Recommend the lower-risk alternative with rationale.`,
        variables: ['comparisonTargets'],
        description: 'Side-by-side drug shortage risk comparison',
        isActive: true,
        lastModified: new Date()
      },
      {
        id: 'portfolio-summary',
        name: 'Portfolio Overview',
        category: 'summary',
        template: `Summarize portfolio status for {{therapyArea}} medications:
- Total drugs monitored: {{totalDrugs}}
- Active shortage alerts: {{activeShortages}}
- Average compliance: {{avgCompliance}}%
- Critical risk concentration areas
- Recommended mitigation strategies

Focus on actionable insights for supply chain management.`,
        variables: ['therapyArea', 'totalDrugs', 'activeShortages', 'avgCompliance'],
        description: 'Executive summary of pharmaceutical portfolio health',
        isActive: true,
        lastModified: new Date()
      },
      {
        id: 'trend-analysis',
        name: 'Market Trend Analysis',
        category: 'analysis',
        template: `Analyze shortage trends for {{therapyArea}} over recent periods:
- Emerging shortage patterns and cyclical behavior
- Regulatory impact on supply stability
- Manufacturing consolidation effects
- Geographic risk concentration
- Predictive indicators for future shortages

Provide trend trajectory and early warning signals.`,
        variables: ['therapyArea'],
        description: 'Market-wide trend analysis for therapy areas',
        isActive: true,
        lastModified: new Date()
      }
    ];

    defaultTemplates.forEach(template => {
      this.templates.set(template.id, template);
    });
  }

  // Get template by ID
  getTemplate(id: string): PromptTemplate | undefined {
    return this.templates.get(id);
  }

  // Get all templates by category
  getTemplatesByCategory(category: PromptTemplate['category']): PromptTemplate[] {
    return Array.from(this.templates.values()).filter(t => t.category === category && t.isActive);
  }

  // Get all active templates
  getAllTemplates(): PromptTemplate[] {
    return Array.from(this.templates.values()).filter(t => t.isActive);
  }

  // Inject context variables into prompt template
  injectContext(templateId: string, context: PromptContext): string {
    const template = this.getTemplate(templateId);
    if (!template) {
      throw new Error(`Template ${templateId} not found`);
    }

    let prompt = template.template;

    // Replace all variables with context values
    Object.entries(context).forEach(([key, value]) => {
      if (value !== undefined) {
        const placeholder = `{{${key}}}`;
        const replacement = Array.isArray(value) ? value.join(', ') : String(value);
        prompt = prompt.replace(new RegExp(placeholder, 'g'), replacement);
      }
    });

    return prompt;
  }

  // Create or update template
  saveTemplate(template: Omit<PromptTemplate, 'lastModified'>): void {
    const updatedTemplate: PromptTemplate = {
      ...template,
      lastModified: new Date()
    };
    this.templates.set(template.id, updatedTemplate);
  }

  // Delete template
  deleteTemplate(id: string): boolean {
    return this.templates.delete(id);
  }

  // Toggle template active status
  toggleTemplate(id: string): boolean {
    const template = this.templates.get(id);
    if (template) {
      template.isActive = !template.isActive;
      template.lastModified = new Date();
      return true;
    }
    return false;
  }

  // Validate template syntax
  validateTemplate(template: string): { valid: boolean; errors: string[] } {
    const errors: string[] = [];
    
    // Check for unmatched braces
    const openBraces = (template.match(/\{\{/g) || []).length;
    const closeBraces = (template.match(/\}\}/g) || []).length;
    
    if (openBraces !== closeBraces) {
      errors.push('Unmatched template braces');
    }

    // Check for valid variable names
    const variables = template.match(/\{\{([^}]+)\}\}/g) || [];
    variables.forEach(variable => {
      const varName = variable.replace(/[{}]/g, '');
      if (!/^[a-zA-Z][a-zA-Z0-9_]*$/.test(varName)) {
        errors.push(`Invalid variable name: ${varName}`);
      }
    });

    return {
      valid: errors.length === 0,
      errors
    };
  }

  // Extract variables from template
  extractVariables(template: string): string[] {
    const variables = template.match(/\{\{([^}]+)\}\}/g) || [];
    return variables.map(v => v.replace(/[{}]/g, ''));
  }
}

// Singleton instance
export const promptManager = new PromptManager();

// Helper function to get appropriate template based on query intent
export function getTemplateForIntent(intent: any): string | null {
  const { type, entities } = intent;
  
  switch (type) {
    case 'forecast_request':
      return 'forecast-analysis';
    case 'risk_inquiry':
      return 'risk-assessment';
    case 'comparison':
      return 'comparative-analysis';
    case 'summarization':
      return 'portfolio-summary';
    case 'trend_analysis':
      return 'trend-analysis';
    default:
      return null;
  }
}

// Helper to build context from query intent and data
export function buildPromptContext(intent: any, data: any[]): PromptContext {
  const context: PromptContext = {
    userQuery: intent.query,
    timeRange: intent.entities.timeRange || 30,
    drugName: intent.entities.drugs?.[0],
    manufacturer: intent.entities.manufacturers?.[0],
    therapyArea: intent.entities.therapyAreas?.[0],
    riskLevel: intent.entities.riskLevel,
    comparisonTarget: intent.entities.comparisonTarget
  };

  // Add computed metrics from data
  if (data.length > 0) {
    const totalDrugs = data.length;
    const activeShortages = data.filter(d => d.shortageFlag).length;
    const avgCompliance = (data.reduce((sum, d) => sum + d.complianceScore, 0) / data.length * 100).toFixed(1);
    
    Object.assign(context, {
      totalDrugs: totalDrugs.toString(),
      activeShortages: activeShortages.toString(),
      avgCompliance
    });
  }

  return context;
}