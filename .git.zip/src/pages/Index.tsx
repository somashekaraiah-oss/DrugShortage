import { useState, useCallback } from "react";
import { useToast } from "@/hooks/use-toast";
import { generateSyntheticData, NDCData } from "@/components/SyntheticDataGenerator";
import { ChatInterface, ChatMessage } from "@/components/ChatInterface";
import { ChartVisualization } from "@/components/ChartVisualization";
import { QueryHistory } from "@/components/QueryHistory";
import { DrugSelector } from "@/components/DrugSelector";
import { VoiceRecorder } from "@/components/VoiceRecorder";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Activity, MessageSquare, BarChart3, TrendingUp, AlertTriangle, CheckCircle } from "lucide-react";
import { analyzeQuery, QueryIntent } from "@/utils/semanticMatching";
import { generateContextualResponse } from "@/utils/aiResponseGenerator";

const Index = () => {
  const [ndcData, setNdcData] = useState<NDCData[]>(() => generateSyntheticData());
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [selectedNDC, setSelectedNDC] = useState<string>("");
  const [currentQueryIntent, setCurrentQueryIntent] = useState<QueryIntent | undefined>();
  const { toast } = useToast();

  // Enhanced contextual AI response generation
  const generateAIResponse = useCallback((query: string, data: NDCData[], intent: QueryIntent): { content: string; insights?: any[] } => {
    const { text, insights } = generateContextualResponse(query, data, intent);
    
    // Update chart if there's a drug mentioned
    const drugName = intent.entities.drugs?.[0];
    if (drugName) {
      const foundNDC = data.find(d => d.name.toLowerCase().includes(drugName.toLowerCase()));
      if (foundNDC) setSelectedNDC(foundNDC.id);
    }
    
    return { content: text, insights };
  }, []);

  const handleQuerySubmit = useCallback((query: string, intent?: QueryIntent) => {
    // Analyze the query using semantic matching
    const analyzedIntent = intent || analyzeQuery(query, ndcData);
    
    // Store the intent for chart visualization - this will update the chart
    setCurrentQueryIntent(analyzedIntent);
    
    // If there's a drug mentioned, set it as selected for chart focus
    const drugName = analyzedIntent.entities.drugs?.[0];
    if (drugName) {
      const foundNDC = ndcData.find(d => d.name.toLowerCase().includes(drugName.toLowerCase()));
      if (foundNDC) setSelectedNDC(foundNDC.id);
    }
    
    // Add user message
    const userMessage: ChatMessage = {
      id: Math.random().toString(36).substr(2, 9),
      type: 'user',
      content: query,
      timestamp: new Date(),
    };

    // Generate AI response using enhanced contextual analysis
    const aiResponse = generateAIResponse(query, ndcData, analyzedIntent);
    const aiMessage: ChatMessage = {
      id: Math.random().toString(36).substr(2, 9),
      type: 'assistant',
      content: aiResponse.content,
      timestamp: new Date(),
      insights: aiResponse.insights,
    };

    setMessages(prev => [...prev, userMessage, aiMessage]);
  }, [ndcData, generateAIResponse]);

  const handleClearHistory = useCallback(() => {
    setMessages([]);
    toast({
      title: "History Cleared",
      description: "Query history has been cleared successfully.",
    });
  }, [toast]);

  const riskMetrics = {
    total: ndcData.length,
    high: ndcData.filter(d => d.riskLevel === 'high').length,
    medium: ndcData.filter(d => d.riskLevel === 'medium').length,
    low: ndcData.filter(d => d.riskLevel === 'low').length,
    avgCompliance: (ndcData.reduce((sum, ndc) => sum + ndc.complianceScore, 0) / ndcData.length * 100).toFixed(1)
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      {/* Hero Section */}
      <div className="text-center space-y-4 py-8">
        <div className="inline-flex items-center gap-3 p-4 bg-gradient-hero rounded-2xl shadow-premium">
          <Activity className="h-8 w-8 text-white animate-pulse-slow" />
          <div className="text-white">
            <h1 className="text-4xl font-bold">ShortageIQ</h1>
            <p className="text-lg opacity-90">AI-Powered Pharmaceutical Intelligence</p>
          </div>
        </div>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          Advanced Temporal Fusion Transformer (TFT) technology providing real-time drug shortage predictions, 
          risk analysis, and actionable insights for pharmaceutical supply chain management.
        </p>
      </div>

      {/* Key Metrics Dashboard */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="shadow-glass hover:shadow-medical transition-all duration-300">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active NDCs</CardTitle>
            <BarChart3 className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">{riskMetrics.total}</div>
            <p className="text-xs text-muted-foreground">Real-time monitoring</p>
          </CardContent>
        </Card>

        <Card className="shadow-glass hover:shadow-medical transition-all duration-300">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">High Risk Alerts</CardTitle>
            <AlertTriangle className="h-4 w-4 text-destructive" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-destructive">{riskMetrics.high}</div>
            <p className="text-xs text-muted-foreground">Immediate attention</p>
          </CardContent>
        </Card>

        <Card className="shadow-glass hover:shadow-medical transition-all duration-300">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Portfolio Health</CardTitle>
            <CheckCircle className="h-4 w-4 text-success" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-success">{riskMetrics.avgCompliance}%</div>
            <p className="text-xs text-muted-foreground">Average compliance</p>
          </CardContent>
        </Card>

        <Card className="shadow-glass hover:shadow-medical transition-all duration-300">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Model Accuracy</CardTitle>
            <TrendingUp className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">85.3%</div>
            <p className="text-xs text-muted-foreground">30-day forecast</p>
          </CardContent>
        </Card>
      </div>

      {/* Main ShortageIQ Interface */}
      <div className="grid grid-cols-1 xl:grid-cols-5 gap-6">
        {/* Chat Interface */}
        <div className="xl:col-span-3">
          <Card className="shadow-premium h-[650px] flex flex-col">
            <CardHeader className="flex-shrink-0 border-b bg-gradient-primary/5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-gradient-primary rounded-full flex items-center justify-center">
                    <MessageSquare className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <CardTitle className="text-primary">ShortageIQ Assistant</CardTitle>
                    <CardDescription>Intelligent drug shortage forecasting and analysis</CardDescription>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="secondary" className="bg-success/10 text-success border-success/20">
                    AI Active
                  </Badge>
                  <VoiceRecorder 
                    onTranscript={(text) => handleQuerySubmit(text)}
                    disabled={false}
                  />
                </div>
              </div>
            </CardHeader>
            <CardContent className="flex-1 p-0 overflow-hidden">
              <ChatInterface
                data={ndcData}
                onQuerySubmit={handleQuerySubmit}
                messages={messages}
              />
            </CardContent>
          </Card>
        </div>

        {/* Charts and Analytics Sidebar */}
        <div className="xl:col-span-2 space-y-4">
          <Card className="shadow-glass h-[450px]">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <BarChart3 className="h-4 w-4" />
                Live Analytics
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0 h-[390px] overflow-hidden">
              <ChartVisualization
                data={ndcData}
                selectedNDC={selectedNDC}
                queryIntent={currentQueryIntent}
              />
            </CardContent>
          </Card>
          
          <Card className="shadow-glass h-[180px]">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium">Drug Selection</CardTitle>
            </CardHeader>
            <CardContent className="p-4">
              <DrugSelector
                data={ndcData}
                selectedNDC={selectedNDC}
                onSelectionChange={(ndcId) => {
                  setSelectedNDC(ndcId);
                  const selectedDrug = ndcData.find(d => d.id === ndcId);
                  if (selectedDrug) {
                    const query = `Analyze ${selectedDrug.name.split(' ')[0].toLowerCase()} risk and forecast`;
                    handleQuerySubmit(query);
                  }
                }}
              />
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Query History Section */}
      <Card className="shadow-glass">
        <CardHeader>
          <CardTitle className="text-sm font-medium">Recent Queries</CardTitle>
        </CardHeader>
        <CardContent className="p-4 max-h-32 overflow-auto">
          <QueryHistory
            messages={messages}
            onClearHistory={handleClearHistory}
            onExportHistory={() => {}}
          />
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <Card className="shadow-glass">
        <CardHeader>
          <CardTitle className="text-center">Sample Queries - Try These!</CardTitle>
          <CardDescription className="text-center">
            Click any query below to see ShortageIQ in action with live chart updates
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {[
              "Forecast methotrexate for 30 days",
              "Show 45-day forecast for NDC_042", 
              "Forecast cisplatin for next 60 days",
              "Show risk trends for lorazepam",
              "Forecast propofol for 15 days",
              "Analyze vancomycin shortage risk",
              "Show 90-day forecast for NDC_078",
              "Compare morphine vs fentanyl risk"
            ].map((query, index) => (
              <Button
                key={index}
                variant="outline"
                size="sm"
                onClick={() => handleQuerySubmit(query)}
                className="h-auto p-3 text-left justify-start whitespace-normal hover:bg-primary/5 hover:border-primary/30 transition-all duration-200"
              >
                <span className="text-xs font-mono text-primary">▶</span>
                <span className="ml-2">"{query}"</span>
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Index;