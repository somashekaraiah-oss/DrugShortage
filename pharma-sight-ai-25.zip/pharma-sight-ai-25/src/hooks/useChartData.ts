// Decoupled Chart Data Hook
// Separates chart logic from chat interface for better scalability

import { useState, useEffect, useMemo } from 'react';
import { NDCData } from '@/components/SyntheticDataGenerator';
import { QueryIntent } from '@/utils/semanticMatching';
import { apiClient } from '@/services/apiClient';

export interface ChartConfig {
  type: 'line' | 'bar' | 'pie' | 'area';
  timeRange: number;
  showConfidence: boolean;
  showFeatures: boolean;
  selectedDrug?: string;
  compareMode: boolean;
  comparisonDrugs: string[];
}

export interface ProcessedChartData {
  forecast: Array<{
    day: number;
    risk: number;
    upperBound?: number;
    lowerBound?: number;
    confidence?: number;
  }>;
  features: Array<{
    feature: string;
    importance: number;
    value: number;
  }>;
  riskDistribution: Array<{
    name: string;
    value: number;
    color: string;
  }>;
  trends: Array<{
    period: string;
    value: number;
    trend: 'up' | 'down' | 'stable';
  }>;
}

export interface ChartDataState {
  data: ProcessedChartData;
  loading: boolean;
  error: string | null;
  lastUpdated: Date | null;
}

export const useChartData = (
  ndcData: NDCData[],
  config: ChartConfig,
  queryIntent?: QueryIntent
) => {
  const [state, setState] = useState<ChartDataState>({
    data: {
      forecast: [],
      features: [],
      riskDistribution: [],
      trends: []
    },
    loading: false,
    error: null,
    lastUpdated: null
  });

  // Process data based on configuration and intent
  const processedData = useMemo(() => {
    if (!ndcData.length) return state.data;

    const selectedDrugData = config.selectedDrug 
      ? ndcData.find(d => d.id === config.selectedDrug || d.name.toLowerCase().includes(config.selectedDrug.toLowerCase()))
      : ndcData[0];

    if (!selectedDrugData) return state.data;

    return {
      forecast: generateForecastData(selectedDrugData, config.timeRange),
      features: generateFeatureData(selectedDrugData),
      riskDistribution: generateRiskDistribution(ndcData),
      trends: generateTrendData(ndcData)
    };
  }, [ndcData, config, queryIntent]);

  // Enhanced forecast generation with API integration
  const generateForecastData = (ndc: NDCData, days: number) => {
    // Use API for enhanced forecasts if available
    if (apiClient && config.type === 'line') {
      // This would be called in a separate effect for async operations
      const baseRisk = ndc.shortageFlag ? 0.8 : 0.2;
      const complianceImpact = (1 - ndc.complianceScore) * 0.5;
      const inspectionImpact = Math.min(ndc.inspectionGap / 365, 1) * 0.3;
      
      return Array.from({ length: days }, (_, i) => {
        const dayRisk = baseRisk + complianceImpact + inspectionImpact;
        const variance = Math.sin(i * 0.2) * 0.1;
        const trend = (ndc.forecastTrend / 100) * (i / days) * 0.2;
        const risk = Math.max(0, Math.min(1, dayRisk + variance + trend));
        
        return {
          day: i + 1,
          risk,
          upperBound: config.showConfidence ? Math.min(1, risk + 0.15) : undefined,
          lowerBound: config.showConfidence ? Math.max(0, risk - 0.15) : undefined,
          confidence: config.showConfidence ? 0.75 + Math.random() * 0.2 : undefined
        };
      });
    }

    // Fallback to local calculation
    const baseRisk = ndc.shortageFlag ? 0.7 : 0.3;
    return Array.from({ length: days }, (_, i) => ({
      day: i + 1,
      risk: Math.max(0, Math.min(1, baseRisk + (Math.random() - 0.5) * 0.2)),
      upperBound: config.showConfidence ? Math.min(1, baseRisk + 0.2) : undefined,
      lowerBound: config.showConfidence ? Math.max(0, baseRisk - 0.2) : undefined
    }));
  };

  // Feature importance calculation
  const generateFeatureData = (ndc: NDCData) => {
    const features = [
      { 
        feature: "Compliance Score", 
        importance: 0.35, 
        value: ndc.complianceScore,
        description: "Manufacturing compliance rating"
      },
      { 
        feature: "Inspection Gap", 
        importance: 0.28, 
        value: Math.min(ndc.inspectionGap / 365, 1),
        description: "Time since last FDA inspection"
      },
      { 
        feature: "Manufacturer Tier", 
        importance: 0.22, 
        value: (4 - ndc.manufacturerTier) / 3,
        description: "Manufacturer reliability tier"
      },
      { 
        feature: "Historical Shortages", 
        importance: 0.15, 
        value: ndc.shortageFlag ? 1 : 0,
        description: "Past shortage occurrences"
      }
    ];

    // Add dynamic features based on query intent
    if (queryIntent?.entities.therapyAreas?.includes('oncology')) {
      features.push({
        feature: "Critical Therapy Area",
        importance: 0.25,
        value: 1,
        description: "Essential oncology medication"
      });
    }

    return features.sort((a, b) => b.importance - a.importance);
  };

  // Risk distribution across portfolio
  const generateRiskDistribution = (data: NDCData[]) => {
    const distribution = [
      { 
        name: "Low Risk", 
        value: data.filter(d => d.riskLevel === 'low').length, 
        color: "#22c55e",
        percentage: (data.filter(d => d.riskLevel === 'low').length / data.length) * 100
      },
      { 
        name: "Medium Risk", 
        value: data.filter(d => d.riskLevel === 'medium').length, 
        color: "#eab308",
        percentage: (data.filter(d => d.riskLevel === 'medium').length / data.length) * 100
      },
      { 
        name: "High Risk", 
        value: data.filter(d => d.riskLevel === 'high').length, 
        color: "#ef4444",
        percentage: (data.filter(d => d.riskLevel === 'high').length / data.length) * 100
      }
    ];

    return distribution.filter(item => item.value > 0);
  };

  // Trend analysis over time periods
  const generateTrendData = (data: NDCData[]) => {
    // Simulate historical trend data
    const periods = ['Q1', 'Q2', 'Q3', 'Q4'];
    return periods.map((period, index) => {
      const baseValue = data.filter(d => d.riskLevel === 'high').length;
      const variation = (Math.random() - 0.5) * 5;
      const value = Math.max(0, baseValue + variation);
      
      return {
        period,
        value,
        trend: index > 0 && value > (baseValue + ((index - 1) * variation)) ? 'up' : 
               index > 0 && value < (baseValue + ((index - 1) * variation)) ? 'down' : 'stable'
      } as const;
    });
  };

  // Fetch enhanced data from API when configuration changes
  useEffect(() => {
    if (!config.selectedDrug || !apiClient) return;

    setState(prev => ({ ...prev, loading: true, error: null }));

    const fetchEnhancedData = async () => {
      try {
        const selectedDrug = ndcData.find(d => 
          d.id === config.selectedDrug || 
          d.name.toLowerCase().includes(config.selectedDrug!.toLowerCase())
        );

        if (!selectedDrug) return;

        // Call FastAPI backend for enhanced forecasting
        const response = await apiClient.getForecast({
          drugName: selectedDrug.name,
          ndcCode: selectedDrug.id,
          timeRange: config.timeRange,
          includeConfidence: config.showConfidence,
          modelVersion: 'tft-v2'
        });

        if (response.success && response.data) {
          // Merge API data with local calculations
          setState(prev => ({
            ...prev,
            data: {
              ...processedData,
              forecast: response.data!.predictions.map(p => ({
                day: p.day,
                risk: p.shortageRisk,
                confidence: p.confidence,
                upperBound: config.showConfidence ? p.shortageRisk + 0.1 : undefined,
                lowerBound: config.showConfidence ? p.shortageRisk - 0.1 : undefined
              }))
            },
            loading: false,
            lastUpdated: new Date()
          }));
        } else {
          throw new Error(response.error || 'API request failed');
        }
      } catch (error) {
        console.warn('API forecast failed, using local data:', error);
        setState(prev => ({
          ...prev,
          data: processedData,
          loading: false,
          error: null // Don't show error for fallback
        }));
      }
    };

    // Debounce API calls
    const timeoutId = setTimeout(fetchEnhancedData, 500);
    return () => clearTimeout(timeoutId);
  }, [config.selectedDrug, config.timeRange, config.showConfidence]);

  // Update local data when processed data changes
  useEffect(() => {
    setState(prev => ({
      ...prev,
      data: processedData,
      lastUpdated: new Date()
    }));
  }, [processedData]);

  // Comparison mode data processing
  const getComparisonData = () => {
    if (!config.compareMode || config.comparisonDrugs.length < 2) {
      return null;
    }

    return config.comparisonDrugs.map(drugId => {
      const drug = ndcData.find(d => d.id === drugId);
      if (!drug) return null;

      return {
        name: drug.name,
        forecast: generateForecastData(drug, config.timeRange),
        features: generateFeatureData(drug),
        riskLevel: drug.riskLevel
      };
    }).filter(Boolean);
  };

  // Export chart data for external use
  const exportData = (format: 'json' | 'csv') => {
    const exportData = {
      ...state.data,
      metadata: {
        timeRange: config.timeRange,
        selectedDrug: config.selectedDrug,
        exportedAt: new Date().toISOString(),
        configuration: config
      }
    };

    if (format === 'json') {
      return JSON.stringify(exportData, null, 2);
    } else {
      // Convert to CSV format
      const csvRows = [];
      csvRows.push(['Day', 'Risk', 'Upper Bound', 'Lower Bound']);
      
      state.data.forecast.forEach(row => {
        csvRows.push([
          row.day.toString(),
          row.risk.toFixed(3),
          row.upperBound?.toFixed(3) || '',
          row.lowerBound?.toFixed(3) || ''
        ]);
      });

      return csvRows.map(row => row.join(',')).join('\n');
    }
  };

  return {
    ...state,
    data: processedData,
    comparisonData: getComparisonData(),
    exportData,
    refreshData: () => {
      setState(prev => ({ ...prev, lastUpdated: new Date() }));
    }
  };
};