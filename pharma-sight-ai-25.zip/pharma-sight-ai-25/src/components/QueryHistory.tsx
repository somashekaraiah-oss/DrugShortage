import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Button } from "@/components/ui/button";
import { History, Download, Trash2, Clock } from "lucide-react";
import { ChatMessage } from "./ChatInterface";

interface QueryHistoryProps {
  messages: ChatMessage[];
  onClearHistory: () => void;
  onExportHistory: () => void;
}

export const QueryHistory = ({ messages, onClearHistory, onExportHistory }: QueryHistoryProps) => {
  const userQueries = messages.filter(m => m.type === 'user');

  const formatTime = (date: Date) => {
    return date.toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <Card className="h-full shadow-glass">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <History className="h-5 w-5 text-primary" />
            Query History
          </CardTitle>
          <div className="flex gap-1">
            <Button
              variant="ghost"
              size="sm"
              onClick={onExportHistory}
              disabled={userQueries.length === 0}
            >
              <Download className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={onClearHistory}
              disabled={userQueries.length === 0}
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        </div>
        <p className="text-sm text-muted-foreground">
          {userQueries.length} queries tracked
        </p>
      </CardHeader>
      
      <CardContent className="p-0">
        <ScrollArea className="h-80 p-4">
          {userQueries.length === 0 ? (
            <div className="text-center py-8">
              <Clock className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
              <p className="text-sm text-muted-foreground">No queries yet</p>
              <p className="text-xs text-muted-foreground mt-1">
                Start asking questions to see your history
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {userQueries.map((query, index) => (
                <div
                  key={query.id}
                  className="p-3 border rounded-lg hover:bg-accent/50 transition-colors cursor-pointer"
                >
                  <div className="flex items-start justify-between mb-2">
                    <span className="text-xs text-muted-foreground">
                      Query #{userQueries.length - index}
                    </span>
                    <span className="text-xs text-muted-foreground">
                      {formatTime(query.timestamp)}
                    </span>
                  </div>
                  <p className="text-sm line-clamp-2">{query.content}</p>
                </div>
              ))}
            </div>
          )}
        </ScrollArea>
      </CardContent>
    </Card>
  );
};