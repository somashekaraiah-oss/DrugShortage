import { NavLink, useLocation } from "react-router-dom";
import { 
  MessageSquare, 
  BarChart3, 
  Database, 
  FileText, 
  BookOpen, 
  Settings,
  Activity,
  TrendingUp
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
  useSidebar,
} from "@/components/ui/sidebar";
import { Logo } from "./Logo";

const navigationItems = [
  {
    title: "ShortageIQ",
    url: "/",
    icon: MessageSquare,
    description: "AI-Powered Drug Shortage Analysis"
  },
  {
    title: "Analytics",
    url: "/analytics",
    icon: BarChart3,
    description: "Executive Reports & Insights"
  },
  {
    title: "Data Management",
    url: "/data",
    icon: Database,
    description: "Synthetic Data & File Processing"
  },
  {
    title: "Knowledge Base",
    url: "/knowledge",
    icon: BookOpen,
    description: "TFT Model Documentation"
  },
  {
    title: "Settings",
    url: "/settings",
    icon: Settings,
    description: "Configuration & Preferences"
  }
];

export function AppSidebar() {
  const { state } = useSidebar();
  const location = useLocation();
  const currentPath = location.pathname;

  const isActive = (path: string) => {
    if (path === "/") {
      return currentPath === "/";
    }
    return currentPath.startsWith(path);
  };

  const getNavClasses = (path: string) => {
    const base = "w-full justify-start transition-all duration-200";
    if (isActive(path)) {
      return `${base} bg-gradient-primary text-white shadow-medical hover:bg-gradient-primary`;
    }
    return `${base} hover:bg-accent hover:text-accent-foreground`;
  };

  return (
    <Sidebar className="border-r border-border/50 bg-gradient-glass backdrop-blur-sm">
      <SidebarHeader className="p-4 border-b border-border/50">
        <div className="flex items-center gap-3">
          <Logo size="md" className="animate-float" />
          {state === "expanded" && (
            <div>
              <h2 className="font-bold text-lg bg-gradient-primary bg-clip-text text-transparent">
                ShortageIQ
              </h2>
              <p className="text-xs text-muted-foreground">Enterprise Intelligence</p>
            </div>
          )}
        </div>
      </SidebarHeader>

      <SidebarContent className="px-2">
        <SidebarGroup>
          <SidebarGroupLabel className="text-xs font-semibold text-muted-foreground px-2">
            Navigation
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu className="space-y-1">
              {navigationItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild>
                    <NavLink 
                      to={item.url} 
                      className={getNavClasses(item.url)}
                      title={item.description}
                    >
                      <item.icon className="h-4 w-4 shrink-0" />
                      {state === "expanded" && (
                        <div className="flex flex-col items-start">
                          <span className="font-medium">{item.title}</span>
                          <span className="text-xs opacity-70 truncate">
                            {item.description}
                          </span>
                        </div>
                      )}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {state === "expanded" && (
          <SidebarGroup className="mt-auto">
            <div className="px-3 py-2 rounded-lg bg-gradient-primary/10 border border-primary/20">
              <div className="flex items-center gap-2 text-primary mb-1">
                <TrendingUp className="h-4 w-4" />
                <span className="text-sm font-medium">System Status</span>
              </div>
              <div className="text-xs text-muted-foreground space-y-1">
                <div className="flex justify-between">
                  <span>Model Accuracy:</span>
                  <span className="text-success font-medium">85.3%</span>
                </div>
                <div className="flex justify-between">
                  <span>Active NDCs:</span>
                  <span className="font-medium">5</span>
                </div>
                <div className="flex justify-between">
                  <span>Last Update:</span>
                  <span className="font-medium">Real-time</span>
                </div>
              </div>
            </div>
          </SidebarGroup>
        )}
      </SidebarContent>

      <SidebarFooter className="p-4 border-t border-border/50">
        {state === "expanded" && (
          <div className="text-xs text-muted-foreground text-center">
            <p>© 2024 PharmaForecaster Pro</p>
            <p>Enterprise Drug Shortage Intelligence</p>
          </div>
        )}
      </SidebarFooter>
    </Sidebar>
  );
}