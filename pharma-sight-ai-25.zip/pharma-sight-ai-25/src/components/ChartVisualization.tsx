import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell } from "recharts";
import { TrendingUp, BarChart3, PieChart as PieChartIcon, Calendar } from "lucide-react";
import { NDCData } from "./SyntheticDataGenerator";
import { QueryIntent } from "@/utils/semanticMatching";

interface ChartVisualizationProps {
  data: NDCData[];
  selectedNDC?: string;
  queryIntent?: QueryIntent;
}

export const ChartVisualization = ({ data, selectedNDC, queryIntent }: ChartVisualizationProps) => {
  // Use query intent to determine chart parameters
  const forecastDays = queryIntent?.entities.timeRange || 30;
  const drugName = queryIntent?.entities?.drugs?.[0] || selectedNDC;
  
  // Generate forecast data for specified time range
  const generateForecastData = (ndc: NDCData, days: number = 30) => {
    const baseRisk = ndc.shortageFlag ? 0.8 : 0.2;
    const complianceImpact = (1 - ndc.complianceScore) * 0.5;
    const inspectionImpact = Math.min(ndc.inspectionGap / 365, 1) * 0.3;
    
    return Array.from({ length: days }, (_, i) => {
      const dayRisk = baseRisk + complianceImpact + inspectionImpact;
      const variance = Math.sin(i * 0.2) * 0.1;
      const trend = (ndc.forecastTrend / 100) * (i / days) * 0.2;
      
      return {
        day: i + 1,
        risk: Math.max(0, Math.min(1, dayRisk + variance + trend)),
        upperBound: Math.max(0, Math.min(1, dayRisk + variance + trend + 0.15)),
        lowerBound: Math.max(0, Math.min(1, dayRisk + variance + trend - 0.15)),
      };
    });
  };

  // Feature importance data
  const generateFeatureImportance = (ndc: NDCData) => [
    { feature: "Compliance Score", importance: 0.35, value: ndc.complianceScore },
    { feature: "Inspection Gap", importance: 0.28, value: ndc.inspectionGap / 365 },
    { feature: "Manufacturer Tier", importance: 0.22, value: (4 - ndc.manufacturerTier) / 3 },
    { feature: "Historical Shortages", importance: 0.15, value: ndc.shortageFlag ? 1 : 0 },
  ];

  // Risk distribution across all NDCs
  const riskDistribution = [
    { name: "Low Risk", value: data.filter(d => d.riskLevel === 'low').length, color: "#22c55e" },
    { name: "Medium Risk", value: data.filter(d => d.riskLevel === 'medium').length, color: "#eab308" },
    { name: "High Risk", value: data.filter(d => d.riskLevel === 'high').length, color: "#ef4444" },
  ];

  const currentNDC = drugName ? data.find(d => d.name.toLowerCase().includes(drugName.toLowerCase()) || d.id === drugName) || data[0] : data[0];
  const forecastData = generateForecastData(currentNDC, forecastDays);
  const featureImportance = generateFeatureImportance(currentNDC);

  // Determine default tab based on query intent
  const getDefaultTab = () => {
    if (!queryIntent) return "forecast";
    switch (queryIntent.type) {
      case 'forecast_request':
        return "forecast";
      case 'feature_importance':
        return "features";
      case 'comparison':
      case 'general':
        return "overview";
      default:
        return "forecast";
    }
  };

  return (
    <div className="w-full h-full overflow-hidden">
      <div className="p-4 border-b bg-card">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <TrendingUp className="h-4 w-4 text-primary" />
            <h3 className="font-medium text-sm">Analytics Dashboard</h3>
            {queryIntent && (
              <Badge variant="outline" className="text-xs">
                {queryIntent.type.replace('_', ' ')}
              </Badge>
            )}
          </div>
        </div>
        <p className="text-xs text-muted-foreground">
          {currentNDC.name} • {forecastDays}-day forecast
        </p>
      </div>
      
      <div className="px-4 py-2 h-full overflow-hidden">
        <Tabs defaultValue={getDefaultTab()} className="h-full">
          <TabsList className="grid w-full grid-cols-3 mb-3">
            <TabsTrigger value="forecast" className="text-xs">Forecast</TabsTrigger>
            <TabsTrigger value="features" className="text-xs">Features</TabsTrigger>
            <TabsTrigger value="overview" className="text-xs">Overview</TabsTrigger>
          </TabsList>
          
          <TabsContent value="forecast" className="mt-0 h-[280px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={forecastData} margin={{ top: 10, right: 20, left: 20, bottom: 50 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis 
                  dataKey="day" 
                  stroke="hsl(var(--foreground))"
                  fontSize={11}
                  tick={{ fontSize: 11, fill: "hsl(var(--foreground))" }}
                  axisLine={{ stroke: "hsl(var(--border))" }}
                  tickLine={{ stroke: "hsl(var(--border))" }}
                  label={{ value: 'Days', position: 'insideBottom', offset: -10, style: { textAnchor: 'middle', fontSize: '11px', fill: 'hsl(var(--foreground))' } }}
                  height={60}
                />
                <YAxis 
                  stroke="hsl(var(--foreground))"
                  fontSize={11}
                  tick={{ fontSize: 11, fill: "hsl(var(--foreground))" }}
                  axisLine={{ stroke: "hsl(var(--border))" }}
                  tickLine={{ stroke: "hsl(var(--border))" }}
                  domain={[0, 1]}
                  tickFormatter={(value) => `${(value * 100).toFixed(0)}%`}
                  label={{ value: 'Risk %', angle: -90, position: 'insideLeft', style: { textAnchor: 'middle', fontSize: '11px', fill: 'hsl(var(--foreground))' } }}
                  width={60}
                />
                <Tooltip 
                  contentStyle={{
                    backgroundColor: "hsl(var(--card))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: "6px",
                    fontSize: "12px"
                  }}
                  formatter={(value: number, name) => [
                    `${(value * 100).toFixed(1)}%`,
                    name === 'risk' ? 'Shortage Risk' : 
                    name === 'upperBound' ? 'Upper Bound' : 'Lower Bound'
                  ]}
                />
                <Line 
                  type="monotone" 
                  dataKey="upperBound" 
                  stroke="hsl(var(--muted-foreground))" 
                  strokeDasharray="5 5"
                  dot={false}
                />
                <Line 
                  type="monotone" 
                  dataKey="lowerBound" 
                  stroke="hsl(var(--muted-foreground))" 
                  strokeDasharray="5 5"
                  dot={false}
                />
                <Line 
                  type="monotone" 
                  dataKey="risk" 
                  stroke="hsl(var(--primary))" 
                  strokeWidth={2}
                  dot={{ fill: "hsl(var(--primary))", strokeWidth: 2, r: 3 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </TabsContent>
          
          <TabsContent value="features" className="mt-0 h-[320px]">
            <div className="mb-3">
              <h4 className="text-sm font-medium text-foreground">Feature Importance for {currentNDC.name}</h4>
              <p className="text-xs text-muted-foreground">Key factors driving shortage risk prediction model</p>
            </div>
            <div className="h-[260px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={featureImportance} layout="horizontal" margin={{ top: 10, right: 40, left: 130, bottom: 10 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.3} />
                  <XAxis 
                    type="number" 
                    stroke="hsl(var(--foreground))"
                    fontSize={11}
                    tick={{ fontSize: 11, fill: "hsl(var(--foreground))" }}
                    axisLine={{ stroke: "hsl(var(--border))" }}
                    tickLine={{ stroke: "hsl(var(--border))" }}
                    tickFormatter={(value) => `${(value * 100).toFixed(0)}%`}
                    domain={[0, 'dataMax']}
                  />
                  <YAxis 
                    type="category" 
                    dataKey="feature" 
                    stroke="hsl(var(--foreground))"
                    fontSize={11}
                    tick={{ fontSize: 11, fill: "hsl(var(--foreground))" }}
                    axisLine={{ stroke: "hsl(var(--border))" }}
                    tickLine={{ stroke: "hsl(var(--border))" }}
                    width={120}
                  />
                  <Tooltip 
                    contentStyle={{
                      backgroundColor: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "8px",
                      fontSize: "12px",
                      boxShadow: "0 4px 12px rgba(0,0,0,0.1)"
                    }}
                    formatter={(value: number, name: string) => [
                      `${(value * 100).toFixed(1)}%`, 
                      'Impact Score'
                    ]}
                    labelFormatter={(label) => `Feature: ${label}`}
                  />
                  <Bar 
                    dataKey="importance" 
                    fill="hsl(var(--primary))"
                    radius={[0, 4, 4, 0]}
                    opacity={0.8}
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </TabsContent>
          
          <TabsContent value="overview" className="mt-0 h-[280px]">
            <div className="h-full flex flex-col">
              <div className="mb-2">
                <h4 className="text-sm font-medium text-foreground">Portfolio Risk Distribution</h4>
                <p className="text-xs text-muted-foreground">Risk levels across {data.length} NDCs in portfolio</p>
              </div>
              <div className="flex-1">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={riskDistribution}
                      cx="50%"
                      cy="50%"
                      innerRadius={40}
                      outerRadius={80}
                      paddingAngle={3}
                      dataKey="value"
                    >
                      {riskDistribution.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip 
                      contentStyle={{
                        backgroundColor: "hsl(var(--card))",
                        border: "1px solid hsl(var(--border))",
                        borderRadius: "6px",
                        fontSize: "12px"
                      }}
                      formatter={(value: number, name) => [`${value} NDCs`, name]}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="flex justify-center gap-3 pt-2">
                {riskDistribution.map((item) => (
                  <div key={item.name} className="flex items-center gap-1">
                    <div 
                      className="w-2 h-2 rounded-full" 
                      style={{ backgroundColor: item.color }}
                    />
                    <span className="text-xs">{item.name}</span>
                  </div>
                ))}
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};