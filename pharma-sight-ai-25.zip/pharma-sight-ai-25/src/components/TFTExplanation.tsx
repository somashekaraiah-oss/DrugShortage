import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ChevronDown, Brain, Zap, Target, BarChart3, Eye } from "lucide-react";
import { useState } from "react";

export const TFTExplanation = () => {
  const [isOpen, setIsOpen] = useState(false);

  const features = [
    {
      icon: <Brain className="h-5 w-5" />,
      title: "Multi-Head Attention",
      description: "Analyzes complex relationships between different time periods and features simultaneously",
      color: "bg-primary",
    },
    {
      icon: <Zap className="h-5 w-5" />,
      title: "Gating Mechanisms", 
      description: "Selectively controls information flow, focusing on the most relevant features for each prediction",
      color: "bg-secondary",
    },
    {
      icon: <Target className="h-5 w-5" />,
      title: "Quantile Forecasting",
      description: "Provides uncertainty estimates with confidence intervals, not just point predictions",
      color: "bg-warning",
    },
    {
      icon: <BarChart3 className="h-5 w-5" />,
      title: "Feature Importance",
      description: "Identifies which factors (compliance, inspections, etc.) most impact shortage predictions",
      color: "bg-success",
    },
    {
      icon: <Eye className="h-5 w-5" />,
      title: "Interpretability",
      description: "Explains predictions through attention weights and feature attribution analysis",
      color: "bg-muted-foreground",
    },
  ];

  const architectureSteps = [
    "Input Encoding: Historical data, compliance scores, inspection records",
    "Static Enrichment: Manufacturer tier, drug category, regulatory history",
    "Temporal Processing: LSTM layers capture sequential patterns",
    "Attention Mechanism: Multi-head attention focuses on relevant time periods",
    "Feature Selection: Gating networks select important variables",
    "Quantile Outputs: Multiple prediction intervals with uncertainty bounds",
  ];

  return (
    <Card className="shadow-glass">
      <Collapsible open={isOpen} onOpenChange={setIsOpen}>
        <CollapsibleTrigger asChild>
          <CardHeader className="cursor-pointer hover:bg-accent/50 transition-colors">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Brain className="h-5 w-5 text-primary" />
                Temporal Fusion Transformer (TFT) Explained
              </CardTitle>
              <Button variant="ghost" size="sm">
                <ChevronDown className={`h-4 w-4 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
              </Button>
            </div>
          </CardHeader>
        </CollapsibleTrigger>
        
        <CollapsibleContent>
          <CardContent className="space-y-6">
            {/* Overview */}
            <div className="p-4 bg-gradient-glass rounded-lg border">
              <h3 className="font-semibold mb-2 text-primary">What is TFT?</h3>
              <p className="text-sm text-muted-foreground">
                Temporal Fusion Transformer is a state-of-the-art deep learning architecture specifically designed 
                for multi-horizon forecasting. It combines the strengths of LSTMs for sequential modeling with 
                transformer attention mechanisms for capturing complex temporal dependencies.
              </p>
            </div>

            {/* Key Features */}
            <div>
              <h3 className="font-semibold mb-3">Key Features</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {features.map((feature, index) => (
                  <div key={index} className="p-3 border rounded-lg hover:shadow-chart transition-shadow">
                    <div className="flex items-start gap-3">
                      <div className={`p-2 rounded-full ${feature.color} text-white`}>
                        {feature.icon}
                      </div>
                      <div>
                        <h4 className="font-medium text-sm">{feature.title}</h4>
                        <p className="text-xs text-muted-foreground mt-1">{feature.description}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Architecture Flow */}
            <div>
              <h3 className="font-semibold mb-3">Architecture Flow</h3>
              <div className="space-y-2">
                {architectureSteps.map((step, index) => (
                  <div key={index} className="flex items-center gap-3 p-2 rounded border-l-2 border-primary/20">
                    <Badge variant="outline" className="text-xs">
                      {index + 1}
                    </Badge>
                    <span className="text-sm">{step}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Drug Shortage Application */}
            <div className="p-4 bg-primary/5 rounded-lg border border-primary/20">
              <h3 className="font-semibold mb-2 text-primary">Application to Drug Shortages</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                <div>
                  <h4 className="font-medium mb-2">Input Features:</h4>
                  <ul className="space-y-1 text-muted-foreground">
                    <li>• Historical shortage patterns</li>
                    <li>• FDA inspection records</li>
                    <li>• Compliance scores</li>
                    <li>• Manufacturing capacity</li>
                    <li>• Supply chain disruptions</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-medium mb-2">Outputs:</h4>
                  <ul className="space-y-1 text-muted-foreground">
                    <li>• 30-day shortage probability</li>
                    <li>• Confidence intervals</li>
                    <li>• Feature importance scores</li>
                    <li>• Risk level classifications</li>
                    <li>• Attention weight visualizations</li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Technical Details */}
            <div className="text-xs text-muted-foreground p-3 bg-muted/20 rounded border">
              <strong>Technical Implementation:</strong> The model uses variable selection networks to identify 
              relevant features, applies multi-head attention across time steps, and outputs quantile predictions 
              at the 10th, 50th, and 90th percentiles. This enables robust uncertainty quantification crucial 
              for pharmaceutical supply chain risk management.
            </div>
          </CardContent>
        </CollapsibleContent>
      </Collapsible>
    </Card>
  );
};