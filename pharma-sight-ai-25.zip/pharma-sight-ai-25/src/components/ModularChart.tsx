// Modular Chart Component - Decoupled from Chat Interface
// Supports multiple chart types with configurable data processing

import { useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  PieChart, 
  Pie, 
  Cell,
  AreaChart,
  Area,
  Legend,
  ComposedChart
} from "recharts";
import { 
  TrendingUp, 
  BarChart3, 
  PieChart as PieChartIcon, 
  Download,
  Settings,
  RefreshCw,
  Maximize2
} from "lucide-react";
import { useChartData, ChartConfig } from "@/hooks/useChartData";
import { NDCData } from "./SyntheticDataGenerator";
import { QueryIntent } from "@/utils/semanticMatching";

interface ModularChartProps {
  data: NDCData[];
  selectedNDC?: string;
  queryIntent?: QueryIntent;
  initialConfig?: Partial<ChartConfig>;
  onConfigChange?: (config: ChartConfig) => void;
  className?: string;
}

export const ModularChart = ({ 
  data, 
  selectedNDC, 
  queryIntent, 
  initialConfig = {},
  onConfigChange,
  className = ""
}: ModularChartProps) => {
  // Chart configuration with intelligent defaults based on query intent
  const config: ChartConfig = useMemo(() => {
    const baseConfig: ChartConfig = {
      type: 'line',
      timeRange: 30,
      showConfidence: true,
      showFeatures: false,
      selectedDrug: selectedNDC,
      compareMode: false,
      comparisonDrugs: [],
      ...initialConfig
    };

    // Adjust config based on query intent
    if (queryIntent) {
      if (queryIntent.type === 'forecast_request') {
        baseConfig.type = 'line';
        baseConfig.timeRange = queryIntent.entities.timeRange || 30;
        baseConfig.showConfidence = true;
      } else if (queryIntent.type === 'feature_importance') {
        baseConfig.type = 'bar';
        baseConfig.showFeatures = true;
      } else if (queryIntent.type === 'comparison') {
        baseConfig.compareMode = true;
        baseConfig.comparisonDrugs = queryIntent.entities.comparisonTarget || [];
      }
    }

    return baseConfig;
  }, [selectedNDC, queryIntent, initialConfig]);

  // Get processed chart data
  const { 
    data: chartData, 
    loading, 
    error, 
    comparisonData,
    exportData,
    refreshData 
  } = useChartData(data, config, queryIntent);

  // Handle configuration changes
  const updateConfig = (updates: Partial<ChartConfig>) => {
    const newConfig = { ...config, ...updates };
    onConfigChange?.(newConfig);
  };

  // Get appropriate chart title based on configuration
  const getChartTitle = () => {
    if (config.compareMode && comparisonData) {
      return `Comparison: ${comparisonData.map(d => d?.name.split(' ')[0]).join(' vs ')}`;
    }
    
    const drugName = config.selectedDrug 
      ? data.find(d => d.id === config.selectedDrug || d.name.toLowerCase().includes(config.selectedDrug!.toLowerCase()))?.name
      : 'Portfolio';
    
    switch (config.type) {
      case 'line':
        return `${config.timeRange}-Day Forecast: ${drugName?.split(' ')[0] || 'Portfolio'}`;
      case 'bar':
        return `Feature Analysis: ${drugName?.split(' ')[0] || 'Portfolio'}`;
      case 'pie':
        return 'Risk Distribution';
      case 'area':
        return `Trend Analysis: ${drugName?.split(' ')[0] || 'Portfolio'}`;
      default:
        return 'Analytics Dashboard';
    }
  };

  // Render forecast chart (line/area)
  const renderForecastChart = () => {
    const ChartComponent = config.type === 'area' ? AreaChart : LineChart;

    return (
      <ResponsiveContainer width="100%" height="100%">
        <ChartComponent data={chartData.forecast} margin={{ top: 10, right: 20, left: 20, bottom: 50 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
          <XAxis 
            dataKey="day" 
            stroke="hsl(var(--foreground))"
            fontSize={11}
            tick={{ fontSize: 11, fill: "hsl(var(--foreground))" }}
            label={{ value: 'Days', position: 'insideBottom', offset: -10, style: { textAnchor: 'middle', fontSize: '11px' } }}
          />
          <YAxis 
            stroke="hsl(var(--foreground))"
            fontSize={11}
            tick={{ fontSize: 11, fill: "hsl(var(--foreground))" }}
            domain={[0, 1]}
            tickFormatter={(value) => `${(value * 100).toFixed(0)}%`}
            label={{ value: 'Risk %', angle: -90, position: 'insideLeft', style: { textAnchor: 'middle', fontSize: '11px' } }}
          />
          <Tooltip 
            contentStyle={{
              backgroundColor: "hsl(var(--card))",
              border: "1px solid hsl(var(--border))",
              borderRadius: "6px",
              fontSize: "12px"
            }}
            formatter={(value: number, name) => [
              `${(value * 100).toFixed(1)}%`,
              name === 'risk' ? 'Shortage Risk' : 
              name === 'upperBound' ? 'Upper Bound' : 'Lower Bound'
            ]}
          />
          
          {config.showConfidence && config.type === 'line' && (
            <>
              <Line 
                type="monotone" 
                dataKey="upperBound" 
                stroke="hsl(var(--muted-foreground))" 
                strokeDasharray="5 5"
                dot={false}
              />
              <Line 
                type="monotone" 
                dataKey="lowerBound" 
                stroke="hsl(var(--muted-foreground))" 
                strokeDasharray="5 5"
                dot={false}
              />
            </>
          )}
          
          {config.type === 'area' ? (
            <Area 
              type="monotone" 
              dataKey="risk" 
              stroke="hsl(var(--primary))" 
              strokeWidth={2}
              fill="hsl(var(--primary))"
              fillOpacity={0.3}
            />
          ) : (
            <Line 
              type="monotone" 
              dataKey="risk" 
              stroke="hsl(var(--primary))" 
              strokeWidth={2}
              dot={{ fill: "hsl(var(--primary))", strokeWidth: 2, r: 3 }}
            />
          )}
        </ChartComponent>
      </ResponsiveContainer>
    );
  };

  // Render feature importance chart
  const renderFeatureChart = () => (
    <ResponsiveContainer width="100%" height="100%">
      <BarChart data={chartData.features} layout="horizontal" margin={{ top: 10, right: 40, left: 130, bottom: 10 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.3} />
        <XAxis 
          type="number" 
          stroke="hsl(var(--foreground))"
          fontSize={11}
          tickFormatter={(value) => `${(value * 100).toFixed(0)}%`}
          domain={[0, 'dataMax']}
        />
        <YAxis 
          type="category" 
          dataKey="feature" 
          stroke="hsl(var(--foreground))"
          fontSize={11}
          width={120}
        />
        <Tooltip 
          contentStyle={{
            backgroundColor: "hsl(var(--card))",
            border: "1px solid hsl(var(--border))",
            borderRadius: "8px",
            fontSize: "12px"
          }}
          formatter={(value: number) => [`${(value * 100).toFixed(1)}%`, 'Impact Score']}
        />
        <Bar 
          dataKey="importance" 
          fill="hsl(var(--primary))"
          radius={[0, 4, 4, 0]}
          opacity={0.8}
        />
      </BarChart>
    </ResponsiveContainer>
  );

  // Render risk distribution pie chart
  const renderDistributionChart = () => (
    <ResponsiveContainer width="100%" height="100%">
      <PieChart>
        <Pie
          data={chartData.riskDistribution}
          cx="50%"
          cy="50%"
          innerRadius={40}
          outerRadius={80}
          paddingAngle={3}
          dataKey="value"
        >
          {chartData.riskDistribution.map((entry, index) => (
            <Cell key={`cell-${index}`} fill={entry.color} />
          ))}
        </Pie>
        <Tooltip 
          contentStyle={{
            backgroundColor: "hsl(var(--card))",
            border: "1px solid hsl(var(--border))",
            borderRadius: "6px",
            fontSize: "12px"
          }}
          formatter={(value: number, name) => [`${value} NDCs`, name]}
        />
        <Legend />
      </PieChart>
    </ResponsiveContainer>
  );

  // Render comparison chart
  const renderComparisonChart = () => {
    if (!comparisonData || comparisonData.length < 2) return null;

    const combinedData = comparisonData[0]?.forecast.map((_, index) => {
      const dataPoint: any = { day: index + 1 };
      comparisonData.forEach((drug, drugIndex) => {
        if (drug?.forecast[index]) {
          dataPoint[`risk_${drugIndex}`] = drug.forecast[index].risk;
        }
      });
      return dataPoint;
    }) || [];

    return (
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={combinedData} margin={{ top: 10, right: 20, left: 20, bottom: 50 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
          <XAxis 
            dataKey="day" 
            stroke="hsl(var(--foreground))"
            fontSize={11}
            label={{ value: 'Days', position: 'insideBottom', offset: -10 }}
          />
          <YAxis 
            stroke="hsl(var(--foreground))"
            fontSize={11}
            domain={[0, 1]}
            tickFormatter={(value) => `${(value * 100).toFixed(0)}%`}
            label={{ value: 'Risk %', angle: -90, position: 'insideLeft' }}
          />
          <Tooltip 
            contentStyle={{
              backgroundColor: "hsl(var(--card))",
              border: "1px solid hsl(var(--border))",
              borderRadius: "6px",
              fontSize: "12px"
            }}
          />
          <Legend />
          
          {comparisonData.map((drug, index) => (
            drug && (
              <Line
                key={index}
                type="monotone"
                dataKey={`risk_${index}`}
                stroke={index === 0 ? "hsl(var(--primary))" : "hsl(var(--secondary))"}
                strokeWidth={2}
                name={drug.name.split(' ')[0]}
                dot={{ r: 3 }}
              />
            )
          ))}
        </LineChart>
      </ResponsiveContainer>
    );
  };

  // Get current chart content
  const getCurrentChart = () => {
    if (config.compareMode && comparisonData) {
      return renderComparisonChart();
    }

    switch (config.type) {
      case 'line':
      case 'area':
        return renderForecastChart();
      case 'bar':
        return renderFeatureChart();
      case 'pie':
        return renderDistributionChart();
      default:
        return renderForecastChart();
    }
  };

  return (
    <Card className={`h-full flex flex-col ${className}`}>
      <CardHeader className="flex-shrink-0 pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            {config.type === 'line' || config.type === 'area' ? (
              <TrendingUp className="h-4 w-4 text-primary" />
            ) : config.type === 'bar' ? (
              <BarChart3 className="h-4 w-4 text-primary" />
            ) : (
              <PieChartIcon className="h-4 w-4 text-primary" />
            )}
            <CardTitle className="text-sm font-medium">{getChartTitle()}</CardTitle>
            {queryIntent && (
              <Badge variant="outline" className="text-xs">
                {queryIntent.type.replace('_', ' ')}
              </Badge>
            )}
          </div>
          
          <div className="flex items-center gap-2">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={refreshData}
              disabled={loading}
            >
              <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
            </Button>
            
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => {
                const data = exportData('json');
                const blob = new Blob([data], { type: 'application/json' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `chart-data-${new Date().toISOString().split('T')[0]}.json`;
                a.click();
              }}
            >
              <Download className="h-4 w-4" />
            </Button>
          </div>
        </div>
        
        {/* Chart Configuration Controls */}
        <div className="flex items-center gap-4 pt-2">
          <div className="flex items-center gap-2">
            <Label htmlFor="confidence" className="text-xs">Confidence Bands</Label>
            <Switch
              id="confidence"
              checked={config.showConfidence}
              onCheckedChange={(checked) => updateConfig({ showConfidence: checked })}
            />
          </div>
          
          {!config.compareMode && (
            <div className="flex items-center gap-2">
              <Label htmlFor="features" className="text-xs">Feature Mode</Label>
              <Switch
                id="features"
                checked={config.type === 'bar'}
                onCheckedChange={(checked) => updateConfig({ type: checked ? 'bar' : 'line' })}
              />
            </div>
          )}
        </div>
      </CardHeader>

      <CardContent className="flex-1 p-0 overflow-hidden">
        {error ? (
          <div className="flex items-center justify-center h-full text-red-500">
            <p className="text-sm">Error loading chart data: {error}</p>
          </div>
        ) : (
          <div className="h-full p-4">
            {getCurrentChart()}
          </div>
        )}
      </CardContent>
    </Card>
  );
};