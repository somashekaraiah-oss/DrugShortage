import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { FileText, Download, TrendingUp, AlertTriangle, CheckCircle } from "lucide-react";
import { NDCData } from "./SyntheticDataGenerator";
import { ChatMessage } from "./ChatInterface";

interface ExecutiveSummaryProps {
  data: NDCData[];
  messages: ChatMessage[];
  onExport: () => void;
}

export const ExecutiveSummary = ({ data, messages, onExport }: ExecutiveSummaryProps) => {
  const generateExecutiveSummary = () => {
    const totalNDCs = data.length;
    const highRiskCount = data.filter(d => d.riskLevel === 'high').length;
    const mediumRiskCount = data.filter(d => d.riskLevel === 'medium').length;
    const lowRiskCount = data.filter(d => d.riskLevel === 'low').length;
    
    const averageCompliance = (data.reduce((sum, ndc) => sum + ndc.complianceScore, 0) / totalNDCs * 100);
    const averageInspectionGap = Math.round(data.reduce((sum, ndc) => sum + ndc.inspectionGap, 0) / totalNDCs);
    
    const criticalNDCs = data.filter(d => d.riskLevel === 'high' && d.complianceScore < 0.7);
    const shortageFlags = data.filter(d => d.shortageFlag).length;
    
    const queryCount = messages.filter(m => m.type === 'user').length;
    
    return {
      totalNDCs,
      highRiskCount,
      mediumRiskCount,
      lowRiskCount,
      averageCompliance,
      averageInspectionGap,
      criticalNDCs: criticalNDCs.length,
      shortageFlags,
      queryCount,
      riskDistribution: {
        high: (highRiskCount / totalNDCs * 100),
        medium: (mediumRiskCount / totalNDCs * 100),
        low: (lowRiskCount / totalNDCs * 100),
      },
    };
  };

  const summary = generateExecutiveSummary();
  
  const executiveNarrative = `
Based on our AI-powered Temporal Fusion Transformer analysis of ${summary.totalNDCs} National Drug Codes (NDCs), we've identified ${summary.highRiskCount} high-risk medications requiring immediate attention. 

**Key Findings:**
• **Compliance Status**: Average compliance score of ${summary.averageCompliance.toFixed(1)}% across all monitored NDCs
• **Inspection Oversight**: Average inspection gap of ${summary.averageInspectionGap} days, with ${data.filter(d => d.inspectionGap > 180).length} NDCs exceeding 180-day threshold
• **Active Shortages**: ${summary.shortageFlags} NDCs currently flagged for shortage events
• **Critical Interventions**: ${summary.criticalNDCs} NDCs require immediate corrective action due to combined risk factors

**30-Day Forecast**: Our TFT model predicts ${data.filter(d => d.forecastTrend > 5).length} NDCs showing increasing shortage risk trends, while ${data.filter(d => d.forecastTrend < -5).length} NDCs demonstrate improving supply stability.

**Recommended Actions**: Prioritize compliance enhancement for high-risk NDCs, accelerate inspection schedules for overdue facilities, and activate alternative sourcing protocols for flagged medications.
  `.trim();

  const riskLevelColor = (level: string) => {
    switch (level) {
      case 'high': return 'destructive' as const;
      case 'medium': return 'secondary' as const;
      default: return 'outline' as const;
    }
  };

  return (
    <Card className="shadow-medical">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5 text-primary" />
            Executive Summary
          </CardTitle>
          <Button variant="medical" size="sm" onClick={onExport}>
            <Download className="h-4 w-4 mr-2" />
            Export Report
          </Button>
        </div>
        <p className="text-sm text-muted-foreground">
          AI-Generated Risk Assessment & Forecasting Analysis
        </p>
      </CardHeader>
      
      <CardContent className="space-y-6">
        {/* Key Metrics Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="p-3 border rounded-lg text-center">
            <div className="text-2xl font-bold text-primary">{summary.totalNDCs}</div>
            <div className="text-xs text-muted-foreground">Total NDCs</div>
          </div>
          
          <div className="p-3 border rounded-lg text-center">
            <div className="text-2xl font-bold text-destructive">{summary.highRiskCount}</div>
            <div className="text-xs text-muted-foreground">High Risk</div>
          </div>
          
          <div className="p-3 border rounded-lg text-center">
            <div className="text-2xl font-bold text-primary">{summary.averageCompliance.toFixed(0)}%</div>
            <div className="text-xs text-muted-foreground">Avg Compliance</div>
          </div>
          
          <div className="p-3 border rounded-lg text-center">
            <div className="text-2xl font-bold text-secondary">{summary.queryCount}</div>
            <div className="text-xs text-muted-foreground">AI Queries</div>
          </div>
        </div>

        {/* Risk Distribution */}
        <div>
          <h3 className="font-semibold mb-3 flex items-center gap-2">
            <TrendingUp className="h-4 w-4" />
            Risk Distribution
          </h3>
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Badge variant={riskLevelColor('high')} className="w-16 justify-center">High</Badge>
                <span className="text-sm">{summary.highRiskCount} NDCs</span>
              </div>
              <span className="text-sm font-mono">{summary.riskDistribution.high.toFixed(1)}%</span>
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Badge variant={riskLevelColor('medium')} className="w-16 justify-center">Medium</Badge>
                <span className="text-sm">{summary.mediumRiskCount} NDCs</span>
              </div>
              <span className="text-sm font-mono">{summary.riskDistribution.medium.toFixed(1)}%</span>
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Badge variant={riskLevelColor('low')} className="w-16 justify-center">Low</Badge>
                <span className="text-sm">{summary.lowRiskCount} NDCs</span>
              </div>
              <span className="text-sm font-mono">{summary.riskDistribution.low.toFixed(1)}%</span>
            </div>
          </div>
        </div>

        {/* Executive Narrative */}
        <div className="p-4 bg-gradient-glass border rounded-lg">
          <h3 className="font-semibold mb-3 flex items-center gap-2">
            <FileText className="h-4 w-4" />
            Executive Summary
          </h3>
          <div className="prose prose-sm max-w-none">
            <p className="text-sm leading-relaxed whitespace-pre-line">
              {executiveNarrative}
            </p>
          </div>
        </div>

        {/* Critical Actions */}
        <div>
          <h3 className="font-semibold mb-3 flex items-center gap-2">
            <AlertTriangle className="h-4 w-4 text-destructive" />
            Immediate Actions Required
          </h3>
          <div className="space-y-2">
            {data.filter(d => d.riskLevel === 'high').slice(0, 3).map((ndc) => (
              <div key={ndc.id} className="p-3 border border-destructive/20 rounded-lg bg-destructive/5">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium text-sm">{ndc.name}</h4>
                    <p className="text-xs text-muted-foreground">{ndc.id}</p>
                  </div>
                  <Badge variant="destructive">URGENT</Badge>
                </div>
                <div className="mt-2 text-xs">
                  <span className="text-muted-foreground">
                    Compliance: {(ndc.complianceScore * 100).toFixed(1)}% • 
                    Inspection Gap: {ndc.inspectionGap} days
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Model Performance */}
        <div className="p-3 bg-primary/5 border border-primary/20 rounded-lg">
          <div className="flex items-center gap-2 mb-2">
            <CheckCircle className="h-4 w-4 text-primary" />
            <span className="font-medium text-sm">TFT Model Performance</span>
          </div>
          <div className="grid grid-cols-3 gap-4 text-xs">
            <div className="text-center">
              <div className="font-mono font-bold">85.3%</div>
              <div className="text-muted-foreground">Accuracy</div>
            </div>
            <div className="text-center">
              <div className="font-mono font-bold">±12%</div>
              <div className="text-muted-foreground">Confidence</div>
            </div>
            <div className="text-center">
              <div className="font-mono font-bold">30d</div>
              <div className="text-muted-foreground">Horizon</div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};