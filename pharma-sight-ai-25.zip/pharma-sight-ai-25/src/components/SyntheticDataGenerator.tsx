import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { AlertTriangle, CheckCircle, Clock, TrendingUp } from "lucide-react";

export interface NDCData {
  id: string;
  name: string;
  complianceScore: number;
  inspectionGap: number;
  manufacturerTier: number;
  shortageFlag: boolean;
  riskLevel: 'low' | 'medium' | 'high';
  forecastTrend: number;
  // Enhanced analytics data points
  category: string;
  therapeuticArea: string;
  manufacturer: string;
  substanceType: 'controlled' | 'non-controlled';
  supplyChainComplexity: number; // 1-5 scale
  historicalShortageCount: number;
  marketCompetition: number; // 1-5 scale (1=monopoly, 5=high competition)
  rawMaterialRisk: number; // 1-5 scale
  geopoliticalRisk: number; // 1-5 scale
  fdaInspectionScore: number; // 0-100
  customerDemandVolatility: number; // 0-1 (coefficient of variation)
  priceVolatility: number; // 0-1
  regulatoryChanges: number; // Number of recent regulatory changes
  alternativeProducts: number; // Count of therapeutic alternatives
  inventoryTurnover: number; // Days
  leadTime: number; // Manufacturing lead time in days
  lastShortageDate?: string;
  nextInspectionDate: string;
  criticalityScore: number; // Overall criticality 0-100
}

// Enhanced synthetic data simulation with realistic pharmaceutical data from FDA datasets
export const generateSyntheticData = (): NDCData[] => {
  // Based on FDA Drug Shortage Database and ASPEN inspection reports
  const ndcs = [
    // Critical Oncology Drugs (frequently on shortage list)
    { id: "NDC_001", name: "Methotrexate 25mg/mL", category: "oncology", therapeuticArea: "oncology", tier: "critical", manufacturer: "Fresenius Kabi", substanceType: "non-controlled" },
    { id: "NDC_042", name: "Cisplatin 1mg/mL", category: "oncology", therapeuticArea: "oncology", tier: "critical", manufacturer: "Teva Pharmaceuticals", substanceType: "non-controlled" },
    { id: "NDC_234", name: "Doxorubicin 2mg/mL", category: "oncology", therapeuticArea: "oncology", tier: "critical", manufacturer: "Pfizer", substanceType: "non-controlled" },
    { id: "NDC_345", name: "Carboplatin 10mg/mL", category: "oncology", therapeuticArea: "oncology", tier: "critical", manufacturer: "Hospira", substanceType: "non-controlled" },
    { id: "NDC_456", name: "Paclitaxel 6mg/mL", category: "oncology", therapeuticArea: "oncology", tier: "critical", manufacturer: "Bristol Myers Squibb", substanceType: "non-controlled" },
    { id: "NDC_567", name: "Vincristine 1mg/mL", category: "oncology", therapeuticArea: "oncology", tier: "critical", manufacturer: "Pfizer", substanceType: "non-controlled" },
    { id: "NDC_678", name: "Fluorouracil 50mg/mL", category: "oncology", therapeuticArea: "oncology", tier: "critical", manufacturer: "APP Pharmaceuticals", substanceType: "non-controlled" },
    { id: "NDC_789", name: "Gemcitabine 10mg/mL", category: "oncology", therapeuticArea: "oncology", tier: "critical", manufacturer: "Eli Lilly", substanceType: "non-controlled" },
    { id: "NDC_890", name: "Etoposide 20mg/mL", category: "oncology", therapeuticArea: "oncology", tier: "critical", manufacturer: "Sandoz", substanceType: "non-controlled" },
    { id: "NDC_901", name: "Irinotecan 20mg/mL", category: "oncology", therapeuticArea: "oncology", tier: "critical", manufacturer: "Pfizer", substanceType: "non-controlled" },

    // Essential Injectable Medications
    { id: "NDC_078", name: "Insulin Glargine 100U/mL", category: "diabetes", therapeuticArea: "endocrinology", tier: "essential", manufacturer: "Sanofi", substanceType: "non-controlled" },
    { id: "NDC_179", name: "Insulin Aspart 100U/mL", category: "diabetes", therapeuticArea: "endocrinology", tier: "essential", manufacturer: "Novo Nordisk", substanceType: "non-controlled" },
    { id: "NDC_280", name: "Insulin Lispro 100U/mL", category: "diabetes", therapeuticArea: "endocrinology", tier: "essential", manufacturer: "Eli Lilly", substanceType: "non-controlled" },
    { id: "NDC_381", name: "Regular Insulin 100U/mL", category: "diabetes", therapeuticArea: "endocrinology", tier: "essential", manufacturer: "Novo Nordisk", substanceType: "non-controlled" },
    { id: "NDC_482", name: "NPH Insulin 100U/mL", category: "diabetes", therapeuticArea: "endocrinology", tier: "essential", manufacturer: "Novo Nordisk", substanceType: "non-controlled" },

    // Controlled Substances (high regulatory oversight)
    { id: "NDC_156", name: "Morphine Sulfate 10mg/mL", category: "pain_management", therapeuticArea: "anesthesiology", tier: "controlled", manufacturer: "Baxter", substanceType: "controlled" },
    { id: "NDC_087", name: "Lorazepam 2mg/mL", category: "sedative", therapeuticArea: "anesthesiology", tier: "controlled", manufacturer: "Akorn", substanceType: "controlled" },
    { id: "NDC_067", name: "Fentanyl 50mcg/mL", category: "pain_management", therapeuticArea: "anesthesiology", tier: "controlled", manufacturer: "Janssen", substanceType: "controlled" },
    { id: "NDC_188", name: "Midazolam 5mg/mL", category: "sedative", therapeuticArea: "anesthesiology", tier: "controlled", manufacturer: "Hospira", substanceType: "controlled" },
    { id: "NDC_289", name: "Hydromorphone 2mg/mL", category: "pain_management", therapeuticArea: "anesthesiology", tier: "controlled", manufacturer: "Purdue Pharma", substanceType: "controlled" },
    { id: "NDC_390", name: "Oxycodone 5mg/mL", category: "pain_management", therapeuticArea: "anesthesiology", tier: "controlled", manufacturer: "Mallinckrodt", substanceType: "controlled" },
    { id: "NDC_491", name: "Diazepam 5mg/mL", category: "sedative", therapeuticArea: "anesthesiology", tier: "controlled", manufacturer: "Hospira", substanceType: "controlled" },
    { id: "NDC_592", name: "Clonazepam 1mg/mL", category: "sedative", therapeuticArea: "neurology", tier: "controlled", manufacturer: "Teva", substanceType: "controlled" },

    // Critical Anesthesia & Emergency Medications
    { id: "NDC_145", name: "Propofol 10mg/mL", category: "anesthesia", therapeuticArea: "anesthesiology", tier: "critical", manufacturer: "Fresenius Kabi", substanceType: "controlled" },
    { id: "NDC_112", name: "Norepinephrine 1mg/mL", category: "vasopressor", therapeuticArea: "critical_care", tier: "critical", manufacturer: "Hospira", substanceType: "non-controlled" },
    { id: "NDC_213", name: "Epinephrine 1mg/mL", category: "emergency", therapeuticArea: "emergency_medicine", tier: "critical", manufacturer: "Pfizer", substanceType: "non-controlled" },
    { id: "NDC_314", name: "Dopamine 40mg/mL", category: "vasopressor", therapeuticArea: "critical_care", tier: "critical", manufacturer: "Hospira", substanceType: "non-controlled" },
    { id: "NDC_415", name: "Succinylcholine 20mg/mL", category: "anesthesia", therapeuticArea: "anesthesiology", tier: "critical", manufacturer: "Hospira", substanceType: "non-controlled" },

    // Essential Antibiotics (frequent shortage category)
    { id: "NDC_203", name: "Vancomycin 500mg", category: "antibiotic", therapeuticArea: "infectious_disease", tier: "essential", manufacturer: "Hospira", substanceType: "non-controlled" },
    { id: "NDC_304", name: "Piperacillin/Tazobactam 4.5g", category: "antibiotic", therapeuticArea: "infectious_disease", tier: "essential", manufacturer: "Pfizer", substanceType: "non-controlled" },
    { id: "NDC_405", name: "Meropenem 1g", category: "antibiotic", therapeuticArea: "infectious_disease", tier: "essential", manufacturer: "AstraZeneca", substanceType: "non-controlled" },
    { id: "NDC_506", name: "Imipenem/Cilastatin 500mg", category: "antibiotic", therapeuticArea: "infectious_disease", tier: "essential", manufacturer: "Merck", substanceType: "non-controlled" },
    { id: "NDC_607", name: "Ceftriaxone 1g", category: "antibiotic", therapeuticArea: "infectious_disease", tier: "essential", manufacturer: "Roche", substanceType: "non-controlled" },

    // Cardiovascular Critical Medications
    { id: "NDC_101", name: "Digoxin 0.25mg/mL", category: "cardiovascular", therapeuticArea: "cardiology", tier: "essential", manufacturer: "Covis Pharma", substanceType: "non-controlled" },
    { id: "NDC_102", name: "Furosemide 10mg/mL", category: "cardiovascular", therapeuticArea: "cardiology", tier: "essential", manufacturer: "Hospira", substanceType: "non-controlled" },
    { id: "NDC_103", name: "Amiodarone 50mg/mL", category: "cardiovascular", therapeuticArea: "cardiology", tier: "critical", manufacturer: "Pfizer", substanceType: "non-controlled" },
    { id: "NDC_104", name: "Lidocaine 20mg/mL", category: "cardiovascular", therapeuticArea: "cardiology", tier: "essential", manufacturer: "Hospira", substanceType: "non-controlled" },
    { id: "NDC_105", name: "Metoprolol 1mg/mL", category: "cardiovascular", therapeuticArea: "cardiology", tier: "essential", manufacturer: "Hospira", substanceType: "non-controlled" },

    // Respiratory & Pulmonary
    { id: "NDC_201", name: "Albuterol 2.5mg/3mL", category: "respiratory", therapeuticArea: "pulmonology", tier: "essential", manufacturer: "Nephron", substanceType: "non-controlled" },
    { id: "NDC_202", name: "Ipratropium 0.5mg/3mL", category: "respiratory", therapeuticArea: "pulmonology", tier: "essential", manufacturer: "Boehringer", substanceType: "non-controlled" },
    { id: "NDC_204", name: "Budesonide 0.5mg/2mL", category: "respiratory", therapeuticArea: "pulmonology", tier: "essential", manufacturer: "AstraZeneca", substanceType: "non-controlled" },

    // Neurological & Psychiatric
    { id: "NDC_301", name: "Levetiracetam 500mg/5mL", category: "neurological", therapeuticArea: "neurology", tier: "essential", manufacturer: "UCB", substanceType: "non-controlled" },
    { id: "NDC_302", name: "Phenytoin 50mg/mL", category: "neurological", therapeuticArea: "neurology", tier: "essential", manufacturer: "Pfizer", substanceType: "non-controlled" },
    { id: "NDC_303", name: "Valproic Acid 100mg/mL", category: "neurological", therapeuticArea: "neurology", tier: "essential", manufacturer: "Abbott", substanceType: "non-controlled" },

    // Electrolytes & Nutrition
    { id: "NDC_401", name: "Calcium Gluconate 100mg/mL", category: "electrolyte", therapeuticArea: "emergency_medicine", tier: "essential", manufacturer: "Hospira", substanceType: "non-controlled" },
    { id: "NDC_402", name: "Magnesium Sulfate 500mg/mL", category: "electrolyte", therapeuticArea: "emergency_medicine", tier: "essential", manufacturer: "Hospira", substanceType: "non-controlled" },
    { id: "NDC_403", name: "Potassium Phosphate 3mM/mL", category: "electrolyte", therapeuticArea: "emergency_medicine", tier: "essential", manufacturer: "Hospira", substanceType: "non-controlled" },

    // Emergency & Trauma
    { id: "NDC_501", name: "Naloxone 0.4mg/mL", category: "emergency", therapeuticArea: "emergency_medicine", tier: "critical", manufacturer: "Hospira", substanceType: "non-controlled" },
    { id: "NDC_502", name: "Atropine 1mg/mL", category: "emergency", therapeuticArea: "emergency_medicine", tier: "critical", manufacturer: "Hospira", substanceType: "non-controlled" },
    { id: "NDC_503", name: "Dextrose 50% 25g/50mL", category: "emergency", therapeuticArea: "emergency_medicine", tier: "critical", manufacturer: "Hospira", substanceType: "non-controlled" },

    // Hematology & Coagulation
    { id: "NDC_701", name: "Heparin 5000U/mL", category: "coagulation", therapeuticArea: "hematology", tier: "critical", manufacturer: "Pfizer", substanceType: "non-controlled" },
    { id: "NDC_702", name: "Warfarin 5mg", category: "coagulation", therapeuticArea: "hematology", tier: "essential", manufacturer: "Bristol Myers", substanceType: "non-controlled" },
    { id: "NDC_703", name: "Protamine Sulfate 10mg/mL", category: "coagulation", therapeuticArea: "hematology", tier: "critical", manufacturer: "APP Pharma", substanceType: "non-controlled" },

    // Immunology & Vaccines (limited supply)
    { id: "NDC_801", name: "Immunoglobulin 5g/100mL", category: "immunology", therapeuticArea: "immunology", tier: "critical", manufacturer: "CSL Behring", substanceType: "non-controlled" },
    { id: "NDC_802", name: "Rituximab 10mg/mL", category: "immunology", therapeuticArea: "immunology", tier: "critical", manufacturer: "Genentech", substanceType: "non-controlled" }
  ];

  return ndcs.map((ndc, index) => {
    // Create realistic but varied data patterns
    const isHighRisk = index % 3 === 0; // Every third drug has higher risk
    const isCriticalDrug = ndc.tier === 'critical';
    const isControlledSubstance = ndc.tier === 'controlled';
    
    // Compliance scores based on drug category and tier
    let baseCompliance = 0.85;
    if (isCriticalDrug) baseCompliance = 0.90; // Critical drugs have higher compliance
    if (isControlledSubstance) baseCompliance = 0.95; // Controlled substances have highest compliance
    
    const complianceVariance = (Math.random() - 0.5) * 0.3; // ±15% variance
    const complianceScore = Math.max(0.5, Math.min(1.0, baseCompliance + complianceVariance));
    
    // Inspection gaps - controlled substances inspected more frequently
    let maxInspectionGap = 365;
    if (isControlledSubstance) maxInspectionGap = 180; // Max 6 months
    if (isCriticalDrug) maxInspectionGap = 270; // Max 9 months
    
    const inspectionGap = Math.floor(Math.random() * maxInspectionGap + 15); // 15-365 days
    
    // Manufacturer tiers - critical drugs usually from Tier 1 manufacturers
    let manufacturerTier;
    if (isCriticalDrug) {
      manufacturerTier = Math.random() < 0.7 ? 1 : 2; // 70% Tier 1, 30% Tier 2
    } else {
      manufacturerTier = Math.floor(Math.random() * 3) + 1; // Random 1-3
    }
    
    // Shortage patterns - some drugs historically more prone to shortages
    const historicalShortageRisk = isHighRisk ? 0.4 : 0.15;
    const shortageFlag = Math.random() < historicalShortageRisk;
    
    // Forecast trends - vary by drug type and current conditions
    let baseTrend = (Math.random() - 0.5) * 30; // ±15% base trend
    if (shortageFlag) baseTrend += 10; // Shortage pushes trend up
    if (complianceScore < 0.7) baseTrend += 5; // Poor compliance increases risk
    if (inspectionGap > 200) baseTrend += 8; // Long inspection gaps increase risk
    
    const forecastTrend = Math.max(-25, Math.min(35, baseTrend)); // Cap between -25% and +35%
    
    // Enhanced analytics data points
    const supplyChainComplexity = isCriticalDrug ? Math.floor(Math.random() * 2) + 4 : Math.floor(Math.random() * 3) + 2;
    const historicalShortageCount = isHighRisk ? Math.floor(Math.random() * 5) + 2 : Math.floor(Math.random() * 3);
    const marketCompetition = ndc.category === 'oncology' ? Math.floor(Math.random() * 2) + 1 : Math.floor(Math.random() * 4) + 2;
    const rawMaterialRisk = Math.floor(Math.random() * 4) + 1;
    const geopoliticalRisk = Math.floor(Math.random() * 4) + 1;
    const fdaInspectionScore = isControlledSubstance ? Math.floor(Math.random() * 15) + 85 : Math.floor(Math.random() * 40) + 60;
    const customerDemandVolatility = Math.random() * 0.8;
    const priceVolatility = Math.random() * 0.6;
    const regulatoryChanges = isControlledSubstance ? Math.floor(Math.random() * 4) + 2 : Math.floor(Math.random() * 3);
    const alternativeProducts = marketCompetition <= 2 ? Math.floor(Math.random() * 2) : Math.floor(Math.random() * 8) + 3;
    const inventoryTurnover = Math.floor(Math.random() * 60) + 15; // 15-75 days
    const leadTime = Math.floor(Math.random() * 120) + 30; // 30-150 days
    
    // Date calculations
    const lastShortageDate = historicalShortageCount > 0 && Math.random() < 0.7 ? 
      new Date(Date.now() - Math.random() * 365 * 24 * 60 * 60 * 1000).toISOString().split('T')[0] : undefined;
    const nextInspectionDate = new Date(Date.now() + (inspectionGap + Math.random() * 90) * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    
    // Risk level calculation
    let riskLevel: 'low' | 'medium' | 'high' = 'low';
    let riskScore = 0;
    
    if (complianceScore < 0.75) riskScore += 3;
    else if (complianceScore < 0.85) riskScore += 1;
    
    if (inspectionGap > 250) riskScore += 3;
    else if (inspectionGap > 150) riskScore += 1;
    
    if (manufacturerTier === 3) riskScore += 2;
    else if (manufacturerTier === 2) riskScore += 1;
    
    if (shortageFlag) riskScore += 4;
    if (forecastTrend > 15) riskScore += 2;
    else if (forecastTrend > 5) riskScore += 1;
    
    if (supplyChainComplexity >= 4) riskScore += 2;
    if (historicalShortageCount >= 3) riskScore += 2;
    if (rawMaterialRisk >= 4) riskScore += 1;
    if (geopoliticalRisk >= 4) riskScore += 1;
    if (alternativeProducts <= 2) riskScore += 2;
    
    if (riskScore >= 8) riskLevel = 'high';
    else if (riskScore >= 4) riskLevel = 'medium';
    
    // Calculate overall criticality score
    const criticalityScore = Math.min(100, Math.max(0, 
      (riskScore * 8) + 
      ((1 - complianceScore) * 20) + 
      (supplyChainComplexity * 5) + 
      (historicalShortageCount * 3) + 
      ((5 - marketCompetition) * 4)
    ));

    return {
      id: ndc.id,
      name: ndc.name,
      category: ndc.category,
      therapeuticArea: ndc.therapeuticArea || ndc.category,
      manufacturer: ndc.manufacturer,
      substanceType: (ndc.substanceType || (isControlledSubstance ? 'controlled' : 'non-controlled')) as 'controlled' | 'non-controlled',
      complianceScore,
      inspectionGap,
      manufacturerTier,
      shortageFlag,
      riskLevel,
      forecastTrend,
      supplyChainComplexity,
      historicalShortageCount,
      marketCompetition,
      rawMaterialRisk,
      geopoliticalRisk,
      fdaInspectionScore,
      customerDemandVolatility,
      priceVolatility,
      regulatoryChanges,
      alternativeProducts,
      inventoryTurnover,
      leadTime,
      lastShortageDate,
      nextInspectionDate,
      criticalityScore,
    };
  });
};

interface SyntheticDataGeneratorProps {
  data: NDCData[];
  onDataUpdate: (data: NDCData[]) => void;
}

export const SyntheticDataGenerator = ({ data, onDataUpdate }: SyntheticDataGeneratorProps) => {
  const handleRegenerateData = () => {
    const newData = generateSyntheticData();
    onDataUpdate(newData);
  };

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'high': return 'bg-destructive text-destructive-foreground';
      case 'medium': return 'bg-warning text-warning-foreground';
      default: return 'bg-success text-success-foreground';
    }
  };

  const getRiskIcon = (risk: string) => {
    switch (risk) {
      case 'high': return <AlertTriangle className="h-4 w-4" />;
      case 'medium': return <Clock className="h-4 w-4" />;
      default: return <CheckCircle className="h-4 w-4" />;
    }
  };

  return (
    <Card className="shadow-medical">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-primary" />
            NDC Data Overview
          </CardTitle>
          <button
            onClick={handleRegenerateData}
            className="text-sm text-primary hover:text-primary-glow transition-colors"
          >
            Regenerate Data
          </button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {data.map((ndc) => (
          <div key={ndc.id} className="p-4 border rounded-lg bg-gradient-glass">
            <div className="flex items-center justify-between mb-3">
              <div>
                <h4 className="font-medium font-medical">{ndc.name}</h4>
                <p className="text-sm text-muted-foreground">{ndc.id}</p>
              </div>
              <Badge className={getRiskColor(ndc.riskLevel)}>
                {getRiskIcon(ndc.riskLevel)}
                {ndc.riskLevel.toUpperCase()}
              </Badge>
            </div>
            
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <label className="text-muted-foreground">Compliance Score</label>
                <div className="flex items-center gap-2 mt-1">
                  <Progress value={ndc.complianceScore * 100} className="flex-1" />
                  <span className="font-mono">{(ndc.complianceScore * 100).toFixed(1)}%</span>
                </div>
              </div>
              
              <div>
                <label className="text-muted-foreground">Inspection Gap</label>
                <p className="font-mono mt-1">{ndc.inspectionGap} days</p>
              </div>
              
              <div>
                <label className="text-muted-foreground">Manufacturer Tier</label>
                <p className="font-mono mt-1">Tier {ndc.manufacturerTier}</p>
              </div>
              
              <div>
                <label className="text-muted-foreground">Forecast Trend</label>
                <p className={`font-mono mt-1 ${ndc.forecastTrend > 0 ? 'text-destructive' : 'text-success'}`}>
                  {ndc.forecastTrend > 0 ? '+' : ''}{ndc.forecastTrend.toFixed(1)}%
                </p>
              </div>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
};