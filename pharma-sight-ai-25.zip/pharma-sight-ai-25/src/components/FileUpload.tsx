import { useCallback, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Upload, FileText, X, CheckCircle, AlertTriangle, TrendingUp } from "lucide-react";
import { NDCData } from "./SyntheticDataGenerator";
import { parseReport, ReportAnalysis } from "@/utils/reportParser";

interface UploadedFile {
  id: string;
  name: string;
  type: string;
  content: string;
  processed: boolean;
  analysis?: ReportAnalysis;
}

interface FileUploadProps {
  onFileProcessed: (impact: { 
    ndcId: string; 
    compliance: number; 
    risk: string;
    analysis: ReportAnalysis;
  }) => void;
  data: NDCData[];
}

export const FileUpload = ({ onFileProcessed, data }: FileUploadProps) => {
  const [dragActive, setDragActive] = useState(false);
  const [files, setFiles] = useState<UploadedFile[]>([]);
  const { toast } = useToast();

  const processFile = useCallback((file: File): Promise<UploadedFile> => {
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const content = e.target?.result as string;
        
        // Simulate FDA Form 483 or ASHP report processing
        const uploadedFile: UploadedFile = {
          id: Math.random().toString(36).substr(2, 9),
          name: file.name,
          type: file.type,
          content,
          processed: false,
        };

        // Simulate processing delay
        setTimeout(() => {
          uploadedFile.processed = true;
          
          // Parse the report using enhanced parser
          const analysis = parseReport(content, file.name);
          uploadedFile.analysis = analysis;
          
          // Determine affected NDC - prefer extracted NDCs, fallback to random
          let targetNDC;
          if (analysis.affectedNDCs.length > 0) {
            const extractedId = analysis.affectedNDCs[0];
            targetNDC = data.find(ndc => ndc.id === extractedId) || data[Math.floor(Math.random() * data.length)];
          } else {
            targetNDC = data[Math.floor(Math.random() * data.length)];
          }
          
          const impact = {
            ndcId: targetNDC.id,
            compliance: analysis.complianceImpact,
            risk: analysis.severity === 'critical' || analysis.severity === 'high' ? 'increased' : 'decreased',
            analysis,
          };
          
          onFileProcessed(impact);
          
          toast({
            title: "Report Processed",
            description: `${file.name} analyzed. ${analysis.findings.length} findings identified. Impact on ${targetNDC.id}: ${impact.risk} risk.`,
          });
          
          resolve(uploadedFile);
        }, 2000);
      };
      reader.readAsText(file);
    });
  }, [data, onFileProcessed, toast]);

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  }, []);

  const handleDrop = useCallback(async (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    const droppedFiles = Array.from(e.dataTransfer.files);
    await handleFiles(droppedFiles);
  }, []);

  const handleFiles = async (fileList: File[]) => {
    const textFiles = fileList.filter(file => 
      file.type.startsWith('text/') || 
      file.name.endsWith('.txt') || 
      file.name.endsWith('.pdf') ||
      file.name.endsWith('.doc')
    );

    if (textFiles.length === 0) {
      toast({
        title: "Invalid File Type",
        description: "Please upload text files, PDFs, or documents.",
        variant: "destructive",
      });
      return;
    }

    for (const file of textFiles) {
      try {
        const uploadedFile = await processFile(file);
        setFiles(prev => [...prev, uploadedFile]);
      } catch (error) {
        toast({
          title: "Upload Error",
          description: `Failed to process ${file.name}`,
          variant: "destructive",
        });
      }
    }
  };

  const removeFile = (id: string) => {
    setFiles(prev => prev.filter(f => f.id !== id));
  };

  const sampleReports = [
    "FDA Form 483 - Sterile Manufacturing Violations",
    "ASHP Drug Shortage Report - Q4 2024",
    "Manufacturing Compliance Assessment",
    "Quality System Inspection Report",
  ];

  const createSampleReport = (title: string) => {
    const sampleContent = `SAMPLE REPORT: ${title}

Date: ${new Date().toLocaleDateString()}
Inspector: FDA Compliance Officer

OBSERVATIONS:
${title.includes('Violations') ? `
1. VIOLATION: Inadequate cleaning validation for sterile manufacturing equipment
2. DEFICIENCY: Incomplete batch records for critical manufacturing steps  
3. OBSERVATION: Insufficient environmental monitoring in sterile areas
` : title.includes('Shortage') ? `
1. Current shortage status for multiple oncology drugs
2. Manufacturing delays due to raw material sourcing
3. Alternative supplier qualification in progress
` : `
1. Compliance with current Good Manufacturing Practices (cGMP)
2. Quality system effectiveness review
3. Risk assessment procedures evaluation
`}

IMPACT ASSESSMENT:
${title.includes('Violations') || title.includes('Shortage') ? 
'HIGH RISK - Immediate corrective action required' : 
'MEDIUM RISK - Monitor and verify improvements'}

This is a simulated report for demonstration purposes.`;

    const blob = new Blob([sampleContent], { type: 'text/plain' });
    const file = new File([blob], `${title.replace(/\s+/g, '_')}.txt`, { type: 'text/plain' });
    handleFiles([file]);
  };

  return (
    <Card className="shadow-glass">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Upload className="h-5 w-5 text-primary" />
          Document Upload
        </CardTitle>
        <p className="text-sm text-muted-foreground">
          Upload FDA Form 483s, ASHP reports, or compliance documents
        </p>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {/* Upload Area */}
        <div
          className={`border-2 border-dashed rounded-lg p-6 text-center transition-all duration-300 ${
            dragActive
              ? "border-primary bg-primary/5 scale-105"
              : "border-muted-foreground/25 hover:border-primary/50"
          }`}
          onDragEnter={handleDrag}
          onDragLeave={handleDrag}
          onDragOver={handleDrag}
          onDrop={handleDrop}
        >
          <Upload className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
          <p className="text-sm text-muted-foreground mb-2">
            Drag and drop files here, or click to select
          </p>
          <input
            type="file"
            multiple
            accept=".txt,.pdf,.doc,.docx"
            onChange={(e) => handleFiles(Array.from(e.target.files || []))}
            className="hidden"
            id="file-upload"
          />
          <label htmlFor="file-upload">
            <Button variant="outline" size="sm" className="cursor-pointer">
              Choose Files
            </Button>
          </label>
        </div>

        {/* Sample Reports */}
        <div>
          <p className="text-sm font-medium mb-2">Try Sample Reports:</p>
          <div className="grid grid-cols-1 gap-2">
            {sampleReports.map((title) => (
              <Button
                key={title}
                variant="ghost"
                size="sm"
                onClick={() => createSampleReport(title)}
                className="justify-start text-left h-auto p-2"
              >
                <FileText className="h-4 w-4 mr-2 flex-shrink-0" />
                <span className="text-xs">{title}</span>
              </Button>
            ))}
          </div>
        </div>

        {/* Uploaded Files */}
        {files.length > 0 && (
          <div>
            <p className="text-sm font-medium mb-2">Uploaded Files:</p>
            <div className="space-y-2">
              {files.map((file) => (
                <div
                  key={file.id}
                  className="flex items-center justify-between p-3 border rounded-lg bg-gradient-glass"
                >
                  <div className="flex items-center gap-2">
                    <FileText className="h-4 w-4 text-primary" />
                    <div>
                      <p className="text-sm font-medium">{file.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {file.processed ? "Processed" : "Processing..."}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {file.processed ? (
                      <CheckCircle className="h-4 w-4 text-success" />
                    ) : (
                      <div className="h-4 w-4 border-2 border-primary border-t-transparent rounded-full animate-spin" />
                    )}
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => removeFile(file.id)}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};