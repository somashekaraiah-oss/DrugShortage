import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Download, FileText, Image, BarChart3 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { ChatMessage } from "./ChatInterface";
import { NDCData } from "./SyntheticDataGenerator";

interface ExportOptionsProps {
  messages: ChatMessage[];
  data: NDCData[];
  selectedChart?: string;
}

export const ExportOptions = ({ messages, data, selectedChart }: ExportOptionsProps) => {
  const [exportFormat, setExportFormat] = useState<string>("pdf");
  const [includeCharts, setIncludeCharts] = useState(true);
  const [includeData, setIncludeData] = useState(true);
  const [includeQueries, setIncludeQueries] = useState(true);
  const [isExporting, setIsExporting] = useState(false);
  const { toast } = useToast();

  const handleExport = async () => {
    setIsExporting(true);
    
    // Simulate export processing
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const exportData = {
      timestamp: new Date().toISOString(),
      format: exportFormat,
      summary: {
        totalNDCs: data.length,
        highRiskCount: data.filter(d => d.riskLevel === 'high').length,
        averageCompliance: (data.reduce((sum, ndc) => sum + ndc.complianceScore, 0) / data.length * 100).toFixed(1),
        totalQueries: messages.filter(m => m.type === 'user').length,
      },
      ...(includeData && { ndcData: data }),
      ...(includeQueries && { 
        queries: messages.filter(m => m.type === 'user').map(m => ({
          timestamp: m.timestamp.toISOString(),
          content: m.content
        }))
      }),
      ...(includeCharts && { chartData: selectedChart || "forecast_curve" })
    };

    // Create and download file
    const blob = new Blob([JSON.stringify(exportData, null, 2)], { 
      type: exportFormat === 'json' ? 'application/json' : 'text/plain' 
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `drug-shortage-report-${new Date().toISOString().split('T')[0]}.${exportFormat}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    setIsExporting(false);
    toast({
      title: "Export Complete",
      description: `Report exported as ${exportFormat.toUpperCase()} successfully.`,
    });
  };

  const exportChart = () => {
    // Simulate chart export
    const canvas = document.createElement('canvas');
    canvas.width = 800;
    canvas.height = 600;
    const ctx = canvas.getContext('2d');
    
    if (ctx) {
      // Create a simple chart representation
      ctx.fillStyle = '#f8fafc';
      ctx.fillRect(0, 0, 800, 600);
      ctx.fillStyle = '#3b82f6';
      ctx.font = '24px Inter';
      ctx.fillText('Drug Shortage Forecast Chart', 50, 50);
      ctx.fillStyle = '#6b7280';
      ctx.font = '16px Inter';
      ctx.fillText('Generated on ' + new Date().toLocaleDateString(), 50, 80);
    }

    canvas.toBlob((blob) => {
      if (blob) {
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `chart-${new Date().toISOString().split('T')[0]}.png`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        toast({
          title: "Chart Exported",
          description: "Chart saved as PNG image.",
        });
      }
    }, 'image/png');
  };

  return (
    <Card className="shadow-glass">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Download className="h-5 w-5 text-medical" />
          Export Options
        </CardTitle>
        <CardDescription>
          Download reports and visualizations for presentations
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-3">
          <Dialog>
            <DialogTrigger asChild>
              <Button variant="outline" className="gap-2">
                <FileText className="h-4 w-4" />
                Export Report
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Export Analysis Report</DialogTitle>
                <DialogDescription>
                  Customize your export options below
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium">Export Format</label>
                  <Select value={exportFormat} onValueChange={setExportFormat}>
                    <SelectTrigger className="mt-1">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pdf">PDF Report</SelectItem>
                      <SelectItem value="json">JSON Data</SelectItem>
                      <SelectItem value="csv">CSV Data</SelectItem>
                      <SelectItem value="xlsx">Excel Workbook</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-3">
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="charts" 
                      checked={includeCharts} 
                      onCheckedChange={(checked) => setIncludeCharts(checked === true)}
                    />
                    <label htmlFor="charts" className="text-sm">Include Charts & Visualizations</label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="data" 
                      checked={includeData} 
                      onCheckedChange={(checked) => setIncludeData(checked === true)}
                    />
                    <label htmlFor="data" className="text-sm">Include Raw NDC Data</label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="queries" 
                      checked={includeQueries} 
                      onCheckedChange={(checked) => setIncludeQueries(checked === true)}
                    />
                    <label htmlFor="queries" className="text-sm">Include Query History</label>
                  </div>
                </div>
                
                <Button 
                  onClick={handleExport} 
                  disabled={isExporting}
                  className="w-full"
                >
                  {isExporting ? "Exporting..." : "Download Report"}
                </Button>
              </div>
            </DialogContent>
          </Dialog>

          <Button variant="outline" onClick={exportChart} className="gap-2">
            <Image className="h-4 w-4" />
            Export Chart
          </Button>
        </div>

        <div className="text-xs text-muted-foreground border-t pt-3">
          <p><strong>Tip:</strong> PDF exports include executive summaries suitable for stakeholder presentations.</p>
        </div>
      </CardContent>
    </Card>
  );
};