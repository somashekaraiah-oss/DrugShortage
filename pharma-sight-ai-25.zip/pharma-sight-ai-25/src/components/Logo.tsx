import { Activity } from "lucide-react";

interface LogoProps {
  className?: string;
  size?: "sm" | "md" | "lg";
}

export const Logo = ({ className = "", size = "md" }: LogoProps) => {
  const sizeClasses = {
    sm: "h-4 w-4",
    md: "h-6 w-6", 
    lg: "h-8 w-8"
  };

  const containerSizes = {
    sm: "p-1.5",
    md: "p-2",
    lg: "p-3"
  };

  return (
    <div className={`bg-gradient-primary rounded-lg ${containerSizes[size]} ${className}`}>
      <Activity className={`${sizeClasses[size]} text-white`} />
    </div>
  );
};