import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Mic, MicOff, Square } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface VoiceRecorderProps {
  onTranscript: (text: string) => void;
  disabled?: boolean;
}

export const VoiceRecorder = ({ onTranscript, disabled = false }: VoiceRecorderProps) => {
  const [isRecording, setIsRecording] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const { toast } = useToast();

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      chunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          chunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = async () => {
        setIsProcessing(true);
        const audioBlob = new Blob(chunksRef.current, { type: 'audio/wav' });
        
        // Simulate speech-to-text processing
        setTimeout(() => {
          const mockTranscripts = [
            "What's the shortage risk for NDC 042?",
            "Show me the forecast for methotrexate",
            "Explain why lorazepam is risky",
            "Generate executive summary",
            "Plot feature importance for injectable drugs"
          ];
          
          const randomTranscript = mockTranscripts[Math.floor(Math.random() * mockTranscripts.length)];
          onTranscript(randomTranscript);
          setIsProcessing(false);
          
          toast({
            title: "Voice Processed",
            description: "Successfully converted speech to text.",
          });
        }, 2000);

        // Clean up stream
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
      
      toast({
        title: "Recording Started",
        description: "Speak your query clearly...",
      });
    } catch (error) {
      toast({
        title: "Microphone Error",
        description: "Unable to access microphone. Please check permissions.",
        variant: "destructive",
      });
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  if (disabled) {
    return (
      <Button variant="outline" size="sm" disabled className="gap-2">
        <MicOff className="h-4 w-4" />
        Voice Disabled
      </Button>
    );
  }

  return (
    <div className="flex gap-2">
      {!isRecording ? (
        <Button
          variant="outline"
          size="sm"
          onClick={startRecording}
          disabled={isProcessing}
          className="gap-2 hover:bg-medical/10"
        >
          <Mic className="h-4 w-4" />
          {isProcessing ? "Processing..." : "Voice Query"}
        </Button>
      ) : (
        <Button
          variant="destructive"
          size="sm"
          onClick={stopRecording}
          className="gap-2 animate-pulse"
        >
          <Square className="h-4 w-4" />
          Stop Recording
        </Button>
      )}
    </div>
  );
};