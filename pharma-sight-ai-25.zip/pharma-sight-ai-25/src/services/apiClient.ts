// Enhanced API Client for FastAPI Backend Integration
// Handles external API synchronization and backend communication

export interface FastAPIConfig {
  baseUrl: string;
  apiKey?: string;
  timeout: number;
  retryAttempts: number;
}

export interface APIResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
  timestamp: Date;
  requestId: string;
}

export interface ForecastRequest {
  drugName: string;
  ndcCode: string;
  timeRange: number;
  includeConfidence: boolean;
  modelVersion?: string;
}

export interface ForecastResponse {
  predictions: Array<{
    day: number;
    shortageRisk: number;
    confidence: number;
    factors: string[];
  }>;
  modelAccuracy: number;
  lastUpdated: Date;
}

export interface ExternalDataSync {
  fdaShortages: any[];
  marketPrices: any[];
  regulatoryUpdates: any[];
  lastSyncTime: Date;
}

class APIClient {
  private config: FastAPIConfig;
  private baseHeaders: Record<string, string>;

  constructor(config: FastAPIConfig) {
    this.config = config;
    this.baseHeaders = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      ...(config.apiKey && { 'Authorization': `Bearer ${config.apiKey}` })
    };
  }

  // Generic API request handler
  private async makeRequest<T>(
    endpoint: string,
    method: 'GET' | 'POST' | 'PUT' | 'DELETE' = 'GET',
    data?: any
  ): Promise<APIResponse<T>> {
    const requestId = Math.random().toString(36).substr(2, 9);
    const url = `${this.config.baseUrl}${endpoint}`;

    try {
      const response = await fetch(url, {
        method,
        headers: this.baseHeaders,
        body: data ? JSON.stringify(data) : undefined,
        signal: AbortSignal.timeout(this.config.timeout)
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const responseData = await response.json();

      return {
        success: true,
        data: responseData,
        timestamp: new Date(),
        requestId
      };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error',
        timestamp: new Date(),
        requestId
      };
    }
  }

  // Health check endpoint
  async healthCheck(): Promise<APIResponse<{ status: string; version: string }>> {
    return this.makeRequest('/health');
  }

  // Get enhanced forecast from FastAPI backend
  async getForecast(request: ForecastRequest): Promise<APIResponse<ForecastResponse>> {
    return this.makeRequest('/api/v1/forecast', 'POST', request);
  }

  // Submit batch analysis request
  async submitBatchAnalysis(drugs: string[]): Promise<APIResponse<{ jobId: string }>> {
    return this.makeRequest('/api/v1/batch-analysis', 'POST', { drugs });
  }

  // Get batch analysis results
  async getBatchResults(jobId: string): Promise<APIResponse<any>> {
    return this.makeRequest(`/api/v1/batch-analysis/${jobId}`);
  }

  // Sync external data sources
  async syncExternalData(): Promise<APIResponse<ExternalDataSync>> {
    return this.makeRequest('/api/v1/sync/external', 'POST');
  }

  // Update model with new training data
  async updateModel(trainingData: any[]): Promise<APIResponse<{ modelVersion: string }>> {
    return this.makeRequest('/api/v1/model/update', 'POST', { trainingData });
  }

  // Get model performance metrics
  async getModelMetrics(): Promise<APIResponse<any>> {
    return this.makeRequest('/api/v1/model/metrics');
  }

  // Upload user data for analysis
  async uploadData(data: any[], dataType: string): Promise<APIResponse<{ recordsProcessed: number }>> {
    return this.makeRequest('/api/v1/data/upload', 'POST', { data, dataType });
  }

  // Get compliance reports
  async getComplianceReport(dateRange: { start: Date; end: Date }): Promise<APIResponse<any>> {
    const params = new URLSearchParams({
      start: dateRange.start.toISOString(),
      end: dateRange.end.toISOString()
    });
    return this.makeRequest(`/api/v1/compliance/report?${params}`);
  }

  // AI-powered query processing
  async processNaturalLanguageQuery(
    query: string,
    context: any
  ): Promise<APIResponse<{ response: string; insights: any[] }>> {
    return this.makeRequest('/api/v1/nlp/query', 'POST', { query, context });
  }
}

// Configuration manager for different environments
export class APIConfigManager {
  private configs: Map<string, FastAPIConfig> = new Map();

  constructor() {
    this.initializeConfigs();
  }

  private initializeConfigs() {
    // Development configuration
    this.configs.set('development', {
      baseUrl: 'http://localhost:8000',
      timeout: 30000,
      retryAttempts: 3
    });

    // Production configuration
    this.configs.set('production', {
      baseUrl: 'https://api.shortageiq.com',
      timeout: 15000,
      retryAttempts: 2
    });

    // Testing configuration
    this.configs.set('testing', {
      baseUrl: 'http://localhost:8001',
      timeout: 10000,
      retryAttempts: 1
    });
  }

  getConfig(environment: string): FastAPIConfig | undefined {
    return this.configs.get(environment);
  }

  setAPIKey(environment: string, apiKey: string): void {
    const config = this.configs.get(environment);
    if (config) {
      config.apiKey = apiKey;
    }
  }
}

// Factory function to create API client instances
export function createAPIClient(environment: string = 'development'): APIClient | null {
  const configManager = new APIConfigManager();
  const config = configManager.getConfig(environment);
  
  if (!config) {
    console.error(`No configuration found for environment: ${environment}`);
    return null;
  }
  
  return new APIClient(config);
}

// Mock API responses for development/testing
export class MockAPIClient extends APIClient {
  constructor() {
    super({
      baseUrl: 'http://localhost:8000',
      timeout: 1000,
      retryAttempts: 1
    });
  }

  async getForecast(request: ForecastRequest): Promise<APIResponse<ForecastResponse>> {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 500));

    const mockResponse: ForecastResponse = {
      predictions: Array.from({ length: request.timeRange }, (_, i) => ({
        day: i + 1,
        shortageRisk: Math.random() * 0.8 + 0.1,
        confidence: Math.random() * 0.3 + 0.7,
        factors: ['supply_chain', 'compliance', 'demand']
      })),
      modelAccuracy: 0.853,
      lastUpdated: new Date()
    };

    return {
      success: true,
      data: mockResponse,
      timestamp: new Date(),
      requestId: Math.random().toString(36).substr(2, 9)
    };
  }

  async processNaturalLanguageQuery(
    query: string,
    context: any
  ): Promise<APIResponse<{ response: string; insights: any[] }>> {
    await new Promise(resolve => setTimeout(resolve, 300));

    return {
      success: true,
      data: {
        response: `AI-generated response for: "${query}" with enhanced context analysis`,
        insights: [
          { type: 'metric', title: 'Model Confidence', content: '85.3%' },
          { type: 'alert', title: 'Risk Factor', content: 'Supply chain vulnerability detected' }
        ]
      },
      timestamp: new Date(),
      requestId: Math.random().toString(36).substr(2, 9)
    };
  }

  async syncExternalData(): Promise<APIResponse<ExternalDataSync>> {
    await new Promise(resolve => setTimeout(resolve, 1000));

    return {
      success: true,
      data: {
        fdaShortages: [],
        marketPrices: [],
        regulatoryUpdates: [],
        lastSyncTime: new Date()
      },
      timestamp: new Date(),
      requestId: Math.random().toString(36).substr(2, 9)
    };
  }
}

// Singleton instances
export const configManager = new APIConfigManager();
export const apiClient = process.env.NODE_ENV === 'production' 
  ? createAPIClient('production') 
  : new MockAPIClient();