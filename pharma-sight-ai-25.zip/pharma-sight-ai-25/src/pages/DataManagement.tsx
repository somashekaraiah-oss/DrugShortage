import { useState, useCallback } from "react";
import { SyntheticDataGenerator, generateSyntheticData, NDCData } from "@/components/SyntheticDataGenerator";
import { DataLoader } from "@/components/DataLoader";
import { FileUpload } from "@/components/FileUpload";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Database, Upload, RefreshCw, FileText, CheckCircle, AlertCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { ReportAnalysis } from "@/utils/reportParser";

const DataManagement = () => {
  const [ndcData, setNdcData] = useState<NDCData[]>(() => generateSyntheticData());
  const [uploadHistory, setUploadHistory] = useState<Array<{
    id: string;
    filename: string;
    timestamp: Date;
    status: 'success' | 'error';
    analysis?: ReportAnalysis;
  }>>([]);
  const { toast } = useToast();

  const handleDataUpdate = useCallback((newData: NDCData[]) => {
    setNdcData(newData);
    toast({
      title: "Data Updated",
      description: "Synthetic data has been regenerated successfully.",
    });
  }, [toast]);

  const handleFileProcessed = useCallback((impact: { 
    ndcId: string; 
    compliance: number; 
    risk: string;
    analysis: ReportAnalysis;
  }) => {
    // Update NDC data
    setNdcData(prev => prev.map(ndc => {
      if (ndc.id === impact.ndcId) {
        const newCompliance = Math.max(0, Math.min(1, ndc.complianceScore + impact.compliance));
        const newRiskLevel = newCompliance < 0.7 ? 'high' : newCompliance < 0.85 ? 'medium' : 'low';
        
        return {
          ...ndc,
          complianceScore: newCompliance,
          riskLevel: newRiskLevel,
        };
      }
      return ndc;
    }));

    // Add to upload history
    setUploadHistory(prev => [{
      id: Math.random().toString(36).substr(2, 9),
      filename: `report_${impact.ndcId}_${Date.now()}.pdf`,
      timestamp: new Date(),
      status: 'success',
      analysis: impact.analysis
    }, ...prev.slice(0, 9)]); // Keep last 10 uploads

    toast({
      title: "File Processed",
      description: `Successfully analyzed report for ${impact.ndcId}`,
    });
  }, [toast]);

  const refreshData = () => {
    const newData = generateSyntheticData();
    setNdcData(newData);
    toast({
      title: "Data Refreshed",
      description: "New synthetic data generated with updated parameters.",
    });
  };

  const dataStats = {
    total: ndcData.length,
    high: ndcData.filter(d => d.riskLevel === 'high').length,
    medium: ndcData.filter(d => d.riskLevel === 'medium').length,
    low: ndcData.filter(d => d.riskLevel === 'low').length,
    avgCompliance: (ndcData.reduce((sum, ndc) => sum + ndc.complianceScore, 0) / ndcData.length * 100).toFixed(1)
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-primary bg-clip-text text-transparent">
            Data Management
          </h1>
          <p className="text-muted-foreground">
            Manage synthetic data generation and process regulatory documents
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Badge variant="secondary" className="bg-primary/10 text-primary border-primary/20">
            {dataStats.total} Active NDCs
          </Badge>
          <Button onClick={refreshData} variant="outline" size="sm" className="gap-2">
            <RefreshCw className="h-4 w-4" />
            Refresh Data
          </Button>
        </div>
      </div>

      {/* Data Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="shadow-glass">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total NDCs</CardTitle>
            <Database className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">{dataStats.total}</div>
            <p className="text-xs text-muted-foreground">Synthetic records</p>
          </CardContent>
        </Card>

        <Card className="shadow-glass">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">High Risk</CardTitle>
            <AlertCircle className="h-4 w-4 text-destructive" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-destructive">{dataStats.high}</div>
            <p className="text-xs text-muted-foreground">Critical attention needed</p>
          </CardContent>
        </Card>

        <Card className="shadow-glass">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Compliance Avg</CardTitle>
            <CheckCircle className="h-4 w-4 text-success" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-success">{dataStats.avgCompliance}%</div>
            <p className="text-xs text-muted-foreground">Portfolio health</p>
          </CardContent>
        </Card>

        <Card className="shadow-glass">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Uploads Today</CardTitle>
            <Upload className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">{uploadHistory.length}</div>
            <p className="text-xs text-muted-foreground">Documents processed</p>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs defaultValue="synthetic" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="scenarios" className="gap-2">
            <Database className="h-4 w-4" />
            Scenarios
          </TabsTrigger>
          <TabsTrigger value="synthetic" className="gap-2">
            <Database className="h-4 w-4" />
            Synthetic Data
          </TabsTrigger>
          <TabsTrigger value="upload" className="gap-2">
            <Upload className="h-4 w-4" />
            File Processing
          </TabsTrigger>
          <TabsTrigger value="history" className="gap-2">
            <FileText className="h-4 w-4" />
            Upload History
          </TabsTrigger>
        </TabsList>

        <TabsContent value="scenarios" className="space-y-6">
          <DataLoader data={ndcData} onDataUpdate={handleDataUpdate} />
        </TabsContent>

        <TabsContent value="synthetic" className="space-y-6">
          <SyntheticDataGenerator
            data={ndcData}
            onDataUpdate={handleDataUpdate}
          />
        </TabsContent>

        <TabsContent value="upload" className="space-y-6">
          <FileUpload
            onFileProcessed={handleFileProcessed}
            data={ndcData}
          />
        </TabsContent>

        <TabsContent value="history" className="space-y-6">
          <Card className="shadow-glass">
            <CardHeader>
              <CardTitle>Recent Upload History</CardTitle>
              <CardDescription>
                Track processed documents and their impact on NDC data
              </CardDescription>
            </CardHeader>
            <CardContent>
              {uploadHistory.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <Upload className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>No uploads yet. Upload your first document to get started.</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {uploadHistory.map((upload) => (
                    <div key={upload.id} className="flex items-center justify-between p-4 bg-muted/50 rounded-lg border">
                      <div className="flex items-center gap-3">
                        <div className={`w-2 h-2 rounded-full ${
                          upload.status === 'success' ? 'bg-success' : 'bg-destructive'
                        }`} />
                        <div>
                          <p className="font-medium text-sm">{upload.filename}</p>
                          <p className="text-xs text-muted-foreground">
                            {upload.timestamp.toLocaleString()}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <Badge 
                          variant={upload.status === 'success' ? 'default' : 'destructive'}
                          className="text-xs"
                        >
                          {upload.status === 'success' ? 'Processed' : 'Failed'}
                        </Badge>
                        {upload.analysis && (
                          <p className="text-xs text-muted-foreground mt-1">
                            {upload.analysis.reportType} - {upload.analysis.severity}
                          </p>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default DataManagement;