import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { 
  Settings as SettingsIcon, 
  Bell, 
  Shield, 
  Database, 
  Palette,
  User,
  Save,
  RefreshCw
} from "lucide-react";

const Settings = () => {
  const { toast } = useToast();
  const [settings, setSettings] = useState({
    notifications: {
      emailAlerts: true,
      pushNotifications: false,
      riskThreshold: [70],
      alertFrequency: "immediate"
    },
    model: {
      forecastHorizon: [30],
      confidenceLevel: [80],
      retrainingFreq: "weekly",
      autoUpdate: true
    },
    display: {
      theme: "system",
      chartStyle: "gradient",
      dashboardLayout: "default",
      animationsEnabled: true
    },
    security: {
      sessionTimeout: [60],
      twoFactorAuth: false,
      auditLogs: true,
      dataRetention: [90]
    }
  });

  const handleSave = () => {
    // Save settings logic
    toast({
      title: "Settings Saved",
      description: "Your preferences have been updated successfully.",
    });
  };

  const handleReset = () => {
    // Reset to defaults
    toast({
      title: "Settings Reset",
      description: "All settings have been restored to default values.",
    });
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-primary bg-clip-text text-transparent">
            Settings
          </h1>
          <p className="text-muted-foreground">
            Configure your PharmaForecaster Pro preferences and system settings
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Button onClick={handleReset} variant="outline" size="sm" className="gap-2">
            <RefreshCw className="h-4 w-4" />
            Reset to Defaults
          </Button>
          <Button onClick={handleSave} size="sm" className="gap-2">
            <Save className="h-4 w-4" />
            Save Changes
          </Button>
        </div>
      </div>

      {/* Settings Tabs */}
      <Tabs defaultValue="notifications" className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="notifications" className="gap-2">
            <Bell className="h-4 w-4" />
            Alerts
          </TabsTrigger>
          <TabsTrigger value="model" className="gap-2">
            <Database className="h-4 w-4" />
            Model
          </TabsTrigger>
          <TabsTrigger value="display" className="gap-2">
            <Palette className="h-4 w-4" />
            Display
          </TabsTrigger>
          <TabsTrigger value="security" className="gap-2">
            <Shield className="h-4 w-4" />
            Security
          </TabsTrigger>
          <TabsTrigger value="profile" className="gap-2">
            <User className="h-4 w-4" />
            Profile
          </TabsTrigger>
        </TabsList>

        <TabsContent value="notifications" className="space-y-6">
          <Card className="shadow-glass">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bell className="h-5 w-5 text-primary" />
                Notification Preferences
              </CardTitle>
              <CardDescription>
                Configure how and when you receive alerts about drug shortage risks
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="email-alerts" className="text-base">Email Alerts</Label>
                  <p className="text-sm text-muted-foreground">Receive risk alerts via email</p>
                </div>
                <Switch
                  id="email-alerts"
                  checked={settings.notifications.emailAlerts}
                  onCheckedChange={(checked) =>
                    setSettings(prev => ({
                      ...prev,
                      notifications: { ...prev.notifications, emailAlerts: checked }
                    }))
                  }
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="push-notifications" className="text-base">Push Notifications</Label>
                  <p className="text-sm text-muted-foreground">Real-time browser notifications</p>
                </div>
                <Switch
                  id="push-notifications"
                  checked={settings.notifications.pushNotifications}
                  onCheckedChange={(checked) =>
                    setSettings(prev => ({
                      ...prev,
                      notifications: { ...prev.notifications, pushNotifications: checked }
                    }))
                  }
                />
              </div>

              <div className="space-y-3">
                <Label className="text-base">Risk Threshold for Alerts</Label>
                <div className="px-4">
                  <Slider
                    value={settings.notifications.riskThreshold}
                    onValueChange={(value) =>
                      setSettings(prev => ({
                        ...prev,
                        notifications: { ...prev.notifications, riskThreshold: value }
                      }))
                    }
                    max={100}
                    min={0}
                    step={5}
                    className="w-full"
                  />
                  <div className="flex justify-between text-sm text-muted-foreground mt-1">
                    <span>0%</span>
                    <span className="font-medium">
                      Alert when risk exceeds {settings.notifications.riskThreshold[0]}%
                    </span>
                    <span>100%</span>
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <Label htmlFor="alert-frequency" className="text-base">Alert Frequency</Label>
                <Select
                  value={settings.notifications.alertFrequency}
                  onValueChange={(value) =>
                    setSettings(prev => ({
                      ...prev,
                      notifications: { ...prev.notifications, alertFrequency: value }
                    }))
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="immediate">Immediate</SelectItem>
                    <SelectItem value="hourly">Hourly Digest</SelectItem>
                    <SelectItem value="daily">Daily Summary</SelectItem>
                    <SelectItem value="weekly">Weekly Report</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="model" className="space-y-6">
          <Card className="shadow-glass">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="h-5 w-5 text-primary" />
                Model Configuration
              </CardTitle>
              <CardDescription>
                Adjust TFT model parameters and forecasting settings
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-3">
                <Label className="text-base">Default Forecast Horizon (Days)</Label>
                <div className="px-4">
                  <Slider
                    value={settings.model.forecastHorizon}
                    onValueChange={(value) =>
                      setSettings(prev => ({
                        ...prev,
                        model: { ...prev.model, forecastHorizon: value }
                      }))
                    }
                    max={180}
                    min={7}
                    step={7}
                    className="w-full"
                  />
                  <div className="flex justify-between text-sm text-muted-foreground mt-1">
                    <span>7 days</span>
                    <span className="font-medium">
                      {settings.model.forecastHorizon[0]} days
                    </span>
                    <span>180 days</span>
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <Label className="text-base">Confidence Level</Label>
                <div className="px-4">
                  <Slider
                    value={settings.model.confidenceLevel}
                    onValueChange={(value) =>
                      setSettings(prev => ({
                        ...prev,
                        model: { ...prev.model, confidenceLevel: value }
                      }))
                    }
                    max={99}
                    min={50}
                    step={5}
                    className="w-full"
                  />
                  <div className="flex justify-between text-sm text-muted-foreground mt-1">
                    <span>50%</span>
                    <span className="font-medium">
                      {settings.model.confidenceLevel[0]}% confidence
                    </span>
                    <span>99%</span>
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <Label htmlFor="retraining-freq" className="text-base">Model Retraining Frequency</Label>
                <Select
                  value={settings.model.retrainingFreq}
                  onValueChange={(value) =>
                    setSettings(prev => ({
                      ...prev,
                      model: { ...prev.model, retrainingFreq: value }
                    }))
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="daily">Daily</SelectItem>
                    <SelectItem value="weekly">Weekly</SelectItem>
                    <SelectItem value="monthly">Monthly</SelectItem>
                    <SelectItem value="manual">Manual Only</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="auto-update" className="text-base">Automatic Model Updates</Label>
                  <p className="text-sm text-muted-foreground">Auto-update when new training data is available</p>
                </div>
                <Switch
                  id="auto-update"
                  checked={settings.model.autoUpdate}
                  onCheckedChange={(checked) =>
                    setSettings(prev => ({
                      ...prev,
                      model: { ...prev.model, autoUpdate: checked }
                    }))
                  }
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="display" className="space-y-6">
          <Card className="shadow-glass">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Palette className="h-5 w-5 text-primary" />
                Display Preferences
              </CardTitle>
              <CardDescription>
                Customize the appearance and layout of your dashboard
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-3">
                <Label htmlFor="theme" className="text-base">Theme</Label>
                <Select
                  value={settings.display.theme}
                  onValueChange={(value) =>
                    setSettings(prev => ({
                      ...prev,
                      display: { ...prev.display, theme: value }
                    }))
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="light">Light</SelectItem>
                    <SelectItem value="dark">Dark</SelectItem>
                    <SelectItem value="system">System</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-3">
                <Label htmlFor="chart-style" className="text-base">Chart Style</Label>
                <Select
                  value={settings.display.chartStyle}
                  onValueChange={(value) =>
                    setSettings(prev => ({
                      ...prev,
                      display: { ...prev.display, chartStyle: value }
                    }))
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="gradient">Gradient</SelectItem>
                    <SelectItem value="solid">Solid Colors</SelectItem>
                    <SelectItem value="minimal">Minimal</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="animations" className="text-base">Enable Animations</Label>
                  <p className="text-sm text-muted-foreground">Smooth transitions and chart animations</p>
                </div>
                <Switch
                  id="animations"
                  checked={settings.display.animationsEnabled}
                  onCheckedChange={(checked) =>
                    setSettings(prev => ({
                      ...prev,
                      display: { ...prev.display, animationsEnabled: checked }
                    }))
                  }
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="security" className="space-y-6">
          <Card className="shadow-glass">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5 text-primary" />
                Security Settings
              </CardTitle>
              <CardDescription>
                Manage security preferences and data protection settings
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-3">
                <Label className="text-base">Session Timeout (Minutes)</Label>
                <div className="px-4">
                  <Slider
                    value={settings.security.sessionTimeout}
                    onValueChange={(value) =>
                      setSettings(prev => ({
                        ...prev,
                        security: { ...prev.security, sessionTimeout: value }
                      }))
                    }
                    max={480}
                    min={15}
                    step={15}
                    className="w-full"
                  />
                  <div className="flex justify-between text-sm text-muted-foreground mt-1">
                    <span>15 min</span>
                    <span className="font-medium">
                      {settings.security.sessionTimeout[0]} minutes
                    </span>
                    <span>8 hours</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="two-factor" className="text-base">Two-Factor Authentication</Label>
                  <p className="text-sm text-muted-foreground">Add an extra layer of security</p>
                </div>
                <Switch
                  id="two-factor"
                  checked={settings.security.twoFactorAuth}
                  onCheckedChange={(checked) =>
                    setSettings(prev => ({
                      ...prev,
                      security: { ...prev.security, twoFactorAuth: checked }
                    }))
                  }
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="audit-logs" className="text-base">Audit Logs</Label>
                  <p className="text-sm text-muted-foreground">Track all user activities and data access</p>
                </div>
                <Switch
                  id="audit-logs"
                  checked={settings.security.auditLogs}
                  onCheckedChange={(checked) =>
                    setSettings(prev => ({
                      ...prev,
                      security: { ...prev.security, auditLogs: checked }
                    }))
                  }
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="profile" className="space-y-6">
          <Card className="shadow-glass">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="h-5 w-5 text-primary" />
                User Profile
              </CardTitle>
              <CardDescription>
                Manage your account information and preferences
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Full Name</Label>
                  <Input id="name" placeholder="Dr. Jane Smith" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="title">Job Title</Label>
                  <Input id="title" placeholder="Chief Pharmacist" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="organization">Organization</Label>
                  <Input id="organization" placeholder="Regional Hospital System" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input id="email" type="email" placeholder="jane.smith@hospital.com" />
                </div>
              </div>

              <div className="pt-4 border-t">
                <h3 className="text-base font-medium mb-3">Account Status</h3>
                <div className="flex items-center gap-4">
                  <Badge className="bg-success/10 text-success border-success/20">
                    Enterprise License
                  </Badge>
                  <Badge variant="outline">
                    Valid until Dec 2024
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Settings;