import { useState } from "react";
import { TFTExplanation } from "@/components/TFTExplanation";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { 
  BookOpen, 
  Search, 
  Brain, 
  TrendingUp, 
  Target, 
  Lightbulb,
  AlertTriangle,
  CheckCircle,
  Info,
  ExternalLink
} from "lucide-react";

const KnowledgeBase = () => {
  const [searchQuery, setSearchQuery] = useState("");

  const knowledgeArticles = [
    {
      id: "tft-basics",
      title: "Temporal Fusion Transformer Fundamentals",
      category: "Model Architecture",
      description: "Understanding the core concepts behind TFT for time series forecasting",
      tags: ["TFT", "Machine Learning", "Forecasting"],
      content: "Learn how TFT combines attention mechanisms with feature importance analysis..."
    },
    {
      id: "pharma-forecasting",
      title: "Drug Shortage Prediction in Pharmaceutical Supply Chains",
      category: "Industry Application",
      description: "How AI models predict and prevent drug shortages in healthcare",
      tags: ["Pharmaceutical", "Supply Chain", "Healthcare"],
      content: "Explore the critical factors that contribute to drug shortages..."
    },
    {
      id: "compliance-scoring",
      title: "FDA Compliance Scoring Methodology",
      category: "Regulatory",
      description: "Understanding compliance scores and their impact on shortage risk",
      tags: ["FDA", "Compliance", "Risk Assessment"],
      content: "Deep dive into how compliance scores are calculated and interpreted..."
    },
    {
      id: "feature-importance",
      title: "Feature Importance in Drug Shortage Models",
      category: "Analytics",
      description: "Which factors matter most in predicting drug shortages",
      tags: ["Feature Engineering", "Risk Factors", "Analytics"],
      content: "Analysis of the most predictive features for shortage forecasting..."
    }
  ];

  const faqs = [
    {
      question: "How accurate is the TFT model for drug shortage prediction?",
      answer: "Our TFT model achieves 85.3% accuracy for 30-day forecasts, with confidence intervals providing uncertainty bounds. Accuracy decreases for longer forecasting horizons but provides valuable early warning capabilities."
    },
    {
      question: "What data sources feed into the forecasting model?",
      answer: "The model integrates FDA inspection data, manufacturer compliance scores, historical shortage events, supply chain metrics, and regulatory filing information to provide comprehensive risk assessment."
    },
    {
      question: "How often is the model retrained with new data?",
      answer: "The model is retrained weekly with new regulatory data and monthly with comprehensive market intelligence. Critical alerts trigger immediate model updates when new shortage events occur."
    },
    {
      question: "What makes TFT better than traditional forecasting methods?",
      answer: "TFT combines the interpretability of traditional methods with the power of deep learning, providing both accurate predictions and explanations of which factors are driving the forecasts."
    },
    {
      question: "How do compliance scores impact shortage predictions?",
      answer: "Compliance scores have a 35% weight in our model. NDCs with compliance scores below 70% have a 3.2x higher likelihood of experiencing shortages within 60 days."
    }
  ];

  const filteredArticles = knowledgeArticles.filter(article =>
    article.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    article.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
    article.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <div className="container mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-primary bg-clip-text text-transparent">
            Knowledge Base
          </h1>
          <p className="text-muted-foreground">
            Comprehensive documentation and insights for drug shortage forecasting
          </p>
        </div>
        <Badge variant="secondary" className="bg-primary/10 text-primary border-primary/20">
          {knowledgeArticles.length} Articles
        </Badge>
      </div>

      {/* Search */}
      <Card className="shadow-glass">
        <CardContent className="pt-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
            <Input
              placeholder="Search knowledge base..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardContent>
      </Card>

      {/* Main Content */}
      <Tabs defaultValue="articles" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="articles" className="gap-2">
            <BookOpen className="h-4 w-4" />
            Articles
          </TabsTrigger>
          <TabsTrigger value="tft" className="gap-2">
            <Brain className="h-4 w-4" />
            TFT Model
          </TabsTrigger>
          <TabsTrigger value="faq" className="gap-2">
            <Info className="h-4 w-4" />
            FAQ
          </TabsTrigger>
          <TabsTrigger value="resources" className="gap-2">
            <ExternalLink className="h-4 w-4" />
            Resources
          </TabsTrigger>
        </TabsList>

        <TabsContent value="articles" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filteredArticles.map((article) => (
              <Card key={article.id} className="shadow-glass hover:shadow-medical transition-shadow">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="text-lg">{article.title}</CardTitle>
                      <CardDescription>{article.description}</CardDescription>
                    </div>
                    <Badge variant="outline" className="text-xs">
                      {article.category}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {article.tags.map((tag) => (
                      <Badge key={tag} variant="secondary" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                  <p className="text-sm text-muted-foreground mb-4">
                    {article.content}
                  </p>
                  <Button variant="outline" size="sm" className="w-full">
                    Read More
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="tft" className="space-y-6">
          <TFTExplanation />
        </TabsContent>

        <TabsContent value="faq" className="space-y-6">
          <Card className="shadow-glass">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Info className="h-5 w-5 text-primary" />
                Frequently Asked Questions
              </CardTitle>
              <CardDescription>
                Common questions about our drug shortage forecasting system
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Accordion type="single" collapsible className="w-full">
                {faqs.map((faq, index) => (
                  <AccordionItem key={index} value={`item-${index}`}>
                    <AccordionTrigger className="text-left">
                      {faq.question}
                    </AccordionTrigger>
                    <AccordionContent className="text-muted-foreground">
                      {faq.answer}
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="resources" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card className="shadow-glass">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-primary" />
                  Research Papers
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <a href="#" className="block p-3 bg-muted/50 rounded-lg hover:bg-muted transition-colors">
                  <p className="font-medium text-sm">Temporal Fusion Transformers for Interpretable Multi-horizon Time Series Forecasting</p>
                  <p className="text-xs text-muted-foreground">Google Research, 2021</p>
                </a>
                <a href="#" className="block p-3 bg-muted/50 rounded-lg hover:bg-muted transition-colors">
                  <p className="font-medium text-sm">Drug Shortages: Root Causes and Potential Solutions</p>
                  <p className="text-xs text-muted-foreground">FDA White Paper, 2019</p>
                </a>
              </CardContent>
            </Card>

            <Card className="shadow-glass">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Target className="h-5 w-5 text-success" />
                  Best Practices
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="p-3 bg-success/10 rounded-lg border border-success/20">
                  <p className="font-medium text-sm text-success">Model Interpretation</p>
                  <p className="text-xs text-muted-foreground">Guidelines for understanding TFT predictions</p>
                </div>
                <div className="p-3 bg-success/10 rounded-lg border border-success/20">
                  <p className="font-medium text-sm text-success">Risk Mitigation</p>
                  <p className="text-xs text-muted-foreground">Strategies for addressing high-risk NDCs</p>
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-glass">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Lightbulb className="h-5 w-5 text-warning" />
                  Quick Tips
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="p-3 bg-warning/10 rounded-lg border border-warning/20">
                  <p className="font-medium text-sm">Monitor compliance scores below 70%</p>
                </div>
                <div className="p-3 bg-warning/10 rounded-lg border border-warning/20">
                  <p className="font-medium text-sm">Set alerts for inspection gaps &gt; 200 days</p>
                </div>
                <div className="p-3 bg-warning/10 rounded-lg border border-warning/20">
                  <p className="font-medium text-sm">Review Tier 3 manufacturers weekly</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default KnowledgeBase;