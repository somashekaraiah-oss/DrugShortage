import { useState, useCallback } from "react";
import { ExecutiveSummary } from "@/components/ExecutiveSummary";
import { ExportOptions } from "@/components/ExportOptions";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BarChart3, TrendingUp, AlertTriangle, CheckCircle, FileText, Download } from "lucide-react";
import { generateSyntheticData, NDCData } from "@/components/SyntheticDataGenerator";
import { ChatMessage } from "@/components/ChatInterface";

const Analytics = () => {
  const [ndcData] = useState<NDCData[]>(() => generateSyntheticData());
  const [messages] = useState<ChatMessage[]>([]);

  const handleExport = useCallback(() => {
    // Export functionality
    console.log("Exporting analytics data...");
  }, []);

  const riskMetrics = {
    total: ndcData.length,
    high: ndcData.filter(d => d.riskLevel === 'high').length,
    medium: ndcData.filter(d => d.riskLevel === 'medium').length,
    low: ndcData.filter(d => d.riskLevel === 'low').length,
    avgCompliance: (ndcData.reduce((sum, ndc) => sum + ndc.complianceScore, 0) / ndcData.length * 100).toFixed(1)
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-primary bg-clip-text text-transparent">
            Analytics Dashboard
          </h1>
          <p className="text-muted-foreground">
            Executive insights and comprehensive reporting for drug shortage intelligence
          </p>
        </div>
        <Badge variant="secondary" className="bg-success/10 text-success border-success/20">
          Real-time Data
        </Badge>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="shadow-glass">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total NDCs</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">{riskMetrics.total}</div>
            <p className="text-xs text-muted-foreground">Active monitoring</p>
          </CardContent>
        </Card>

        <Card className="shadow-glass">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">High Risk</CardTitle>
            <AlertTriangle className="h-4 w-4 text-destructive" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-destructive">{riskMetrics.high}</div>
            <p className="text-xs text-muted-foreground">Require immediate attention</p>
          </CardContent>
        </Card>

        <Card className="shadow-glass">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg Compliance</CardTitle>
            <CheckCircle className="h-4 w-4 text-success" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-success">{riskMetrics.avgCompliance}%</div>
            <p className="text-xs text-muted-foreground">Portfolio average</p>
          </CardContent>
        </Card>

        <Card className="shadow-glass">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Forecast Accuracy</CardTitle>
            <TrendingUp className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">85.3%</div>
            <p className="text-xs text-muted-foreground">30-day prediction</p>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs defaultValue="executive" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="executive" className="gap-2">
            <FileText className="h-4 w-4" />
            Executive Summary
          </TabsTrigger>
          <TabsTrigger value="detailed" className="gap-2">
            <BarChart3 className="h-4 w-4" />
            Detailed Reports
          </TabsTrigger>
          <TabsTrigger value="export" className="gap-2">
            <Download className="h-4 w-4" />
            Export Options
          </TabsTrigger>
        </TabsList>

        <TabsContent value="executive" className="space-y-6">
          <ExecutiveSummary
            data={ndcData}
            messages={messages}
            onExport={handleExport}
          />
        </TabsContent>

        <TabsContent value="detailed" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="shadow-glass">
              <CardHeader>
                <CardTitle>Risk Distribution</CardTitle>
                <CardDescription>
                  Current risk level breakdown across all monitored NDCs
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">High Risk</span>
                    <div className="flex items-center gap-2">
                      <div className="w-32 bg-muted rounded-full h-2">
                        <div 
                          className="bg-destructive h-2 rounded-full" 
                          style={{ width: `${(riskMetrics.high / riskMetrics.total) * 100}%` }}
                        />
                      </div>
                      <span className="text-sm font-medium">{riskMetrics.high}</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Medium Risk</span>
                    <div className="flex items-center gap-2">
                      <div className="w-32 bg-muted rounded-full h-2">
                        <div 
                          className="bg-warning h-2 rounded-full" 
                          style={{ width: `${(riskMetrics.medium / riskMetrics.total) * 100}%` }}
                        />
                      </div>
                      <span className="text-sm font-medium">{riskMetrics.medium}</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Low Risk</span>
                    <div className="flex items-center gap-2">
                      <div className="w-32 bg-muted rounded-full h-2">
                        <div 
                          className="bg-success h-2 rounded-full" 
                          style={{ width: `${(riskMetrics.low / riskMetrics.total) * 100}%` }}
                        />
                      </div>
                      <span className="text-sm font-medium">{riskMetrics.low}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-glass">
              <CardHeader>
                <CardTitle>Top Priority NDCs</CardTitle>
                <CardDescription>
                  NDCs requiring immediate attention based on risk scores
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {ndcData
                    .filter(ndc => ndc.riskLevel === 'high')
                    .slice(0, 3)
                    .map((ndc, index) => (
                      <div key={ndc.id} className="flex items-center justify-between p-3 bg-destructive/5 rounded-lg border border-destructive/20">
                        <div>
                          <p className="font-medium text-sm">{ndc.name}</p>
                          <p className="text-xs text-muted-foreground">{ndc.id}</p>
                        </div>
                        <div className="text-right">
                          <Badge variant="destructive" className="text-xs">
                            {(ndc.complianceScore * 100).toFixed(1)}% compliance
                          </Badge>
                          <p className="text-xs text-muted-foreground mt-1">
                            {ndc.inspectionGap} days gap
                          </p>
                        </div>
                      </div>
                    ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="export" className="space-y-6">
          <ExportOptions
            messages={messages}
            data={ndcData}
            selectedChart="analytics_overview"
          />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Analytics;