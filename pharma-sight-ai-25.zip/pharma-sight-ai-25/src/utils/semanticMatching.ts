// Enhanced semantic matching for drug analysis queries with advanced NLP capabilities
export interface QueryIntent {
  type: 'forecast_request' | 'risk_inquiry' | 'comparison' | 'trend_analysis' | 'general' | 'feature_importance' | 'summarization' | 'status_check';
  confidence: number;
  entities: {
    drugs?: string[];
    manufacturers?: string[];
    therapyAreas?: string[];
    substanceTypes?: string[];
    timeRange?: number;
    riskLevel?: string;
    category?: string;
    comparisonTarget?: string[];
  };
  intent: {
    action: string;
    focus: string;
    scope: string;
  };
}

// Enhanced mappings for comprehensive entity extraction
const DRUG_SYNONYMS: Record<string, string[]> = {
  'cisplatin': ['cisplatin', 'cis-platinum', 'platinol', 'cddp'],
  'carboplatin': ['carboplatin', 'paraplatin', 'cbdca'],
  'oxaliplatin': ['oxaliplatin', 'eloxatin', 'l-ohp'],
  'methotrexate': ['methotrexate', 'mtx', 'trexall', 'rheumatrex'],
  'morphine': ['morphine', 'ms contin', 'roxanol', 'kadian'],
  'fentanyl': ['fentanyl', 'actiq', 'duragesic', 'sublimaze'],
  'propofol': ['propofol', 'diprivan', 'fresofol'],
  'vancomycin': ['vancomycin', 'vancocin', 'vanco'],
  'insulin': ['insulin', 'humulin', 'novolog', 'lantus', 'humalog'],
  'paclitaxel': ['paclitaxel', 'taxol', 'abraxane'],
  'docetaxel': ['docetaxel', 'taxotere'],
  'doxorubicin': ['doxorubicin', 'adriamycin', 'doxil'],
  'cyclophosphamide': ['cyclophosphamide', 'cytoxan', 'endoxan'],
  'fluorouracil': ['fluorouracil', '5-fu', 'adrucil'],
  'gemcitabine': ['gemcitabine', 'gemzar'],
  'irinotecan': ['irinotecan', 'camptosar', 'cpt-11'],
  'bleomycin': ['bleomycin', 'blenoxane'],
  'mitomycin': ['mitomycin', 'mutamycin'],
  'vincristine': ['vincristine', 'oncovin', 'marqibo'],
  'vinblastine': ['vinblastine', 'velban'],
  'etoposide': ['etoposide', 'vepesid', 'etopophos'],
  'hydromorphone': ['hydromorphone', 'dilaudid', 'exalgo'],
  'oxycodone': ['oxycodone', 'oxycontin', 'roxicodone'],
  'midazolam': ['midazolam', 'versed'],
  'lorazepam': ['lorazepam', 'ativan'],
  'epinephrine': ['epinephrine', 'adrenalin', 'epipen'],
  'norepinephrine': ['norepinephrine', 'levophed'],
  'dopamine': ['dopamine', 'intropin'],
  'vasopressin': ['vasopressin', 'pitressin'],
  'mannitol': ['mannitol', 'osmitrol'],
  'furosemide': ['furosemide', 'lasix'],
  'potassium chloride': ['potassium chloride', 'kcl', 'k-dur'],
  'sodium chloride': ['sodium chloride', 'normal saline', 'nacl'],
  'dextrose': ['dextrose', 'd5w', 'd10w', 'd50w'],
  'heparin': ['heparin', 'unfractionated heparin'],
  'enoxaparin': ['enoxaparin', 'lovenox'],
};

const MANUFACTURER_SYNONYMS: Record<string, string[]> = {
  'fresenius kabi': ['fresenius', 'fresenius kabi', 'kabi', 'fka'],
  'baxter': ['baxter', 'baxter healthcare', 'bax'],
  'pfizer': ['pfizer', 'pfz', 'pharmacia'],
  'hospira': ['hospira', 'hsp', 'hospira worldwide'],
  'teva': ['teva', 'teva pharmaceuticals', 'teva generic'],
  'mylan': ['mylan', 'mylan pharmaceuticals'],
  'sandoz': ['sandoz', 'sandoz inc'],
  'novartis': ['novartis', 'novartis pharmaceuticals'],
  'roche': ['roche', 'genentech', 'roche laboratories'],
  'bristol myers squibb': ['bms', 'bristol myers', 'bristol myers squibb'],
  'merck': ['merck', 'merck & co', 'msd'],
  'johnson & johnson': ['j&j', 'johnson & johnson', 'janssen'],
  'abbvie': ['abbvie', 'abbott laboratories'],
  'gilead': ['gilead', 'gilead sciences'],
  'amgen': ['amgen', 'amgen inc'],
  'eli lilly': ['lilly', 'eli lilly', 'eli lilly and company'],
  'glaxosmithkline': ['gsk', 'glaxosmithkline', 'glaxo'],
  'astrazeneca': ['astrazeneca', 'az', 'zeneca'],
  'sanofi': ['sanofi', 'sanofi aventis'],
  'boehringer ingelheim': ['boehringer', 'boehringer ingelheim'],
};

const THERAPY_AREA_SYNONYMS: Record<string, string[]> = {
  'oncology': ['oncology', 'cancer', 'chemotherapy', 'chemo', 'tumor', 'malignancy', 'neoplasm', 'carcinoma'],
  'cardiology': ['cardiology', 'cardiac', 'heart', 'cardiovascular', 'cvd', 'coronary'],
  'neurology': ['neurology', 'neurological', 'brain', 'nervous system', 'cns', 'neuro'],
  'endocrinology': ['endocrinology', 'diabetes', 'diabetic', 'insulin', 'glucose', 'thyroid', 'hormonal'],
  'infectious disease': ['infectious', 'infection', 'antibiotic', 'antimicrobial', 'sepsis', 'bacteria', 'viral'],
  'critical care': ['critical care', 'icu', 'intensive care', 'emergency', 'resuscitation', 'life support'],
  'anesthesia': ['anesthesia', 'anesthetic', 'sedation', 'pain management', 'analgesic'],
  'nephrology': ['nephrology', 'kidney', 'renal', 'dialysis', 'urinary'],
  'gastroenterology': ['gastroenterology', 'gi', 'digestive', 'stomach', 'intestinal'],
  'hematology': ['hematology', 'blood', 'coagulation', 'bleeding', 'clotting', 'hemostasis'],
  'immunology': ['immunology', 'immune', 'immunosuppressive', 'autoimmune', 'transplant'],
  'psychiatry': ['psychiatry', 'mental health', 'psychiatric', 'depression', 'anxiety', 'psychotropic'],
};

const SUBSTANCE_TYPE_SYNONYMS: Record<string, string[]> = {
  'controlled substance': ['controlled', 'narcotic', 'opioid', 'scheduled', 'dea controlled', 'c-ii', 'c-iii', 'c-iv', 'c-v'],
  'injectable': ['injectable', 'injection', 'iv', 'intravenous', 'intramuscular', 'im', 'subcutaneous', 'sc'],
  'oral': ['oral', 'tablet', 'capsule', 'pill', 'po', 'by mouth'],
  'topical': ['topical', 'cream', 'ointment', 'gel', 'patch', 'transdermal'],
  'sterile': ['sterile', 'aseptic', 'parenteral', 'preservative-free'],
  'chemotherapy': ['chemotherapy', 'cytotoxic', 'antineoplastic', 'oncology drug'],
  'biologic': ['biologic', 'monoclonal antibody', 'protein', 'enzyme', 'vaccine'],
  'generic': ['generic', 'non-branded', 'off-patent'],
  'brand': ['brand', 'branded', 'innovator', 'reference'],
};

const RISK_SYNONYMS: Record<string, string[]> = {
  'high': ['high', 'critical', 'severe', 'urgent', 'extreme', 'dangerous', 'acute'],
  'medium': ['medium', 'moderate', 'average', 'standard', 'intermediate'],
  'low': ['low', 'minimal', 'minor', 'slight', 'negligible'],
};

// Conversational query patterns for natural language understanding
const CONVERSATIONAL_PATTERNS: Record<string, RegExp[]> = {
  'worry_concern': [
    /anything\s+(i|we)\s+should\s+be\s+worried\s+about/i,
    /should\s+(i|we)\s+be\s+concerned/i,
    /is\s+this\s+bad/i,
    /is\s+this\s+something\s+to\s+worry\s+about/i,
    /cause\s+for\s+concern/i,
    /anything\s+alarming/i
  ],
  'news_updates': [
    /what'?s\s+new/i,
    /any\s+updates/i,
    /latest\s+news/i,
    /what\s+changed/i,
    /recent\s+developments/i,
    /what\s+happened/i
  ],
  'explanation': [
    /what'?s\s+the\s+story/i,
    /explain\s+this/i,
    /tell\s+me\s+about\s+this/i,
    /why\s+is\s+this\s+happening/i,
    /what\s+caused\s+this/i,
    /what\s+does\s+this\s+mean/i
  ],
  'status_inquiry': [
    /how\s+are\s+things/i,
    /what'?s\s+going\s+on/i,
    /current\s+situation/i,
    /where\s+do\s+we\s+stand/i,
    /give\s+me\s+an?\s+update/i
  ],
  'forecast_inquiry': [
    /what\s+to\s+expect/i,
    /what'?s\s+coming/i,
    /future\s+outlook/i,
    /what\s+lies\s+ahead/i,
    /prediction/i
  ]
};

// Enhanced action intent patterns
const ACTION_PATTERNS: Record<string, RegExp[]> = {
  'summarize': [/summarize|summary|overview|recap|brief/i],
  'analyze': [/analyz|assess|evaluat|examin|review/i],
  'predict': [/predict|forecast|project|anticipat|estimat/i],
  'compare': [/compar|vs|versus|differ|contrast/i],
  'show': [/show|display|list|view|present/i],
  'explain': [/explain|why|how|what.*caus|reason/i],
  'identify': [/identif|find|detect|spot|locat/i],
  'monitor': [/monitor|track|watch|observ/i],
};

const FOCUS_PATTERNS: Record<string, RegExp[]> = {
  'shortage': [/shortag|scarcit|unavailabl|out.*stock|supply.*chain/i],
  'risk': [/risk|threat|danger|vulnerabil|concern/i],
  'trend': [/trend|pattern|chang|increas|decreas|shift/i],
  'status': [/status|current|state|condition|situation/i],
  'compliance': [/complianc|adherenc|conform|regulat/i],
  'performance': [/performanc|metric|kpi|measur/i],
  'forecast': [/forecast|prediction|future|project/i],
};

function extractTimeRange(query: string): number | undefined {
  // Extract time ranges from queries (return in days)
  const patterns = [
    { regex: /(\d+)\s*days?/i, multiplier: 1 },
    { regex: /(\d+)\s*weeks?/i, multiplier: 7 },
    { regex: /(\d+)\s*months?/i, multiplier: 30 },
    { regex: /next\s*(\d+)/i, multiplier: 1 },
    { regex: /(\d+)-day/i, multiplier: 1 },
    { regex: /(\d+)-week/i, multiplier: 7 },
    { regex: /(\d+)-month/i, multiplier: 30 },
  ];

  for (const pattern of patterns) {
    const match = query.match(pattern.regex);
    if (match) {
      return parseInt(match[1]) * pattern.multiplier;
    }
  }

  // Default ranges for common terms
  if (query.includes('short term') || query.includes('immediate')) return 7;
  if (query.includes('medium term')) return 30;
  if (query.includes('long term')) return 90;
  if (query.includes('quarter')) return 90;
  if (query.includes('year')) return 365;
  if (query.includes('current') || query.includes('today')) return 1;

  return undefined;
}

function extractEntities(query: string, synonymMap: Record<string, string[]>): string[] {
  const found: string[] = [];
  const lowerQuery = query.toLowerCase();
  
  for (const [canonical, synonyms] of Object.entries(synonymMap)) {
    for (const synonym of synonyms) {
      if (lowerQuery.includes(synonym.toLowerCase())) {
        found.push(canonical);
        break;
      }
    }
  }
  
  return [...new Set(found)]; // Remove duplicates
}

function extractActionIntent(query: string): { action: string; focus: string; scope: string } {
  const lowerQuery = query.toLowerCase();
  
  let action = 'general';
  let focus = 'general';
  let scope = 'portfolio';

  // Check for conversational patterns first
  for (const [pattern, regexes] of Object.entries(CONVERSATIONAL_PATTERNS)) {
    if (regexes.some(regex => regex.test(query))) {
      switch (pattern) {
        case 'worry_concern':
          action = 'assess_risk';
          focus = 'concern';
          scope = 'portfolio';
          break;
        case 'news_updates':
          action = 'summarize';
          focus = 'updates';
          scope = 'recent';
          break;
        case 'explanation':
          action = 'explain';
          focus = 'context';
          scope = 'detailed';
          break;
        case 'status_inquiry':
          action = 'report_status';
          focus = 'current';
          scope = 'overview';
          break;
        case 'forecast_inquiry':
          action = 'forecast';
          focus = 'prediction';
          scope = 'future';
          break;
      }
      return { action, focus, scope };
    }
  }
  
  // Extract action using original patterns
  for (const [act, patterns] of Object.entries(ACTION_PATTERNS)) {
    if (patterns.some(pattern => pattern.test(query))) {
      action = act;
      break;
    }
  }
  
  // Extract focus
  for (const [foc, patterns] of Object.entries(FOCUS_PATTERNS)) {
    if (patterns.some(pattern => pattern.test(query))) {
      focus = foc;
      break;
    }
  }
  
  // Determine scope
  if (lowerQuery.includes('portfolio') || lowerQuery.includes('all drugs') || lowerQuery.includes('entire')) {
    scope = 'portfolio';
  } else if (lowerQuery.includes('category') || lowerQuery.includes('therapy') || lowerQuery.includes('class')) {
    scope = 'category';
  } else if (lowerQuery.includes('manufacturer') || lowerQuery.includes('supplier')) {
    scope = 'manufacturer';
  } else if (lowerQuery.includes('drug') || lowerQuery.includes('medication') || lowerQuery.includes('substance')) {
    scope = 'drug';
  }
  
  return { action, focus, scope };
}

function findDrugMentions(query: string, ndcData: any[]): string[] {
  const found: string[] = [];
  const lowerQuery = query.toLowerCase();
  
  // Check for direct NDC ID matches
  for (const item of ndcData) {
    if (lowerQuery.includes(item.id?.toLowerCase() || '')) {
      found.push(item.name);
    }
  }
  
  // Check against drug names in data
  for (const item of ndcData) {
    const drugName = item.name.toLowerCase();
    if (lowerQuery.includes(drugName)) {
      found.push(item.name);
    }
  }
  
  // Check against synonyms
  for (const [canonical, synonyms] of Object.entries(DRUG_SYNONYMS)) {
    for (const synonym of synonyms) {
      if (lowerQuery.includes(synonym.toLowerCase())) {
        // Find all corresponding NDC data
        const matchedItems = ndcData.filter(item => 
          item.name.toLowerCase().includes(canonical.toLowerCase()) ||
          synonyms.some(syn => item.name.toLowerCase().includes(syn.toLowerCase()))
        );
        found.push(...matchedItems.map(item => item.name));
        break;
      }
    }
  }
  
  return [...new Set(found)]; // Remove duplicates
}

function findComparisonTargets(query: string): string[] {
  const lowerQuery = query.toLowerCase();
  const comparisonWords = ['vs', 'versus', 'compare', 'between', 'and'];
  
  for (const word of comparisonWords) {
    if (lowerQuery.includes(word)) {
      // Extract drug names around comparison words
      const drugs = extractEntities(query, DRUG_SYNONYMS);
      if (drugs.length >= 2) {
        return drugs;
      }
    }
  }
  
  return [];
}

function categorizeQuery(query: string): QueryIntent['type'] {
  const lowerQuery = query.toLowerCase();
  
  // Check conversational patterns first for more natural categorization
  for (const [pattern, regexes] of Object.entries(CONVERSATIONAL_PATTERNS)) {
    if (regexes.some(regex => regex.test(query))) {
      switch (pattern) {
        case 'worry_concern':
          return 'risk_inquiry';
        case 'news_updates':
          return 'status_check';
        case 'explanation':
          return 'trend_analysis';
        case 'status_inquiry':
          return 'summarization';
        case 'forecast_inquiry':
          return 'forecast_request';
      }
    }
  }
  
  // Summarization queries
  if (lowerQuery.includes('summarize') || lowerQuery.includes('summary') || 
      lowerQuery.includes('overview') || lowerQuery.includes('recap')) {
    return 'summarization';
  }
  
  // Status check queries
  if (lowerQuery.includes('status') || lowerQuery.includes('current') || 
      lowerQuery.includes('situation') || lowerQuery.includes('state')) {
    return 'status_check';
  }
  
  // Risk-related queries
  if (lowerQuery.includes('risk') || lowerQuery.includes('danger') || 
      lowerQuery.includes('threat') || lowerQuery.includes('concern')) {
    return 'risk_inquiry';
  }
  
  // Forecast/prediction queries
  if (lowerQuery.includes('forecast') || lowerQuery.includes('predict') || 
      lowerQuery.includes('future') || lowerQuery.includes('project')) {
    return 'forecast_request';
  }
  
  // Feature importance queries
  if (lowerQuery.includes('feature') || lowerQuery.includes('factor') || 
      lowerQuery.includes('importance') || lowerQuery.includes('contribut')) {
    return 'feature_importance';
  }
  
  // Comparison queries
  if (lowerQuery.includes('compare') || lowerQuery.includes('vs') || 
      lowerQuery.includes('versus') || lowerQuery.includes('difference')) {
    return 'comparison';
  }
  
  // Trend analysis
  if (lowerQuery.includes('trend') || lowerQuery.includes('pattern') || 
      lowerQuery.includes('change') || lowerQuery.includes('analysis')) {
    return 'trend_analysis';
  }
  
  return 'general';
}

function extractRiskLevel(query: string): string | undefined {
  const lowerQuery = query.toLowerCase();
  
  for (const [level, synonyms] of Object.entries(RISK_SYNONYMS)) {
    for (const synonym of synonyms) {
      if (lowerQuery.includes(synonym)) {
        return level;
      }
    }
  }
  
  return undefined;
}

export function analyzeQuery(query: string, ndcData: any[]): QueryIntent {
  const queryType = categorizeQuery(query);
  const drugs = findDrugMentions(query, ndcData);
  const manufacturers = extractEntities(query, MANUFACTURER_SYNONYMS);
  const therapyAreas = extractEntities(query, THERAPY_AREA_SYNONYMS);
  const substanceTypes = extractEntities(query, SUBSTANCE_TYPE_SYNONYMS);
  const timeRange = extractTimeRange(query);
  const riskLevel = extractRiskLevel(query);
  const comparisonTarget = findComparisonTargets(query);
  const intent = extractActionIntent(query);
  
  // Calculate confidence based on entity extraction success
  let confidence = 0.3; // Base confidence
  if (drugs.length > 0) confidence += 0.2;
  if (manufacturers.length > 0) confidence += 0.15;
  if (therapyAreas.length > 0) confidence += 0.15;
  if (substanceTypes.length > 0) confidence += 0.1;
  if (timeRange) confidence += 0.1;
  if (riskLevel) confidence += 0.1;
  if (comparisonTarget.length > 0) confidence += 0.1;
  
  return {
    type: queryType,
    confidence: Math.min(confidence, 1.0),
    entities: {
      drugs: drugs.length > 0 ? drugs : undefined,
      manufacturers: manufacturers.length > 0 ? manufacturers : undefined,
      therapyAreas: therapyAreas.length > 0 ? therapyAreas : undefined,
      substanceTypes: substanceTypes.length > 0 ? substanceTypes : undefined,
      timeRange,
      riskLevel,
      comparisonTarget: comparisonTarget.length > 0 ? comparisonTarget : undefined,
    },
    intent,
  };
}

// Export helper functions
export { extractTimeRange, findDrugMentions, categorizeQuery, extractRiskLevel };