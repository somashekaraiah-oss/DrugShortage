import { NDCData } from "@/components/SyntheticDataGenerator";
import { QueryIntent } from "@/utils/semanticMatching";

export interface DataInsight {
  type: 'table' | 'metric' | 'alert' | 'trend';
  title: string;
  content: string | Array<Record<string, any>>;
  severity?: 'low' | 'medium' | 'high';
}

// Enhanced RAG-based contextual response generation with pharmaceutical intelligence
export function generateContextualResponse(
  query: string, 
  data: NDCData[], 
  intent: QueryIntent
): { text: string; insights: DataInsight[] } {
  const { type, entities } = intent;
  
  // Advanced semantic matching for drug identification with enhanced filtering
  const relevantData = findRelevantData(data, intent);
  let insights: DataInsight[] = [];
  let responseText = "";

  // Handle conversational queries with contextual understanding
  if (/anything.*worried|should.*concerned|is.*bad/i.test(query)) {
    return generateWorryResponse(query, data, intent);
  }
  
  if (/what'?s\s+new|latest|recent|updates/i.test(query)) {
    return generateNewsResponse(query, data, intent);
  }
  
  if (/what'?s\s+the\s+story|explain.*spike|behind.*spike/i.test(query)) {
    return generateExplanationResponse(query, relevantData, intent, data);
  }

  // Contextual analysis based on pharmaceutical domain knowledge
  const portfolioAnalysis = analyzePortfolioContext(data);
  const shortagePattern = identifyShortagePatterns(data);

  switch (type) {
    case 'summarization':
      ({ text: responseText, insights } = generateSummarizationResponse(query, relevantData, intent, data));
      break;
    case 'status_check':
      ({ text: responseText, insights } = generateStatusResponse(query, relevantData, intent, data));
      break;
    case 'forecast_request':
      ({ text: responseText, insights } = generateForecastResponse(query, relevantData, intent));
      break;
    case 'risk_inquiry':
      ({ text: responseText, insights } = generateRiskResponse(query, relevantData, intent));
      break;
    case 'comparison':
      ({ text: responseText, insights } = generateComparisonResponse(query, relevantData, intent, data));
      break;
    case 'trend_analysis':
      ({ text: responseText, insights } = generateTrendResponse(query, relevantData, intent, data));
      break;
    case 'feature_importance':
      ({ text: responseText, insights } = generateFeatureResponse(query, relevantData, intent));
      break;
    default:
      ({ text: responseText, insights } = generateGeneralResponse(query, relevantData, intent));
  }

  // Add contextual insights based on query scope
  if (intent.intent.scope === 'portfolio' || relevantData.length === 0) {
    insights.push(
      {
        type: 'metric',
        title: 'Portfolio Overview',
        content: `${portfolioAnalysis.totalDrugs} total drugs monitored, ${portfolioAnalysis.criticalDrugs} critical risk`,
      },
      {
        type: 'alert',
        title: 'Active Shortages',
        content: `${portfolioAnalysis.shortageActive} drugs currently experiencing shortages`,
        severity: portfolioAnalysis.shortageActive > 0 ? 'high' : 'low'
      }
    );
  }

  return { text: responseText, insights };
}

function findRelevantData(ndcData: NDCData[], queryIntent: QueryIntent): NDCData[] {
  let relevantData = ndcData;

  // Filter by drugs if mentioned
  if (queryIntent.entities.drugs && queryIntent.entities.drugs.length > 0) {
    relevantData = relevantData.filter(item =>
      queryIntent.entities.drugs!.some(drug =>
        item.name.toLowerCase().includes(drug.toLowerCase())
      )
    );
  }

  // Filter by manufacturers if mentioned
  if (queryIntent.entities.manufacturers && queryIntent.entities.manufacturers.length > 0) {
    relevantData = relevantData.filter(item =>
      queryIntent.entities.manufacturers!.some(manufacturer =>
        (item as any).manufacturer?.toLowerCase().includes(manufacturer.toLowerCase())
      )
    );
  }

  // Filter by therapy areas if mentioned
  if (queryIntent.entities.therapyAreas && queryIntent.entities.therapyAreas.length > 0) {
    relevantData = relevantData.filter(item =>
      queryIntent.entities.therapyAreas!.some(area => {
        const category = (item as any).category?.toLowerCase() || '';
        const drugName = item.name.toLowerCase();
        
        if (area === 'oncology') {
          return category.includes('oncology') || drugName.includes('cisplatin') || 
                 drugName.includes('carboplatin') || drugName.includes('doxorubicin') ||
                 drugName.includes('paclitaxel') || drugName.includes('methotrexate');
        }
        if (area === 'critical care') {
          return drugName.includes('propofol') || drugName.includes('norepinephrine') ||
                 drugName.includes('epinephrine') || drugName.includes('dopamine');
        }
        if (area === 'endocrinology') {
          return drugName.includes('insulin') || category.includes('diabetes');
        }
        
        return category.includes(area) || drugName.includes(area);
      })
    );
  }

  // Filter by substance types if mentioned
  if (queryIntent.entities.substanceTypes && queryIntent.entities.substanceTypes.length > 0) {
    relevantData = relevantData.filter(item =>
      queryIntent.entities.substanceTypes!.some(type => {
        const drugName = item.name.toLowerCase();
        const category = (item as any).category?.toLowerCase() || '';
        
        if (type === 'controlled substance') {
          return drugName.includes('morphine') || drugName.includes('fentanyl') ||
                 drugName.includes('hydromorphone') || drugName.includes('oxycodone') ||
                 drugName.includes('midazolam') || drugName.includes('lorazepam');
        }
        if (type === 'injectable') {
          return drugName.includes('injection') || drugName.includes('iv') ||
                 category.includes('injectable') || drugName.includes('infusion');
        }
        if (type === 'chemotherapy') {
          return category.includes('oncology') || drugName.includes('cisplatin') ||
                 drugName.includes('carboplatin') || drugName.includes('doxorubicin') ||
                 drugName.includes('paclitaxel') || drugName.includes('methotrexate');
        }
        return false;
      })
    );
  }

  // Filter by risk level if specified
  if (queryIntent.entities.riskLevel) {
    relevantData = relevantData.filter(item =>
      item.riskLevel.toLowerCase() === queryIntent.entities.riskLevel!.toLowerCase()
    );
  }

  return relevantData;
}

function generateSummarizationResponse(query: string, relevantData: NDCData[], queryIntent: QueryIntent, allData: NDCData[]): { text: string; insights: DataInsight[] } {
  const insights: DataInsight[] = [];
  let text = "";

  if (queryIntent.entities.therapyAreas?.includes('oncology')) {
    const oncologyDrugs = relevantData.length > 0 ? relevantData : allData.filter(item => {
      const drugName = item.name.toLowerCase();
      const category = (item as any).category?.toLowerCase() || '';
      return category.includes('oncology') || drugName.includes('cisplatin') ||
             drugName.includes('carboplatin') || drugName.includes('doxorubicin') ||
             drugName.includes('paclitaxel') || drugName.includes('methotrexate');
    });
    
    const highRisk = oncologyDrugs.filter(d => d.riskLevel === 'high').length;
    const mediumRisk = oncologyDrugs.filter(d => d.riskLevel === 'medium').length;
    const avgCompliance = oncologyDrugs.reduce((sum, d) => sum + d.complianceScore, 0) / oncologyDrugs.length;
    
    text = `**Oncology Drug Shortage Summary:**\n\nMonitoring ${oncologyDrugs.length} oncology medications. Current risk distribution: ${highRisk} high-risk, ${mediumRisk} medium-risk drugs. Average compliance score: ${(avgCompliance * 100).toFixed(1)}%. Key concerns include critical chemotherapy agents with supply chain vulnerabilities.`;
    
    insights.push(
      {
        type: 'alert',
        title: 'Critical Oncology Drugs',
        content: `${highRisk} oncology drugs at high shortage risk`,
        severity: highRisk > 3 ? 'high' : 'medium'
      },
      {
        type: 'table',
        title: 'Oncology Risk Breakdown',
        content: [
          { 'Risk Level': 'High', 'Count': highRisk.toString(), 'Examples': oncologyDrugs.filter(d => d.riskLevel === 'high').slice(0, 3).map(d => d.name.split(' ')[0]).join(', ') },
          { 'Risk Level': 'Medium', 'Count': mediumRisk.toString(), 'Examples': oncologyDrugs.filter(d => d.riskLevel === 'medium').slice(0, 3).map(d => d.name.split(' ')[0]).join(', ') },
          { 'Risk Level': 'Low', 'Count': (oncologyDrugs.length - highRisk - mediumRisk).toString(), 'Examples': oncologyDrugs.filter(d => d.riskLevel === 'low').slice(0, 3).map(d => d.name.split(' ')[0]).join(', ') }
        ]
      }
    );
  } else if (queryIntent.entities.substanceTypes?.includes('controlled substance')) {
    const controlledDrugs = relevantData.length > 0 ? relevantData : allData.filter(item => {
      const drugName = item.name.toLowerCase();
      return drugName.includes('morphine') || drugName.includes('fentanyl') ||
             drugName.includes('hydromorphone') || drugName.includes('oxycodone') ||
             drugName.includes('midazolam') || drugName.includes('lorazepam');
    });
    
    const criticalShortages = controlledDrugs.filter(d => d.shortageFlag).length;
    const avgCompliance = controlledDrugs.reduce((sum, d) => sum + d.complianceScore, 0) / controlledDrugs.length;
    
    text = `**Controlled Substance Risk Overview:**\n\nTracking ${controlledDrugs.length} controlled substances. ${criticalShortages} currently flagged for shortage. Average DEA compliance: ${(avgCompliance * 100).toFixed(1)}%. Enhanced monitoring required due to regulatory constraints and manufacturing quotas.`;
    
    insights.push(
      {
        type: 'alert',
        title: 'DEA Controlled Substances',
        content: `${criticalShortages} controlled substances with active shortage flags`,
        severity: criticalShortages > 0 ? 'high' : 'low'
      }
    );
  } else if (queryIntent.entities.manufacturers?.includes('fresenius kabi')) {
    const freseniusDrugs = relevantData.length > 0 ? relevantData : allData.filter(item => {
      const manufacturer = (item as any).manufacturer?.toLowerCase() || '';
      return manufacturer.includes('fresenius');
    });
    
    const shortageCount = freseniusDrugs.filter(d => d.shortageFlag).length;
    const avgCompliance = freseniusDrugs.reduce((sum, d) => sum + d.complianceScore, 0) / freseniusDrugs.length;
    
    text = `**Fresenius Kabi Portfolio Status:**\n\nCurrent portfolio: ${freseniusDrugs.length} products. Active shortages: ${shortageCount}. Manufacturing compliance average: ${(avgCompliance * 100).toFixed(1)}%. Recent FDA inspections and facility remediations may impact supply continuity.`;
    
    insights.push(
      {
        type: 'metric',
        title: 'Fresenius Kabi Portfolio',
        content: `${freseniusDrugs.length} products, ${shortageCount} shortages`
      }
    );
  } else if (queryIntent.entities.substanceTypes?.includes('injectable')) {
    const injectableDrugs = relevantData.length > 0 ? relevantData : allData.filter(item => {
      const drugName = item.name.toLowerCase();
      const category = (item as any).category?.toLowerCase() || '';
      return drugName.includes('injection') || drugName.includes('iv') ||
             category.includes('injectable') || drugName.includes('infusion');
    });
    
    text = `**Injectable Medication Patterns:**\n\nAnalyzing ${injectableDrugs.length} injectable products. Sterile manufacturing constraints and quality issues drive shortage risks. Recommend diversified supplier strategy and inventory buffers.`;
  }

  if (!text) {
    text = `**Portfolio Summary:**\n\nAnalyzed ${relevantData.length} drugs matching your criteria. No specific patterns identified for the requested category.`;
  }

  return { text, insights };
}

function generateStatusResponse(query: string, relevantData: NDCData[], queryIntent: QueryIntent, allData: NDCData[]): { text: string; insights: DataInsight[] } {
  const insights: DataInsight[] = [];
  let text = "";

  // Handle conversational "what's new" queries
  if (/what'?s\s+new|latest|recent|updates/i.test(query)) {
    const recentAlerts = allData.filter(d => d.shortageFlag).slice(0, 5);
    const highRiskDrugs = allData.filter(d => d.riskLevel === 'high').slice(0, 3);
    
    text = `**📋 Latest Updates:**\n\n`;
    if (recentAlerts.length > 0) {
      text += `🚨 **Active Shortages (${recentAlerts.length}):**\n`;
      recentAlerts.forEach(drug => {
        text += `• ${drug.name.split(' ')[0]} - ${drug.riskLevel} risk\n`;
      });
      text += `\n`;
    }
    
    if (highRiskDrugs.length > 0) {
      text += `⚠️ **High-Risk Drugs Requiring Attention:**\n`;
      highRiskDrugs.forEach(drug => {
        text += `• ${drug.name.split(' ')[0]} - Compliance: ${(drug.complianceScore * 100).toFixed(0)}%\n`;
      });
    }
    
    insights.push({
      type: 'alert',
      title: 'Current Alerts',
      content: `${recentAlerts.length} active shortages, ${highRiskDrugs.length} high-risk drugs`,
      severity: recentAlerts.length > 0 ? 'high' : 'medium'
    });
    
    return { text, insights };
  }

  if (queryIntent.entities.manufacturers?.includes('fresenius kabi')) {
    const freseniusDrugs = allData.filter(item => {
      const manufacturer = (item as any).manufacturer?.toLowerCase() || '';
      return manufacturer.includes('fresenius');
    });
    
    const activeShortages = freseniusDrugs.filter(d => d.shortageFlag);
    const highRisk = freseniusDrugs.filter(d => d.riskLevel === 'high');
    
    text = `**Current Fresenius Kabi Status:**\n\n✓ Portfolio size: ${freseniusDrugs.length} products\n⚠️ Active shortages: ${activeShortages.length}\n🔴 High-risk products: ${highRisk.length}\n\nKey issues: Manufacturing facility compliance, FDA remediation requirements, and supply chain disruptions affecting injectable portfolio.`;
    
    insights.push(
      {
        type: 'alert',
        title: 'Fresenius Manufacturing Alert',
        content: `Multiple facility inspections impacting ${activeShortages.length} products`,
        severity: activeShortages.length > 0 ? 'high' : 'medium'
      }
    );
  }

  if (!text && relevantData.length > 0) {
    const shortageCount = relevantData.filter(d => d.shortageFlag).length;
    const avgCompliance = relevantData.reduce((sum, d) => sum + d.complianceScore, 0) / relevantData.length;
    
    text = `**Current Status Summary:**\n\n${relevantData.length} products monitored\n${shortageCount} active shortage alerts\nAverage compliance: ${(avgCompliance * 100).toFixed(1)}%`;
  }

  return { text, insights };
}

function generateComparisonResponse(query: string, relevantData: NDCData[], queryIntent: QueryIntent, allData: NDCData[]): { text: string; insights: DataInsight[] } {
  const insights: DataInsight[] = [];
  let text = "";

  if (queryIntent.entities.comparisonTarget && queryIntent.entities.comparisonTarget.length >= 2) {
    const drug1Name = queryIntent.entities.comparisonTarget[0];
    const drug2Name = queryIntent.entities.comparisonTarget[1];
    
    const drug1 = allData.find(d => d.name.toLowerCase().includes(drug1Name.toLowerCase()));
    const drug2 = allData.find(d => d.name.toLowerCase().includes(drug2Name.toLowerCase()));
    
    if (drug1 && drug2) {
      text = `**${drug1.name.split(' ')[0]} vs ${drug2.name.split(' ')[0]} Comparison:**\n\n`;
      text += `Risk Level: ${drug1.riskLevel} vs ${drug2.riskLevel}\n`;
      text += `Compliance: ${(drug1.complianceScore * 100).toFixed(1)}% vs ${(drug2.complianceScore * 100).toFixed(1)}%\n`;
      text += `Manufacturer: ${(drug1 as any).manufacturer || 'Unknown'} vs ${(drug2 as any).manufacturer || 'Unknown'}\n`;
      text += `Shortage Status: ${drug1.shortageFlag ? 'Active' : 'None'} vs ${drug2.shortageFlag ? 'Active' : 'None'}`;
      
      insights.push({
        type: 'table',
        title: 'Drug Comparison',
        content: [
          { 'Metric': 'Risk Level', [drug1.name.split(' ')[0]]: drug1.riskLevel, [drug2.name.split(' ')[0]]: drug2.riskLevel },
          { 'Metric': 'Compliance Score', [drug1.name.split(' ')[0]]: `${(drug1.complianceScore * 100).toFixed(1)}%`, [drug2.name.split(' ')[0]]: `${(drug2.complianceScore * 100).toFixed(1)}%` },
          { 'Metric': 'Manufacturer', [drug1.name.split(' ')[0]]: (drug1 as any).manufacturer || 'Unknown', [drug2.name.split(' ')[0]]: (drug2 as any).manufacturer || 'Unknown' },
          { 'Metric': 'Shortage Flag', [drug1.name.split(' ')[0]]: drug1.shortageFlag ? 'Yes' : 'No', [drug2.name.split(' ')[0]]: drug2.shortageFlag ? 'Yes' : 'No' }
        ]
      });
    }
  }

  return { text, insights };
}

function generateTrendResponse(query: string, relevantData: NDCData[], queryIntent: QueryIntent, allData: NDCData[]): { text: string; insights: DataInsight[] } {
  const insights: DataInsight[] = [];
  let text = "";

  if (queryIntent.entities.substanceTypes?.includes('injectable')) {
    const injectables = allData.filter(item => {
      const drugName = item.name.toLowerCase();
      const category = (item as any).category?.toLowerCase() || '';
      return drugName.includes('injection') || drugName.includes('iv') ||
             category.includes('injectable') || drugName.includes('infusion');
    });
    
    const highRiskInjectables = injectables.filter(d => d.riskLevel === 'high').length;
    const shortageInjectables = injectables.filter(d => d.shortageFlag).length;
    
    text = `**Injectable Drug Shortage Trends:**\n\nSterile manufacturing constraints continue driving shortages. ${highRiskInjectables} of ${injectables.length} injectables at high risk. Quality issues and facility remediations are primary drivers. Trend: Increasing consolidation among sterile manufacturers creates vulnerability.`;
    
    insights.push({
      type: 'alert',
      title: 'Injectable Manufacturing Crisis',
      content: `${shortageInjectables} injectable drugs currently in shortage`,
      severity: 'high'
    });
  }

  return { text, insights };
}

function generateForecastResponse(query: string, relevantData: NDCData[], queryIntent: QueryIntent): { text: string; insights: DataInsight[] } {
  const insights: DataInsight[] = [];
  let text = "";

  if (relevantData.length > 0) {
    const drug = relevantData[0];
    const timeRange = queryIntent.entities.timeRange || 14;
    
    // Generate forecast data
    const forecastData = Array.from({ length: Math.min(timeRange, 14) }, (_, i) => {
      const day = i + 1;
      const baseRisk = drug.shortageFlag ? 0.7 : 0.3;
      const trend = drug.forecastTrend / 100;
      const probability = Math.max(0, Math.min(1, baseRisk + (trend * day * 0.01) + (Math.random() - 0.5) * 0.1));
      
      return {
        'Day': `Day ${day}`,
        'Shortage Risk': `${(probability * 100).toFixed(1)}%`,
        'Confidence': `${(75 + Math.random() * 20).toFixed(1)}%`,
        'Status': probability > 0.6 ? '🔴 High' : probability > 0.4 ? '🟡 Medium' : '🟢 Low'
      };
    });

    insights.push({
      type: 'table',
      title: `${timeRange}-Day Forecast: ${drug.name.split(' ')[0]}`,
      content: forecastData
    });

    text = `**${timeRange}-Day Forecast: ${drug.name.split(' ')[0]}**\n\nShortage probability trend: ${drug.forecastTrend > 0 ? 'Increasing' : 'Decreasing'}. Current compliance: ${(drug.complianceScore * 100).toFixed(1)}%.`;
  }

  return { text, insights };
}

function generateRiskResponse(query: string, relevantData: NDCData[], queryIntent: QueryIntent): { text: string; insights: DataInsight[] } {
  const insights: DataInsight[] = [];
  let text = "";

  if (relevantData.length > 0) {
    const drug = relevantData[0];
    
    const riskFactors = [
      { 'Factor': 'Compliance Score', 'Value': `${(drug.complianceScore * 100).toFixed(1)}%`, 'Impact': drug.complianceScore < 0.7 ? 'High Risk' : 'Normal' },
      { 'Factor': 'Inspection Gap', 'Value': `${drug.inspectionGap} days`, 'Impact': drug.inspectionGap > 365 ? 'High Risk' : 'Normal' },
      { 'Factor': 'Manufacturer Tier', 'Value': `Tier ${drug.manufacturerTier}`, 'Impact': drug.manufacturerTier === 3 ? 'Medium Risk' : 'Low Risk' },
      { 'Factor': 'Current Shortage', 'Value': drug.shortageFlag ? 'Yes' : 'No', 'Impact': drug.shortageFlag ? 'Critical' : 'Normal' },
      { 'Factor': 'Risk Level', 'Value': drug.riskLevel.toUpperCase(), 'Impact': drug.riskLevel === 'high' ? 'High Risk' : drug.riskLevel === 'medium' ? 'Medium Risk' : 'Low Risk' }
    ];

    insights.push({
      type: 'table',
      title: `Risk Factor Analysis: ${drug.name.split(' ')[0]}`,
      content: riskFactors
    });

    text = `**Risk Assessment: ${drug.name.split(' ')[0]}**\n\nOverall Risk: **${drug.riskLevel.toUpperCase()}**\nCompliance: ${(drug.complianceScore * 100).toFixed(1)}%\nShortage Status: ${drug.shortageFlag ? 'Active' : 'Normal'}`;
  }

  return { text, insights };
}

function generateFeatureResponse(query: string, relevantData: NDCData[], queryIntent: QueryIntent): { text: string; insights: DataInsight[] } {
  const insights: DataInsight[] = [];
  let text = "";

  if (relevantData.length > 0) {
    const drug = relevantData[0];
    
    const featureData = [
      { 'Feature': 'Compliance Score', 'Importance': '85%', 'Impact': 'High' },
      { 'Feature': 'Manufacturing Capacity', 'Importance': '78%', 'Impact': 'High' },
      { 'Feature': 'Supplier Concentration', 'Importance': '72%', 'Impact': 'Medium' },
      { 'Feature': 'Regulatory History', 'Importance': '68%', 'Impact': 'Medium' },
      { 'Feature': 'Market Demand', 'Importance': '55%', 'Impact': 'Low' }
    ];

    insights.push({
      type: 'table',
      title: `Feature Importance for ${drug.name.split(' ')[0]}`,
      content: featureData
    });

    text = `**Feature Importance Analysis: ${drug.name.split(' ')[0]}**\n\nTop factors contributing to shortage risk prediction identified by our AI model.`;
  }

  return { text, insights };
}

function generateGeneralResponse(query: string, relevantData: NDCData[], queryIntent: QueryIntent): { text: string; insights: DataInsight[] } {
  const text = `I've analyzed your query about drug shortage management. Based on the current data, I found ${relevantData.length} relevant drugs in your portfolio. The system monitors risk factors including compliance scores, shortage history, and supply chain indicators to predict potential shortages.`;
  
  const insights: DataInsight[] = [
    {
      type: 'metric',
      title: 'Query Analysis',
      content: `Confidence: ${Math.round(queryIntent.confidence * 100)}%`,
    }
  ];

  return { text, insights };
}

// Portfolio-wide contextual analysis
function analyzePortfolioContext(data: NDCData[]) {
  const totalDrugs = data.length;
  const criticalDrugs = data.filter(d => d.riskLevel === 'high').length;
  const shortageActive = data.filter(d => d.shortageFlag).length;
  const avgCompliance = data.reduce((sum, d) => sum + d.complianceScore, 0) / totalDrugs;
  
  // Risk concentration analysis
  const riskByCategory = data.reduce((acc, drug) => {
    const category = (drug as any).category || 'unknown';
    if (!acc[category]) acc[category] = { total: 0, high: 0 };
    acc[category].total++;
    if (drug.riskLevel === 'high') acc[category].high++;
    return acc;
  }, {} as Record<string, { total: number; high: number }>);
  
  return {
    totalDrugs,
    criticalDrugs,
    shortageActive,
    avgCompliance,
    riskByCategory,
    riskScore: (criticalDrugs / totalDrugs) * 100
  };
}

// Pattern recognition for shortage prediction
function identifyShortagePatterns(data: NDCData[]) {
  const patterns = {
    manufacturerRisk: {} as Record<string, number>,
    categoryRisk: {} as Record<string, number>,
    seasonalTrends: {} as Record<string, number>,
    supplyChainVulnerabilities: [] as string[]
  };
  
  // Manufacturer concentration risk
  data.forEach(drug => {
    const manufacturer = (drug as any).manufacturer || 'Unknown';
    if (!patterns.manufacturerRisk[manufacturer]) patterns.manufacturerRisk[manufacturer] = 0;
    if (drug.shortageFlag || drug.riskLevel === 'high') {
      patterns.manufacturerRisk[manufacturer]++;
    }
  });
  
  // Category-based risk patterns
  data.forEach(drug => {
    const category = (drug as any).category || 'unknown';
    if (!patterns.categoryRisk[category]) patterns.categoryRisk[category] = 0;
    if (drug.shortageFlag) patterns.categoryRisk[category]++;
  });
  
  // Identify supply chain vulnerabilities
  const highRiskManufacturers = Object.entries(patterns.manufacturerRisk)
    .filter(([_, count]) => count > 2)
    .map(([name]) => name);
  
  patterns.supplyChainVulnerabilities = [
    ...highRiskManufacturers.map(m => `High shortage concentration: ${m}`),
    'Single-source oncology medications',
    'Controlled substance regulatory bottlenecks'
  ];
  
  return patterns;
}

// Conversational response handlers
function generateWorryResponse(query: string, data: NDCData[], intent: QueryIntent): { text: string; insights: DataInsight[] } {
  const insights: DataInsight[] = [];
  const highRiskDrugs = data.filter(d => d.riskLevel === 'high');
  const activeShortages = data.filter(d => d.shortageFlag);
  const lowCompliance = data.filter(d => d.complianceScore < 0.7);
  
  let text = "";
  
  if (highRiskDrugs.length > 0 || activeShortages.length > 0 || lowCompliance.length > 0) {
    text = `**🚨 Yes, there are concerns that need your attention:**\n\n`;
    
    if (activeShortages.length > 0) {
      text += `❗ **Active Shortages:** ${activeShortages.length} drugs currently experiencing shortages\n`;
      text += `   Critical: ${activeShortages.map(d => d.name.split(' ')[0]).slice(0, 3).join(', ')}\n\n`;
    }
    
    if (highRiskDrugs.length > 0) {
      text += `⚠️ **High Risk:** ${highRiskDrugs.length} drugs at elevated shortage risk\n`;
      text += `   Watch closely: ${highRiskDrugs.map(d => d.name.split(' ')[0]).slice(0, 3).join(', ')}\n\n`;
    }
    
    if (lowCompliance.length > 0) {
      text += `📉 **Compliance Issues:** ${lowCompliance.length} drugs with compliance < 70%\n`;
    }
    
    text += `\n**Recommended Actions:**\n• Increase inventory for critical items\n• Contact alternative suppliers\n• Monitor manufacturing status closely`;
    
    insights.push({
      type: 'alert',
      title: 'Immediate Concerns',
      content: `${activeShortages.length + highRiskDrugs.length} drugs need attention`,
      severity: activeShortages.length > 0 ? 'high' : 'medium'
    });
  } else {
    text = `**✅ Good news - no immediate concerns!**\n\nAll monitored drugs are showing stable supply patterns with acceptable risk levels. Continue regular monitoring as scheduled.`;
    
    insights.push({
      type: 'metric',
      title: 'Portfolio Status',
      content: 'All systems normal - no critical alerts',
      severity: 'low'
    });
  }
  
  return { text, insights };
}

function generateNewsResponse(query: string, data: NDCData[], intent: QueryIntent): { text: string; insights: DataInsight[] } {
  const insights: DataInsight[] = [];
  const recentAlerts = data.filter(d => d.shortageFlag).slice(0, 5);
  const highRiskDrugs = data.filter(d => d.riskLevel === 'high').slice(0, 3);
  
  let text = `**📋 Latest Updates:**\n\n`;
  if (recentAlerts.length > 0) {
    text += `🚨 **Active Shortages (${recentAlerts.length}):**\n`;
    recentAlerts.forEach(drug => {
      text += `• ${drug.name.split(' ')[0]} - ${drug.riskLevel} risk\n`;
    });
    text += `\n`;
  }
  
  if (highRiskDrugs.length > 0) {
    text += `⚠️ **High-Risk Drugs Requiring Attention:**\n`;
    highRiskDrugs.forEach(drug => {
      text += `• ${drug.name.split(' ')[0]} - Compliance: ${(drug.complianceScore * 100).toFixed(0)}%\n`;
    });
  }
  
  insights.push({
    type: 'alert',
    title: 'Current Alerts',
    content: `${recentAlerts.length} active shortages, ${highRiskDrugs.length} high-risk drugs`,
    severity: recentAlerts.length > 0 ? 'high' : 'medium'
  });
  
  return { text, insights };
}

function generateExplanationResponse(query: string, relevantData: NDCData[], intent: QueryIntent, allData: NDCData[]): { text: string; insights: DataInsight[] } {
  const insights: DataInsight[] = [];
  
  // Look for trends in the data that could explain spikes
  const recentHighRisk = allData.filter(d => d.riskLevel === 'high');
  const manufacturingIssues = allData.filter(d => d.complianceScore < 0.8);
  
  let text = `**📊 Understanding Recent Patterns:**\n\n`;
  
  if (recentHighRisk.length > 0) {
    const categories = recentHighRisk.reduce((acc, drug) => {
      const category = (drug as any).category || 'uncategorized';
      acc[category] = (acc[category] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);
    
    const topCategory = Object.entries(categories).sort(([,a], [,b]) => b - a)[0];
    
    text += `**Risk Spike Analysis:**\n`;
    text += `• ${recentHighRisk.length} drugs showing elevated risk levels\n`;
    text += `• Primary category affected: ${topCategory?.[0]} (${topCategory?.[1]} drugs)\n`;
    text += `• Common factors: Manufacturing constraints, regulatory inspections, supply chain disruptions\n\n`;
  }
  
  if (manufacturingIssues.length > 0) {
    text += `**Manufacturing Insights:**\n`;
    text += `• ${manufacturingIssues.length} drugs with compliance issues\n`;
    text += `• Likely causes: FDA facility inspections, quality remediation, capacity constraints\n`;
  }
  
  text += `\n**Key Drivers:**\n• Sterile manufacturing complexity\n• Regulatory compliance requirements\n• Market consolidation effects\n• Raw material availability`;
  
  insights.push({
    type: 'trend',
    title: 'Pattern Analysis',
    content: `${recentHighRisk.length} elevated risk drugs, ${manufacturingIssues.length} compliance issues`,
    severity: 'medium'
  });
  
  return { text, insights };
}