// Report parsing utilities for FDA Form 483 and ASHP reports

export interface ReportAnalysis {
  reportType: 'FDA_483' | 'ASHP_SHORTAGE' | 'COMPLIANCE' | 'UNKNOWN';
  severity: 'low' | 'medium' | 'high' | 'critical';
  findings: string[];
  affectedNDCs: string[];
  complianceImpact: number; // -1 to 1 scale
  riskFactors: {
    manufacturing: number;
    quality: number;
    supply_chain: number;
    regulatory: number;
  };
  keywords: string[];
  recommendations: string[];
}

// Keywords that indicate different types of findings
const SEVERITY_KEYWORDS = {
  critical: ['violation', 'immediate', 'critical', 'severe', 'halt', 'stop', 'suspend', 'recall'],
  high: ['deficiency', 'significant', 'major', 'non-compliance', 'failure', 'inadequate'],
  medium: ['observation', 'minor', 'improvement', 'recommend', 'should'],
  low: ['note', 'suggestion', 'consider', 'monitor', 'review'],
};

const REPORT_TYPE_KEYWORDS = {
  FDA_483: ['form 483', 'fda', 'inspection', 'cgmp', 'good manufacturing', 'compliance'],
  ASHP_SHORTAGE: ['ashp', 'shortage', 'supply', 'availability', 'backorder', 'allocation'],
  COMPLIANCE: ['compliance', 'audit', 'quality system', 'deviation', 'corrective action'],
};

const RISK_FACTOR_KEYWORDS = {
  manufacturing: ['manufacturing', 'production', 'facility', 'equipment', 'process', 'batch'],
  quality: ['quality', 'testing', 'specification', 'validation', 'contamination', 'purity'],
  supply_chain: ['supply', 'supplier', 'raw material', 'distribution', 'logistics', 'vendor'],
  regulatory: ['regulatory', 'filing', 'approval', 'license', 'permit', 'registration'],
};

const NDC_PATTERNS = [
  /NDC[_\s]*(\d{3})/gi,
  /(\d{5}-\d{3}-\d{2})/g,
  /(\d{5}-\d{4}-\d{1})/g,
  /(\d{4}-\d{4}-\d{2})/g,
];

export function parseReport(content: string, filename: string): ReportAnalysis {
  const lowerContent = content.toLowerCase();
  const words = lowerContent.split(/\s+/);
  
  // Determine report type
  const reportType = determineReportType(lowerContent, filename);
  
  // Extract severity
  const severity = determineSeverity(lowerContent);
  
  // Extract findings
  const findings = extractFindings(content);
  
  // Find affected NDCs
  const affectedNDCs = extractNDCs(content);
  
  // Calculate compliance impact
  const complianceImpact = calculateComplianceImpact(lowerContent, severity);
  
  // Analyze risk factors
  const riskFactors = analyzeRiskFactors(lowerContent);
  
  // Extract keywords
  const keywords = extractKeywords(lowerContent);
  
  // Generate recommendations
  const recommendations = generateRecommendations(reportType, severity, riskFactors);
  
  return {
    reportType,
    severity,
    findings,
    affectedNDCs,
    complianceImpact,
    riskFactors,
    keywords,
    recommendations,
  };
}

function determineReportType(content: string, filename: string): ReportAnalysis['reportType'] {
  const filenameScore = Object.entries(REPORT_TYPE_KEYWORDS).map(([type, keywords]) => ({
    type: type as ReportAnalysis['reportType'],
    score: keywords.reduce((score, keyword) => 
      score + (filename.toLowerCase().includes(keyword) ? 2 : 0), 0),
  }));
  
  const contentScore = Object.entries(REPORT_TYPE_KEYWORDS).map(([type, keywords]) => ({
    type: type as ReportAnalysis['reportType'],
    score: keywords.reduce((score, keyword) => 
      score + (content.includes(keyword) ? 1 : 0), 0),
  }));
  
  const totalScores = filenameScore.map((fs, i) => ({
    type: fs.type,
    score: fs.score + contentScore[i].score,
  }));
  
  const bestMatch = totalScores.reduce((best, current) => 
    current.score > best.score ? current : best);
  
  return bestMatch.score > 0 ? bestMatch.type : 'UNKNOWN';
}

function determineSeverity(content: string): ReportAnalysis['severity'] {
  const severityScores = Object.entries(SEVERITY_KEYWORDS).map(([level, keywords]) => ({
    level: level as ReportAnalysis['severity'],
    score: keywords.reduce((score, keyword) => 
      score + (content.includes(keyword) ? 1 : 0), 0),
  }));
  
  const bestMatch = severityScores.reduce((best, current) => 
    current.score > best.score ? current : best);
  
  return bestMatch.score > 0 ? bestMatch.level : 'medium';
}

function extractFindings(content: string): string[] {
  const findings: string[] = [];
  
  // Look for numbered findings
  const numberedFindings = content.match(/\d+\.\s*[^.]*(?:violation|deficiency|observation|finding)[^.]*\./gi);
  if (numberedFindings) {
    findings.push(...numberedFindings.map(f => f.trim()));
  }
  
  // Look for bullet point findings
  const bulletFindings = content.match(/[•\-*]\s*[^.]*(?:violation|deficiency|observation|finding)[^.]*\./gi);
  if (bulletFindings) {
    findings.push(...bulletFindings.map(f => f.trim()));
  }
  
  // If no structured findings, extract sentences with key terms
  if (findings.length === 0) {
    const sentences = content.split(/[.!?]+/);
    const keyTerms = ['violation', 'deficiency', 'inadequate', 'failure', 'non-compliance'];
    
    findings.push(...sentences
      .filter(sentence => keyTerms.some(term => sentence.toLowerCase().includes(term)))
      .slice(0, 5)
      .map(s => s.trim()));
  }
  
  return findings.filter(f => f.length > 10).slice(0, 8);
}

function extractNDCs(content: string): string[] {
  const ndcs = new Set<string>();
  
  for (const pattern of NDC_PATTERNS) {
    const matches = content.match(pattern);
    if (matches) {
      matches.forEach(match => ndcs.add(match.trim()));
    }
  }
  
  // Also look for our synthetic NDC IDs
  const syntheticNDCs = content.match(/NDC[_\s]*(\d{3})/gi);
  if (syntheticNDCs) {
    syntheticNDCs.forEach(match => {
      const id = match.replace(/[^0-9]/g, '');
      if (id.length === 3) {
        ndcs.add(`NDC_${id}`);
      }
    });
  }
  
  return Array.from(ndcs);
}

function calculateComplianceImpact(content: string, severity: ReportAnalysis['severity']): number {
  const severityMultipliers = {
    critical: -0.25,
    high: -0.15,
    medium: -0.08,
    low: -0.03,
  };
  
  const baseImpact = severityMultipliers[severity];
  
  // Count negative keywords
  const negativeKeywords = ['violation', 'failure', 'inadequate', 'deficiency', 'non-compliance'];
  const negativeCount = negativeKeywords.reduce((count, keyword) => 
    count + (content.match(new RegExp(keyword, 'gi'))?.length || 0), 0);
  
  // Count positive keywords
  const positiveKeywords = ['compliant', 'adequate', 'satisfactory', 'improvement', 'corrected'];
  const positiveCount = positiveKeywords.reduce((count, keyword) => 
    count + (content.match(new RegExp(keyword, 'gi'))?.length || 0), 0);
  
  let adjustment = (negativeCount * -0.02) + (positiveCount * 0.01);
  adjustment = Math.max(-0.1, Math.min(0.05, adjustment));
  
  return Math.max(-1, Math.min(1, baseImpact + adjustment));
}

function analyzeRiskFactors(content: string): ReportAnalysis['riskFactors'] {
  const riskFactors = {
    manufacturing: 0,
    quality: 0,
    supply_chain: 0,
    regulatory: 0,
  };
  
  Object.entries(RISK_FACTOR_KEYWORDS).forEach(([factor, keywords]) => {
    const score = keywords.reduce((total, keyword) => 
      total + (content.match(new RegExp(keyword, 'gi'))?.length || 0), 0);
    riskFactors[factor as keyof typeof riskFactors] = Math.min(1, score * 0.1);
  });
  
  return riskFactors;
}

function extractKeywords(content: string): string[] {
  const allKeywords = [
    ...Object.values(SEVERITY_KEYWORDS).flat(),
    ...Object.values(RISK_FACTOR_KEYWORDS).flat(),
    'cgmp', 'sterile', 'contamination', 'recall', 'batch', 'lot',
  ];
  
  return allKeywords
    .filter(keyword => content.includes(keyword))
    .slice(0, 10);
}

function generateRecommendations(
  reportType: ReportAnalysis['reportType'],
  severity: ReportAnalysis['severity'],
  riskFactors: ReportAnalysis['riskFactors']
): string[] {
  const recommendations: string[] = [];
  
  // Severity-based recommendations
  if (severity === 'critical' || severity === 'high') {
    recommendations.push('Immediate escalation to senior management required');
    recommendations.push('Consider temporary production halt pending investigation');
  }
  
  // Risk factor-based recommendations
  if (riskFactors.manufacturing > 0.5) {
    recommendations.push('Conduct comprehensive manufacturing process review');
  }
  
  if (riskFactors.quality > 0.5) {
    recommendations.push('Implement enhanced quality control measures');
  }
  
  if (riskFactors.supply_chain > 0.5) {
    recommendations.push('Evaluate alternative suppliers and supply chain resilience');
  }
  
  if (riskFactors.regulatory > 0.5) {
    recommendations.push('Engage regulatory affairs team for compliance assessment');
  }
  
  // Report type-specific recommendations
  if (reportType === 'FDA_483') {
    recommendations.push('Prepare comprehensive CAPA (Corrective and Preventive Action) plan');
    recommendations.push('Schedule follow-up inspection preparation');
  }
  
  if (reportType === 'ASHP_SHORTAGE') {
    recommendations.push('Activate shortage mitigation protocols');
    recommendations.push('Communicate with healthcare providers about alternatives');
  }
  
  return recommendations.slice(0, 6);
}